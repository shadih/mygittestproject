package ntdProcessing.ntdProcessing;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Classes of ntdProcessing.externaldata
import ntdProcessing.externaldata.NTDInterval;
import ntdProcessing.externaldata.NTDIntervalProperties;
import ntdProcessing.util.PurgeIntervalHelper;
import ntdProcessing.util.service_util;

// Other uca-ebc classes
import com.hp.uca.common.trace.LogHelper;
import com.hp.uca.expert.alarm.Alarm;
import com.hp.uca.expert.alarm.AlarmCommon;
import com.hp.uca.expert.lifecycle.LifeCycleAnalysis;
import com.hp.uca.expert.scenario.Scenario;
import com.hp.uca.expert.scenario.ScenarioStatus;
import com.hp.uca.expert.scenario.ScenarioThreadLocal;
import com.hp.uca.expert.x733alarm.PerceivedSeverity;

// Just an example of extension of analyzer
public class ExtendedLifeCycle extends LifeCycleAnalysis {
	
	protected static final String NTD_TICKET_INTERVAL_BEAN_NAME = "NTDIntervalProperties";
	private static NTDIntervalProperties ntdIntervalProperties = null;
	private static Boolean purgeIntervalSet = false;
	
	private static Logger log = LoggerFactory
			.getLogger(ExtendedLifeCycle.class);

	// Intention is to trigger the rule with this alarm. We will trigger the
	// rule to setup watch dog to purge alarms.
	// This will be set to true when we get the first alarm.
	private static Boolean firstAlarm = true;

	public ExtendedLifeCycle(Scenario scenario) {
		super(scenario);

		/*
		 * If needed more configuration, use the context.xml to define any beans
		 * that will be available here using scenario.getGlobals()
		 */
		// scenario.getGlobals()
	}

	@Override
	public AlarmCommon onAlarmCreationProcess(Alarm alarm) {
		
		if (log.isTraceEnabled()) {
			LogHelper.enter(log, "onAlarmCreationProcess()");
		}
		String ntdSourceIdentifier = "NTD";

		// This is where we will create a Node in Graph DB
		// Call extended Topo Access to access the DB
		// Extract the fields of the Alarm
		// Create / insert a node in the Graph DB

		// LogHelper.exit(log, "onAlarmCreationProcess()");

		// call CreateNode() or DeleteNode() only if alarms sourceIdentifier is NTD
		if ( alarm.getSourceIdentifier().equalsIgnoreCase(ntdSourceIdentifier) )
		{
			alarm.getVar().put("PurgingState", false);
			
			long now = (System.currentTimeMillis() / 1000l); 
			
			// for Junit testing we must set the alarm time to be now
			//alarm.setCustomFieldValue("AlarmTime", Long.toString(now));
			
			
			if (log.isTraceEnabled())
			{
				LogHelper.enter(log, "onAlarmCreationProcess(): Processing NTD Ticket");
				log.trace("Alarm time is " + alarm.getCustomFieldValue("AlarmTime") );
			}
			
			// After checking severity , and if severity is not clear
			if ( !alarm.getPerceivedSeverity().equals(PerceivedSeverity.CLEAR) )
			{
				if (log.isTraceEnabled())
				{
					LogHelper.enter(log, "onAlarmCreationProcess(): Calling - NTD=>CreateNode() on TicketNumber : " + alarm.getCustomFieldValue("TicketNumber") );
				}
				
				ExtendedTopoAccess.getInstance().CreateNode(alarm);
				
				// we are only going to do one watchdog to check for aged tickets.
				if(!purgeIntervalSet) {
					PurgeIntervalHelper.startPurgePeriod(getScenario(), alarm); 
					purgeIntervalSet=true;
				}
				
				if (log.isTraceEnabled())
				{
					LogHelper.exit(log, "onAlarmCreationProcess(): Calling - NTD=>CreateNode() on TicketNumber : " + alarm.getCustomFieldValue("TicketNumber") );
					// LogHelper.enter(log, "After Calling - NTD=>CreateNode() on TicketNumber : " + alarm.getCustomFieldValue("TicketNumber") );
				}
			}

			if ( alarm.getPerceivedSeverity().equals(PerceivedSeverity.CLEAR) )
			{
				if (log.isTraceEnabled())
				{
					//LogHelper.enter(log, "Before Calling - NTD=>DeleteNode() on TicketNumber : " + alarm.getCustomFieldValue("TicketNumber") );
					LogHelper.enter(log, "onAlarmCreationProcess(): Calling - NTD=>DeleteNode() on TicketNumber : " + alarm.getCustomFieldValue("TicketNumber") );
				}
				
				ExtendedTopoAccess.getInstance().DeleteNode(alarm.getCustomFieldValue("TicketNumber"),alarm);
				
				if (log.isTraceEnabled())
				{
					LogHelper.exit(log, "onAlarmCreationProcess(): Calling - NTD=>DeleteNode() on TicketNumber : " + alarm.getCustomFieldValue("TicketNumber") );
					//LogHelper.enter(log, "After Calling - NTD=>DeleteNode() on TicketNumber : " + alarm.getCustomFieldValue("TicketNumber") );
				}
			}
			
		}
		
		if (log.isTraceEnabled()) {
			LogHelper.exit(log, "onAlarmCreationProcess()");
		}

		// By returning NULL we ensure that alarm will not go into Working
		// Memory

		if (!firstAlarm)
			return null;
		else
		{
			firstAlarm = false;
			return alarm;
		}
				
	} // for onAlarmCreationProcess()
	
	
	public static String lookupNTDTicketDuration() {
		if (log.isTraceEnabled()) {
			LogHelper.enter(log, "lookupNTDTicketDuration()");
		}
		
		NTDInterval ntdInterval  = new NTDInterval();
		
        if( ntdIntervalProperties == null)
        {
            Scenario scenario = ScenarioThreadLocal.getScenario();    
    		if(scenario == null) {
    			log.trace("GFPUtil.forwardOrCascadeAlarm() Scenario cannot be NULL");  
    		}
        	
        	ntdIntervalProperties = (NTDIntervalProperties)service_util.retrieveBeanFromContextXml(scenario, NTD_TICKET_INTERVAL_BEAN_NAME);
        }
         
        if(ntdIntervalProperties != null) 
        {
        	ntdInterval  = ntdIntervalProperties.getHashNTDInterval().get("NTDProcess");
        }
  
		if (log.isTraceEnabled()) { 
			LogHelper.exit(log, "lookupNTDTicketDuration() - ntdTicketDuration in seconds is : " + ntdInterval.getNtdTicketDuration());
		}
		return ntdInterval.getNtdTicketDuration();
		//return "60";
	}

} // For Class LifeCycleAnalysis
