package ntdProcessing.ntdProcessing;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import ntdProcessing.util.service_util;

import org.neo4j.cypher.javacompat.ExecutionEngine;
import org.neo4j.cypher.javacompat.ExecutionResult;
import org.neo4j.graphdb.Relationship;
import org.neo4j.graphdb.RelationshipType;
import org.neo4j.graphdb.Transaction;
import org.neo4j.graphdb.index.Index;
import org.neo4j.graphdb.index.IndexHits;
import org.neo4j.graphdb.index.IndexManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.att.gfp.helper.GFPUtil;
import com.hp.uca.common.trace.LogHelper;
import com.hp.uca.expert.alarm.Alarm;
import com.hp.uca.expert.alarm.AlarmForwarder;
import com.hp.uca.expert.alarm.FileAlarmForwarder;
import com.hp.uca.expert.alarm.OpenMediationAlarmForwarder;
import com.hp.uca.expert.alarm.exception.AlarmForwarderException;
import com.hp.uca.expert.scenario.Scenario;
import com.hp.uca.expert.scenario.ScenarioThreadLocal;
import com.hp.uca.expert.topology.TopoAccess;

public class ExtendedTopoAccess extends TopoAccess {

	private static ExtendedTopoAccess topologyAccessor = null;
	private static AlarmForwarder ntdFileAlarmForwarder; 

	private static Logger log = LoggerFactory 
			.getLogger(ExtendedTopoAccess.class); 

	private static ExecutionEngine engine= GFPUtil.getCypherEngine(); 


	public static synchronized ExtendedTopoAccess getInstance() {
		if (topologyAccessor == null) {
			topologyAccessor = new ExtendedTopoAccess();
		}
		if(engine == null)
			engine = GFPUtil.getCypherEngine(); 
		return topologyAccessor;
	}
	
	// Forward Alarm to File
	public void sendAlarm(Alarm alarm){
		
		if (log.isTraceEnabled()) {
			LogHelper.enter(log, "service_util.forwardAlarmToNOM()");
		}
//		if(alarmFile == null)
//			alarmFile = new File("forwarded-alarms.xml");
//		fileAlarmForwarder = null;
        Scenario scenario = ScenarioThreadLocal.getScenario();    
		if(scenario == null) {
			log.trace("GFPUtil.forwardOrCascadeAlarm() Scenario cannot be NULL");  
		}
		
		if(ntdFileAlarmForwarder == null) {
			log.trace("service_util.forwardAlarmToNOM(): retrieving the file alarm forwarder from spring bean = ");
			if(service_util.retrieveBeanFromContextXml(scenario,"ntdFileAlarmForwarder") != null) {
				ntdFileAlarmForwarder = (FileAlarmForwarder) (service_util.retrieveBeanFromContextXml(scenario,"ntdFileAlarmForwarder"));
				log.trace("service_util.forwardAlarmToNOM(): retrieved file alarm forwarder from spring bean = ");
			}      
		} 
		if(ntdFileAlarmForwarder != null) {  
			try { 
				ntdFileAlarmForwarder.write(alarm);
	//			fileAlarmForwarder.write(null);
				log.trace("service_util.forwardAlarmToNOM(): Wrote alarm to file:" + alarm.getIdentifier()); 
			} catch (AlarmForwarderException e) {
				log.error(e.getMessage());  
				e.printStackTrace();     
			}
		} else {  
			log.trace("service_util.forwardAlarmToNOM(): fileAlarmForwarder is still NULL.");
		}    
		if (log.isTraceEnabled()) {
			log.trace("sendAlarm() : Exit : ");
		}
	}

	// Method1: CreateNode(Alarm ntdAlarm) will be called from ExtendedLifeCycle.java (when we receive an active alarm)
	public void CreateNode(Alarm ntdAlarm){
		
		if (log.isTraceEnabled())
		{
			log.trace("CreateNode() : Enter : ");
		}
		
		// Will be used to build Cypher Query
		String query = null;
		
		
		if (log.isTraceEnabled())
		{
			log.trace("CreateNode() : Extract Fields from Alarm ");
		}
		
		// Extract the fields from Alarm
		String clfiValue = ntdAlarm.getCustomFieldValue("clfi");
		String TicketNumberValue = ntdAlarm.getCustomFieldValue("TicketNumber");
		String NWPHostnameValue = ntdAlarm.getCustomFieldValue("NWPHostname");
		String PublishFlagValue = ntdAlarm.getCustomFieldValue("PublishFlag");
		String AlarmTimeValue = ntdAlarm.getCustomFieldValue("AlarmTime");
		
		// Only when NTDTicketNumber is not NULL update Neo4j Graph Database
		if (!TicketNumberValue.isEmpty())
		{
			if (log.isTraceEnabled())
			{
				log.trace("CreateNode() : Extracted Fields from Alarm clfi = " + clfiValue + 
						" TicketNumber = " + TicketNumberValue + 
						" NWPHostname = " + NWPHostnameValue + 
						" PublishFlag = " + PublishFlagValue + 
						" AlarmTime = " + AlarmTimeValue + 
						" PerceivedSeverity = " + ntdAlarm.getPerceivedSeverity() );
			}
			
			if (log.isTraceEnabled())
			{
				log.trace("CreateNode() : Build query to create NTD Ticket in neo4j Graph DB ");
			}
		
			// 	Example create node without relationship - This will not work for us
				// CREATE (n  { class : "NTD" , clfi : "P101/GE10/DTRTMIBL0AW/DTRTMIBL0BW" ,  TicketNumber :"512066" , NWPHostname :"RAMAhost" , PublishFlag : "H" , AlarmTime : "1453248000" }) return n
			// Example2: Create node with NTDTicket as relationship
				// CREATE (n  { class : "NTD" , clfi : "P101/GE10" ,  TicketNumber :"512064" , NWPHostname :"RAMAhost" , PublishFlag : "H" , AlarmTime : "1453248000" })-[r:NTDTicket]->neo return n
		
			query = "START n=node(0) " +
			"CREATE (t  { class :\"NTD\" , clfi :\"" + clfiValue + "\" ,  TicketNumber :\"" + TicketNumberValue +
			"\" , NWPHostname :\"" + NWPHostnameValue + "\", PublishFlag :\"" + PublishFlagValue +
			"\", AlarmTime :" + AlarmTimeValue + " })" +   
			" CREATE n-[:NTDTicket]->t " + 
			"RETURN t"; 
			
/*			query = "CREATE (n " +
					" { class : \"NTD\" , " +
					"clfi : \"" + clfiValue + "\" , " +
					" TicketNumber :\"" + TicketNumberValue + "\" , " +
					"NWPHostname :\"" + NWPHostnameValue+ "\" , " +
					"PublishFlag : \"" + PublishFlagValue + "\" , " +
					"AlarmTime : \"" + AlarmTimeValue + "\" }" +
					")" + 
					"-[r:NTDTicket]->neo " +
					" return n" ;*/
		
			if (log.isTraceEnabled())
			{
				log.trace("CreateNode() : Execute query to create NTD Ticket in neo4j Graph DB ........ " );
				log.trace("CreateNode() : Cypher Query " +  query );
			}
			
			ExecutionResult result = engine.execute(query);
			
			// Learnings - 17th September 2013 (As usual, thanks to Dave Florcik)
			// Looks like Indexes are created on Columns of a Node
			// We need to create an Index
			// About how to query nodes based on an Index and then delete the node, there is some confusion
			// Also since NTD tickets are not many, we decided that we will not use Indexes.
		
			//Forward alarm to a file
			sendAlarm(ntdAlarm);
		
			// Lets display what is inserted in the Neo4j Graph DB
		
			// This does not work
			/*		int count=0;
			for ( Map<String, Object> row : result ) {
			
				log.trace("CreateNode() : Result of Neo4j Query : " +
						" class " + (String)row.get("class") +
						" clfi " + (String)row.get("clfi") +
						" TicketNumber " + (String)row.get("TicketNumber") +
						" NWPHostname " + (String)row.get("NWPHostname") +
						" PublishFlag " + (String)row.get("PublishFlag") +
						" AlarmTime " + (String)row.get("AlarmTime")
					);
			
				count++;
				//break;
			}*/
		
		}
		else
		{
			if (log.isTraceEnabled())
			{
				log.trace("CreateNode() : TicketNumber is NULL for the incoming alarm with CLFI " +
						"CLFI Value = " +
						clfiValue );
			}
		}
		
		if (log.isTraceEnabled())
		{
			log.trace("CreateNode() : Exit : ");
		}
	}

	// Method2: DeleteNode(string TicketNumber) will be called from ExtendedLifeCycle.java (When we receive a clear alarm)
	public void DeleteNode(String TicketNumberValue, Alarm ntdAlarm) {

		if (log.isTraceEnabled())
		{
			log.trace("DeleteNode() : Enter : ");
		}
		String query = null;


		if (log.isTraceEnabled())
		{
			log.trace("DeleteNode() : Build query to delete NTD Ticket : "
				+ TicketNumberValue + " : from neo4j Graph DB ");
		}
		
		// query = "START n=node(*) MATCH n WHERE n.TicketNumber = \'" + TicketNumberValue +  "\' DELETE n"; // This fails when there are nodes that do not have n.TicketNumber (example EVC Nodes, PPort Nodes)
		// query = START n=node(*)  MATCH (n)-[r:NTDTicket]-() WHERE ( HAS(n.class) and n.class="NTD" and HAS(n.TicketNumber) and n.TicketNumber="512064" ) DELETE n, r; // This works when executed manuelly
		query = "START n=node(0)  MATCH (n)-[r:NTDTicket]-(t) WHERE t.TicketNumber=\"" + TicketNumberValue + "\"  DELETE t, r";
		
		
		if (log.isTraceEnabled())
		{
			log.trace("DeleteNode() : Execute query to delete NTD Ticket : " +
				TicketNumberValue + " from neo4j Graph DB ........ " );
			log.trace("DeleteNode() : Cypher Query " +  query );
		}

		ExecutionResult result = engine.execute(query);
		
		//Forward alarm to a file
		// sendAlarm can be called from 
		// 1. ExtendedLifeCycle => onAlarmCreationProcess when we receive a clear alarm. We need to log when receiving a clear alarm.
		// 2. PurgeNode() when the nodes meets purgeInterval criteria. In this case we do not have an alarm to log.
		if (ntdAlarm != null)
		{
			sendAlarm(ntdAlarm);
		}

		// This does not work
		// log.trace("DeleteNode() : Number of nodes deleted are : " + result); 

		if (log.isTraceEnabled())
		{
			log.trace("DeleteNode() : Exit : ");
		}

	}

	// Method3: PurgeNode() will be called from rules when ever watchDog has triggered
	public void PurgeNode() {
		
		if (log.isTraceEnabled())
		{
			log.trace("PurgeNode() : Enter : ");
		}
		
		String query = null;
		ArrayList <String> nodes = new ArrayList<String>();
		

		// Get the current time converted to Unix Time
		// String now = String.valueOf(System.currentTimeMillis()/1000l);
		long now = (System.currentTimeMillis() / 1000l);

		// Lets now go 7 days back from now
		// long cutoffdate = now - (7 * 24 * 60 * 60);
		
		// For testing - I will go back 4 hours
		// long cutoffdate = now - ( 4 * 60 * 60 );
		
		// Get ntdTicketDuration from XML
		long ntdTicketDuration = Long.parseLong(ExtendedLifeCycle.lookupNTDTicketDuration());
		
		if (log.isTraceEnabled())
		{
			log.trace("PurgeNode() : ntdTicketDuration in seconds is : " + ntdTicketDuration );
			log.trace("PurgeNode() : time now is : " + now );
		}
			
		// To arrive at cutoffdate we go back in Time by -> time(now) - ntdTicketDuration, and we delete tickets older than this new cutoffdate.
		long cutoffdate = now - ntdTicketDuration ;
				
		// Now lets Compute ntdTicketDurationInDays, used only for logging purposes.
		
		// Get the number of seconds in a day
		long oneHour = ( 60 * 60 );
		double ntdTicketDurationInHours = ( ntdTicketDuration /  oneHour );
		
		if (log.isTraceEnabled())
		{
			log.trace("PurgeNode() : We will retrieve tickets older than ntdTicketDuration ( in hours ) : " + ntdTicketDurationInHours );
		}
		
		// Below commented queries are for academic purposes
		// Cypher Query which failed with The property 'AlarmTime' does not exist on Node[0]
			// query = "START n=node(*) MATCH (n) WHERE n.AlarmTime < \"" + cutoffdate + "\" RETURN n.TicketNumber";
		// Cypher Query that succeeded, we need to ensure that we have the HAS Clause that checks for the fileds we are intrested in
			// START n=node(*)  MATCH (n)-[r:NTDTicket]-() WHERE ( HAS(n.class) and n.class="NTD" and HAS(n.AlarmTime) and n.AlarmTime < 1377212789 ) RETURN  n; // This should work
		
		query = "START n=node(0)  MATCH (n)-[:NTDTicket]-(t) WHERE t.AlarmTime < " + cutoffdate + "  RETURN  t.TicketNumber";

		if (log.isTraceEnabled())
		{
			log.trace("PurgeNode() : Execute query to get NTD Tickets older than ntdTicketDuration : " +  ntdTicketDurationInHours + " hours from neo4j Graph DB " );
			log.trace("PurgeNode() : Cypher Query " +  query );
		}
		ExecutionResult result = engine.execute(query);

		// Lets delete each node that is part of the above query
		int count = 0;
		for (Map<String, Object> row : result) {
			String TicketNumberValue = (String) row.get("t.TicketNumber");
			
			if(TicketNumberValue != null) {
				if (log.isTraceEnabled())
				{
					log.trace("PurgeNode() : Deleting Ticket Number : " + TicketNumberValue
							+ " From Neo4j Graph DB ");
				}

				nodes.add(TicketNumberValue);
				count++;
			}
			// break;
		}

		if(!nodes.isEmpty()) {
			for (String ticketNum : nodes) {
				// call DeleteNode with TicketNumber and Null
				// As we do not have an alarm in this case we pass Null in place of Alarm
				// We pass the TicketNumber that is returned by the query
				DeleteNode(ticketNum,null);
			}
		}
		
		if (log.isTraceEnabled())
		{
			log.trace("PurgeNode() : Number of nodes deleted are : " + count);
		}
		
		if (log.isTraceEnabled())
		{
			log.trace("PurgeNode() : Exit : ");
		}

	}

}
