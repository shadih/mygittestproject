package ntdProcessing.util;

import java.lang.reflect.Method;

import ntdProcessing.externaldata.NTDIntervalProperties;
import ntdProcessing.ntdProcessing.ExtendedTopoAccess;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hp.uca.common.callback.Callback;
import com.hp.uca.expert.alarm.Alarm;
import com.hp.uca.expert.scenario.Scenario;

public class PurgeIntervalHelper {
	
	private static final int ARGUMENT_1 = 0;
	private static final int ARGUMENT_2 = 1;

	private static final Logger LOG = LoggerFactory.getLogger(PurgeIntervalHelper.class);
	
	private static final int NB_CALLBACK_ARGUMENTS = 2;

	public static void startPurgePeriod(Scenario scenario, Alarm alarm) {

		LOG.info("STARTING purge interval for alarm: " + alarm.getIdentifier());
		alarm.getVar().put("PurgingState", true);
		Callback callback = null;
		try {
			callback = buildenrichmentCallback(scenario, alarm);
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		}
		NTDIntervalProperties ntdIntervalProperties = (NTDIntervalProperties)service_util.retrieveBeanFromContextXml(scenario, "NTDIntervalProperties");
		scenario.addCallbackWatchdogItem(
				ntdIntervalProperties.getHashNTDInterval().get("NTDProcess").getNtdTicketCheckIntervalAsLong(),
				callback, true, "Purging alarm xxx", false,
				alarm);

		LOG.trace("Purge interval is: " + ntdIntervalProperties.getHashNTDInterval().get("NTDProcess").getNtdTicketCheckIntervalAsLong());
	}
	
	
	public static Callback buildenrichmentCallback(Scenario scenario,
			Alarm alarm)
			throws NoSuchMethodException {

		Class<?> partypes[] = new Class[NB_CALLBACK_ARGUMENTS];
		partypes[ARGUMENT_1] = Scenario.class;
		partypes[ARGUMENT_2] = Alarm.class;

		Object arglist[] = new Object[NB_CALLBACK_ARGUMENTS];
		arglist[ARGUMENT_1] = scenario;
		arglist[ARGUMENT_2] = alarm;
		Method method = PurgeIntervalHelper.class.getMethod(
				"enrichmentCallback", partypes);

		Callback callback = new Callback(method, null, arglist);

		return callback;
	}
	 
	
	public static void enrichmentCallback(Scenario scenario, Alarm alarm) {
		 LOG.info("End of  purge interval for alarm :" + alarm.getIdentifier()); 
	       ExtendedTopoAccess.getInstance().PurgeNode();
	}
}
