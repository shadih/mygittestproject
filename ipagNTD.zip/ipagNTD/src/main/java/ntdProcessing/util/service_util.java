package ntdProcessing.util;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

//import com.att.gfp.data.ipagPreprocess.preprocess.EnrichedAlarm;
//import com.att.gfp.data.ipagPreprocess.preprocess.ExtendedLifeCycle;
import ntdProcessing.ntdProcessing.ExtendedTopoAccess;
import com.hp.uca.common.trace.LogHelper;
import com.hp.uca.common.xml.XmlConfiguration;
import com.hp.uca.expert.alarm.Alarm;
import com.hp.uca.expert.scenario.Scenario;
import com.hp.uca.expert.x733alarm.PerceivedSeverity;
import com.hp.uca.expert.alarm.FileAlarmForwarder;
import com.hp.uca.expert.alarm.OpenMediationAlarmForwarder;
import com.hp.uca.expert.alarm.AlarmForwarder;
import com.hp.uca.expert.alarm.exception.AlarmForwarderException;

public class service_util {

	private static Logger log = LoggerFactory.getLogger(ExtendedTopoAccess.class);
	
	public service_util() {
		
	}
	
	public static File getfileFromResourceName(String fileName) {
		File configFile = null;
		
		configFile = new File(fileName);
		
		return configFile;

	}
	
	public static Object retrieveBeanFromContextXml(Scenario scenario,String beanName) {
		if(scenario == null) {
			log.trace("service_util.retrieveBeanFromContextXml() Scenario is NULL");
		}
		ApplicationContext context =   
			scenario.getVPApplicationContext(); 
	      return context.getBean(beanName);
	}
	
	
	

	
}
