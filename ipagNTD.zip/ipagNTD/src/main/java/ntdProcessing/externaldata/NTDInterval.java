package ntdProcessing.externaldata;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ntdInterval", propOrder = {

})
public class NTDInterval {

	@XmlElement(required = true)
	private  String module;
	@XmlElement(required = true)
	private String ntdTicketDuration;
	@XmlElement(required = true)
	private String ntdTicketCheckInterval;

	
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getNtdTicketDuration() {
		return ntdTicketDuration; 
	}
	public void setNtdTicketDuration(String ntdTicketDuration) {
		this.ntdTicketDuration = ntdTicketDuration;
	}
	public String getNtdTicketCheckInterval() {
		return ntdTicketCheckInterval;
	}
	public void setNtdTicketCheckInterval(String ntdTicketCheckInterval) {
		this.ntdTicketCheckInterval = ntdTicketCheckInterval;
	}
	// getNtdTicketCheckInterval return as Long
	public Long getNtdTicketCheckIntervalAsLong() {
		return Long.parseLong(ntdTicketCheckInterval);
	}
}
