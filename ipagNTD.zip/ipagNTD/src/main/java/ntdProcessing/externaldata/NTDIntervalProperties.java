package ntdProcessing.externaldata;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ntdProcessing.util.service_util;
import com.hp.uca.common.misc.DateTimeUtil;
import com.hp.uca.common.properties.exception.ConfigurationFileException;
import com.hp.uca.common.xml.XmlConfiguration;
import com.hp.uca.expert.jmx.JMXManager;
import com.hp.uca.expert.scenario.Scenario;


public class NTDIntervalProperties extends XmlConfiguration implements 
NTDIntervalPropertiesMXBean {

	private static final String NTD_TICKET_INTERVAL_JMX_NAME = "NTDInterval";

	private static final String UCA_EXPERT_APPLICATION = "uca_ebc";

	/** 
	 * 
	 */
	public static final String NTD_TICKET_INTERVAL_CONFIG_XML = "Configurations.xml";

	private static final Logger log = LoggerFactory.getLogger(NTDIntervalProperties.class);

	/**
	 * JMX Helper, manages information exported to the JMX interface.
	 */
	private JMXManager jmxManager;

	private File ntdIntervalFile;

	private Scenario scenario;

	private NTDIntervalXml ntdIntervalXml;

	private long lastFileUpdate = 0L;

	private String configurationFileName = NTD_TICKET_INTERVAL_CONFIG_XML;

	private Map<String, NTDInterval> hashNTDInterval = Collections
			.synchronizedMap(new HashMap<String, NTDInterval>());

	/**
	 * 
	 */
	public NTDIntervalProperties() {
		super();

		setObjectClass(ntdProcessing.externaldata.NTDIntervalXml.class);

	}


	/**
	 * 
	 */
	@PostConstruct
	public void init() {
		log.info("Enter: PurgeIntervalProperties  init()");
		
		ntdIntervalFile = service_util.getfileFromResourceName(NTD_TICKET_INTERVAL_CONFIG_XML);

		if (ntdIntervalFile != null && ntdIntervalFile.exists()) {
			lastFileUpdate = ntdIntervalFile.lastModified();
		}

		try {
			initialize(configurationFileName);
			refreshFromFile();
		} catch (ConfigurationFileException e) {
			log.error(
					"Unable to retrieve event names from file : " + e);

		}

		if(ntdIntervalFile.exists()) {
			log.info("file to open:  " + ntdIntervalFile.getAbsolutePath());
		} else {
			log.info("file doesn't exist:  " + ntdIntervalFile.getAbsolutePath());
		}
		
		log.trace("Exit: init()");
		
	}

	/**
	 * @param scenario
	 */
	public void registerJmx(Scenario scenario) {
		this.scenario = scenario;
		jmxManager.register(UCA_EXPERT_APPLICATION, scenario.getValuePack()
				.getNameVersion(), null, NTD_TICKET_INTERVAL_JMX_NAME, this);
	}

	/**
	 * 
	 */
	@PreDestroy
	public void unregisterJmx() {
		try {
			jmxManager
					.unregister(UCA_EXPERT_APPLICATION, scenario.getValuePack()
							.getNameVersion(), null, NTD_TICKET_INTERVAL_JMX_NAME);
		} catch (Exception e) {

		}
	}

	@Override
	public void refreshFromFile() throws ConfigurationFileException {

		synchronized (getHashNTDInterval()) {

			setNTDIntervalXml((NTDIntervalXml) unmarshal());

			rebuildHashTables();
		}

			log.trace("refreshFromFile()");
 
	}

	@Override
	public void saveToFile() throws ConfigurationFileException {
		 log.trace("Enter: saveToFile()");
		
		marshal(getNTDIntervalXml());

		log.trace("Exit: saveToFile()");
	}

	protected void rebuildHashTables() {
		log.trace("Enter: PurgeInterval rebuildHashTables()");

		getHashNTDInterval().clear(); 

		if (getNTDIntervalXml() != null) {

			for (NTDInterval ntdInterval : getNTDIntervalXml().getNtdInterval()) {
				getHashNTDInterval().put(
						ntdInterval.getModule(),
						ntdInterval); 
 
				log.trace("ntdInterval has = " + ntdInterval.getModule());
				log.trace("Life Time of a NTD Ticket = " + ntdInterval.getNtdTicketDuration());
				log.trace("Trigger the Deletion of NTD Tickets every = " + ntdInterval.getNtdTicketCheckInterval());
			}  
		}
		log.trace("Exit: rebuildHashTables()");
		
	}

	/**
	 * 
	 */
	public void reloadFileIfUpdated() {

		if (ntdIntervalFile != null && ntdIntervalFile.exists()
				&& lastFileUpdate < ntdIntervalFile.lastModified()) {
			lastFileUpdate = ntdIntervalFile.lastModified();
			try {
				log.info(String.format("File [%s] has changed... reloading it",
						ntdIntervalFile.getAbsolutePath()));
				refreshFromFile();
			} catch (ConfigurationFileException e) {
				log.trace("Unable to retrieve Enrichment from file : " + e);

			}
		}
	}

	/**
	 * @return the tunableXml
	 */
	public NTDIntervalXml getNTDIntervalXml() {
		return ntdIntervalXml;
	}

	/**
	 * @param enrichmentXml
	 *            the enrichmentXml to set
	 */
	public void setNTDIntervalXml(NTDIntervalXml ntdIntervalXml) {
		this.ntdIntervalXml = ntdIntervalXml;
	}

	/**
	 * @return the hashManagedObjectToSite
	 */
	public Map<String, NTDInterval> getHashNTDInterval() {
		return hashNTDInterval;
	}

	/**
	 * @return the configurationFileName
	 */
	public String getConfigurationFileName() {
		return configurationFileName;
	}

	/**
	 * @param configurationFileName
	 *            the configurationFileName to set
	 */
	public void setConfigurationFileName(String configurationFileName) {
		this.configurationFileName = configurationFileName;
	}

	/**
	 * @return the jmxManager
	 */
	public JMXManager getJmxManager() {
		return jmxManager;
	}

	/**
	 * @param jmxManager
	 *            the jmxManager to set
	 */
	public void setJmxManager(JMXManager jmxManager) {
		this.jmxManager = jmxManager;
	}

	/**
	 * @return the tunableFile
	 */
	public File getNTDIntervalFile() {
		return ntdIntervalFile;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.acme.enrichment.EnrichmentPropertiesMXBean#getLastFileUpdate()
	 */
	@Override
	public String getLastFileUpdate() {
		return DateTimeUtil.toString(lastFileUpdate);
	}

	
}
