package ntdProcessing.externaldata;

import java.util.Map;

import com.hp.uca.common.properties.exception.ConfigurationFileException;

public interface NTDIntervalPropertiesMXBean {

	/**
	 * @throws ConfigurationFileException
	 */
	void refreshFromFile() throws ConfigurationFileException;

	/**
	 * @throws ConfigurationFileException 
	 */
	void saveToFile() throws ConfigurationFileException;

	/**
	 * @return
	 */
	Map<String, NTDInterval> getHashNTDInterval(); 

	/**
	 * @return
	 */ 
	String getLastFileUpdate();	
}
