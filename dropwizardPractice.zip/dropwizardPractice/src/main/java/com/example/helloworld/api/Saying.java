package com.example.helloworld.api;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.Length;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Saying {
    private long id;
    static final Logger metricsLogger = LoggerFactory.getLogger("metricsLogger");
	static final Logger debugLogger = LoggerFactory.getLogger("debugLogger");

    @Length(max = 3)
    private String content;

    public Saying() {
        // Jackson deserialization
    }

    public Saying(long id, String content) {
        this.id = id;
        this.content = content;
        metricsLogger.info(" metricsLogger INFO; Saying  - Constructor; id: {} .", id);
        debugLogger.debug(" debugLogger DEBUG; Saying  - Constructor; content: {}", content);
    }

    @JsonProperty
    public long getId() {
        return id;
    }

    @JsonProperty
    public String getContent() {
        return content;
    }
}