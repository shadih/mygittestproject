package com.example.helloworld;

import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;
import com.example.helloworld.resources.HelloWorldResource;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.util.ContextInitializer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.example.helloworld.health.TemplateHealthCheck;

public class HelloWorldApplication extends Application<HelloWorldConfiguration> {
	
	static final Logger logger = LoggerFactory.getLogger(HelloWorldApplication.class);
	static final Logger metricsLogger = LoggerFactory.getLogger("metricsLogger");
	static final Logger debugLogger = LoggerFactory.getLogger("debugLogger");
	
    public static void main(String[] args) throws Exception {
    
    	logger.info("HelloWorldApplication.main() Startup with config file: {} .", args[1]);
    	//metricsLogger.info("in metrics at info level - HelloWorldApplication Startup with config file: {} .", args[1]);
    	//debugLogger.info("in debug at info level - HelloWorldApplication Startup with config file: {} .", args[1]);
    	//debugLogger.trace("in debug at trace level - HelloWorldApplication Startup with config file: {} .", args[1]);
    	//debugLogger.debug("in debug at debug level - HelloWorldApplication Startup with config file: {} .", args[1]);
    	//metricsLogger.debug("in metrics at debug level  - HelloWorldApplication Startup with config file: {} .", args[1]);
    	
        new HelloWorldApplication().run(args);
    	LoggerContext context = (LoggerContext)LoggerFactory.getILoggerFactory();
    	context.reset();
    	ContextInitializer initializer = new ContextInitializer(context);
    	initializer.autoConfig();
    	debugLogger.info(" debugLogger INFO - HelloWorldApplication.main() after run()");
    	metricsLogger.info(" metricsLogger INFO - HelloWorldApplication.main() after run()");
    	debugLogger.debug(" debugLogger DEBUG - HelloWorldApplication.main() after run()");
    	metricsLogger.debug(" metricsLogger DEBUG - HelloWorldApplication.main() after run()");
    }

    @Override
    public String getName() {
        return "hello-world";
    }

    @Override
    public void initialize(Bootstrap<HelloWorldConfiguration> bootstrap) {
        // nothing to do yet
    }

    @Override
    public void run(HelloWorldConfiguration configuration,
                    Environment environment) {
    	logger.info("HelloWorldApplication.run().");
    	debugLogger.info("HelloWorldApplication.run().");
    	
        final HelloWorldResource resource = new HelloWorldResource(
            configuration.getTemplate(),
            configuration.getDefaultName()
        );
        final TemplateHealthCheck healthCheck =
            new TemplateHealthCheck(configuration.getTemplate());
        environment.healthChecks().register("template", healthCheck);
        environment.jersey().register(resource);
    }

}