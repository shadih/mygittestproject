package com.att.gfp.data.dcaecorrelator;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONObject;

//import com.att.gfp.cpe.topo.CpeAutoFactory;
//import com.att.gfp.cpe.topo.CpeBaseTopoObject;
import com.att.gfp.goc.topology.GocTopoError;
import com.att.gfp.goc.topology.GocTopoInvalid;
import com.att.gfp.goc.topology.GocTopoNotFound;
import com.att.gfp.goc.topology.GocTopoObject;
import com.att.sa.flatiron.client.FlatironClient;
import com.att.sa.flatiron.client.FlatironClientFactory;
import com.att.sa.flatiron.client.FlatironException;
import com.att.sa.flatiron.client.FlatironObjectNotFoundException;
import com.att.sa.flatiron.client.FlatironRelation;

public class GfpdDb_OLD
{
	public GfpdDb_OLD ( String flatironHosts, String flatironScope )
	{
		this ( FlatironClientFactory.createClient ( flatironHosts, flatironScope ) );
	}

	public GfpdDb_OLD ( FlatironClient fc )
	{
		fFlatiron = fc;
	}

	/**
	 * Get an object from the DB based on its unique key.
	 * @param key
	 * @return a basic topology object
	 * @throws GocTopoError 
	 */
/*	public CpeBaseTopoObject getObject ( String key ) throws GocTopoNotFound, GocTopoError
	{
		return getObject ( key, new simpleFactory () );
	}

	*//**
	 * Get an object from the DB based on its unique key.
	 * @param key
	 * @return a basic topology object
	 * @throws GocTopoError 
	 *//*
	public <T extends CpeBaseTopoObject> T getObject ( String key, Class<T> clazz ) throws GocTopoNotFound, GocTopoError
	{
		return getObject ( key, new CpeAutoFactory<T> ( this, clazz ) );
	}

	*//**
	 * Get an object from the DB based on its unique key and using the provided factory to 
	 * instantiate the object.
	 * @param key
	 * @param factory
	 * @return an object
	 * @throws GocTopoError
	 *//*
	public <T extends GocTopoObject> T getObject ( String key, GocTopoObject.TopoObjectFactory<T> factory ) throws GocTopoNotFound, GocTopoError
	{
		try
		{
			final JSONObject o = fFlatiron.get ( key );
			if ( o == null )
			{
				throw new FlatironObjectNotFoundException ( key );
			}
			return factory.createFrom ( key, o );
		}
		catch ( FlatironObjectNotFoundException e )
		{
			throw new GocTopoNotFound ( e );
		}
		catch ( FlatironException e )
		{
			throw new GocTopoError ( e );
		}
	}

	*//**
	 * Search for objects with the given value in the given field. Note that Flatiron requires that an index
	 * is established on the field before this search.
	 * 
	 * @param field
	 * @param value
	 * @return a map of matching objects with object keys as the map key.
	 * @throws GocTopoNotFound
	 * @throws GocTopoError
	 *//*
	public Map<String,CpeBaseTopoObject> search ( String field, String value ) throws GocTopoNotFound, GocTopoError
	{
		return search ( field, value, new simpleFactory () );
	}

	*//**
	 * Search for objects with the given value in the given field, and use the factory to instantiate the results.
	 * @param field
	 * @param value
	 * @param factory
	 * @return
	 * @throws GocTopoNotFound
	 * @throws GocTopoError
	 *//*
	public <T extends CpeBaseTopoObject> Map<String,T> search ( String field, String value, GocTopoObject.TopoObjectFactory<T> factory ) throws GocTopoNotFound, GocTopoError
	{
		try
		{
			final HashMap<String,T> result = new HashMap<String,T>();
			final Map<String,JSONObject> results = fFlatiron.search ( field, value );
			for ( Entry<String, JSONObject> e : results.entrySet () )
			{
				result.put ( e.getKey(), factory.createFrom ( e.getKey(), e.getValue () ) );
			}
			return result;
		}
		catch ( FlatironObjectNotFoundException e )
		{
			throw new GocTopoNotFound ( e );
		}
		catch ( FlatironException e )
		{
			throw new GocTopoError ( e );
		}
	}

	public List<String> getInboundRelations ( CpeBaseTopoObject obj, String reln ) throws GocTopoNotFound, GocTopoError
	{
		try
		{
			final LinkedList<String> result = new LinkedList<String> ();
			final Collection<FlatironRelation> related = fFlatiron.getInboundRel ( obj.getKey(), reln );
			for ( FlatironRelation fr : related )
			{
				result.add ( fr.getFromOid () );
			}
			return result;
		}
		catch ( FlatironObjectNotFoundException e )
		{
			throw new GocTopoNotFound ( e );
		}
		catch ( FlatironException e )
		{
			throw new GocTopoError ( e );
		}
	}

	public List<String> getOutboundRelations ( CpeBaseTopoObject obj, String reln ) throws GocTopoNotFound, GocTopoError
	{
		try
		{
			final LinkedList<String> result = new LinkedList<String> ();
			final Collection<FlatironRelation> related = fFlatiron.getOutboundRel ( obj.getKey(), reln );
			for ( FlatironRelation fr : related )
			{
				result.add ( fr.getToOid () );
			}
			return result;
		}
		catch ( FlatironObjectNotFoundException e )
		{
			throw new GocTopoNotFound ( e );
		}
		catch ( FlatironException e )
		{
			throw new GocTopoError ( e );
		}
	}

	

	private class simpleFactory implements GocTopoObject.TopoObjectFactory<CpeBaseTopoObject>
	{
		@Override
		public CpeBaseTopoObject createFrom ( String key, JSONObject data ) throws GocTopoInvalid
		{
			return new CpeBaseTopoObject ( CCEDemoDb.this, key, data)
			{
			};
		}
	}*/
	
	private final FlatironClient fFlatiron;

	public FlatironClient getFlatiron ()
	{
		return fFlatiron;
	}
}
