package com.att.javatest;


import java.util.Date;
import java.util.TimeZone;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class Dt2 {
	private static String dateTimeFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS+00:00";
	
	public static void main(String[] args) {

		//SimpleDateFormat df3 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss zzz");
		//SimpleDateFormat df4 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss:SSS z");
		//String fFromFormat = "MM/dd/yyyy HH:mm:ss:SSS";
		
		//String fFromFormat = "MM/dd/yyyy HH:mm:ss z";
		
		// Wed, 13 Jul 2016 19:11:12 GMT+00:00
		String fFromFormat = "EEE, d MMM yyyy HH:mm:ss z'+00:00'";
		
	
		SimpleDateFormat df4 = new SimpleDateFormat(fFromFormat);
		df4.setTimeZone(TimeZone.getTimeZone("GMT"));
		long date = 1454113680000L;
		System.out.println(" -- " + df4.format(new Date(date)));
		
		final SimpleDateFormat sdf2 = new SimpleDateFormat(dateTimeFormat);
		sdf2.setTimeZone(TimeZone.getTimeZone("UTC"));
		System.out.println(" UTC --> " + sdf2.format(new Date()));
		
		Date d = new Date();
		String val = "02/11/2016 15:54:00 UTC";
		try {
			d = df4.parse(val);
		}
		catch ( ParseException e )
		{
			System.out.println("ParseException. Failed to parse val: " + val + " with format: " + fFromFormat + "." );
		}
		catch ( Exception e )
		{
			System.out.println("Exception. Failed to parse val: " + val + " with format: " + fFromFormat + "." );
		}

		//System.out.println(" now = " + df3.format(now) + ".");
		final long plannedTimeMs = d.getTime();
		System.out.println(" plannedTimeMs = " + plannedTimeMs + ".");
		final long nowMs = System.currentTimeMillis();
		System.out.println(" nowMs = " + nowMs + ".");
		final long diff = (plannedTimeMs - nowMs)/1000;
		final int diffInt = (int) (plannedTimeMs - nowMs)/1000;
		if ( diff > 0 ) {
			System.out.println(" diff = " + diff + ".");
		}
		else {
			System.out.println(" agingSeconds can't be -ve.");
			System.out.println(" diff = " + diff + ".");
		}
		System.out.println(" diffInt = " + diffInt + ".");
	}

}
