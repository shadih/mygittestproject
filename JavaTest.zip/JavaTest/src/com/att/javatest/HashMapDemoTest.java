package com.att.javatest;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import com.att.javatest.HashMapDemo.Entry;


public class HashMapDemoTest {

	static HashMapDemo hmd;
	static HashMap<String,HashMap<String,LinkedList<Entry>>> fEntries;

	public static void main(String[] args) {
		hmd = new HashMapDemo();
		fEntries = hmd.genEntry("setname1", "innerName1", 1000);
		fEntries = hmd.genEntry("setname2", "innerName2", 2000);

		for(Map.Entry<String, HashMap<String,LinkedList<Entry>>> Entry : fEntries.entrySet()) {
			System.out.println("Processing fEntrie with key = " + Entry.getKey());
			HashMap<String,LinkedList<Entry>> innerHM = Entry.getValue();
			for(Map.Entry<String,LinkedList<Entry>> iEntry: innerHM.entrySet() ) {
				System.out.println("Processing innerHM with key = " + iEntry.getKey());
				LinkedList<Entry> innerLL = iEntry.getValue();
				for (int i = 0; i < innerLL.size(); i++) {
					System.out.println("innerLL element " + i + " --> " + innerLL.get(i).toString());
				}
			}
		}
	}


}
