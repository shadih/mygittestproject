/**
 * 
 */

function validate() {
         if( document.ChangeCDRAlarmSettings.cdrChangeType.value == "byEP" &&
             document.ChangeCDRAlarmSettings.device_hostname.value == "" )
         {
            alert( "Please provide a non null Endpoint/Router" );
            document.ChangeCDRAlarmSettings.device_hostname.focus() ;
            return false;
         } else {
             return true;
         }
      }


function validate() {
    if( document.ChangeCDRAlarmSettings.bcd_thrshld.value == "" )
    {
       alert( "Please provide a non null Endpoint/Router" );
       document.ChangeCDRAlarmSettings.bcd_thrshld.focus() ;
       return false;
    } else {
        return true;
    }
 }

function validate() {
	var elem = document.getElementById('ChangeCDRAlarmSettings').elements;
	        for(var i = 0; i < elem.length; i++) {
	        	document.write("hello " + elem[i].value + "ok");
	           if ( elem[i].value == "" ) {
			alert(elem[i].name + " cannot be null ");
			elem[i].name.focus();
			return false;
	           }
	        }
}

