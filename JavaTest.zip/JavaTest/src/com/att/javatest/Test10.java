package com.att.javatest;

public class Test10 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("testing Testinit...");
		Testinit.send();
		Testinit.send();
		Testinit.send();
	}

}
