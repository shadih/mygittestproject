package com.att.javatest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class TailingFile {

	public static void main(String[] args) {
		System.out.println("Starting..");
		int initCnt = 10;
		String txt = "main text";
		
		KeepTailing kt = new KeepTailing();
		kt.keepTailing();
		
		System.out.println("back to main()..");
		
		while (true) {
			System.out.println("in main: " + txt + " " + initCnt);
			initCnt++;
			
			try {
				Thread.sleep(4000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
}
