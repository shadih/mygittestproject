package com.att.javatest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class DcaeSyslogColSpecsReader {

	public static void main(String[] args) {

		try {

			JSONObject jo = new JSONObject ( new JSONTokener ( new FileInputStream ( new File ( "dcae-syslog-col-specs.json" ) ) ) );

			JSONObject parameters = null;
			JSONArray appConfig = null;
			JSONArray collectors = null;
			JSONArray otherConfig = null;
			String flatironHost = null;

			if ( jo.has("parameters") ) {
				parameters = jo.getJSONObject("parameters");
			} else {
				System.out.println("ERROR" + "Missing \"parameters\" JSON object. Exiting");
				System.exit(1);
			}

			System.out.println ("> parameters -> " + parameters.toString() + " <\n\n");

			if ( parameters.has("app_config") ) {
				appConfig = parameters.getJSONArray("app_config");
			} else {
				System.out.println("ERROR" + "Missing \"app_config\" JSON Array. Exiting");
				System.exit(1);
			}

			//System.out.println ("> app_config -> " + appConfig.toString() + " <\n");

			if ( parameters.has("collectors") ) {
				collectors = parameters.getJSONArray("collectors");
			} else {
				System.out.println("ERROR" + "Missing \"collectors\" JSON Array. Exiting");
				System.exit(1);
			}

			//System.out.println ("> collectors -> " + collectors.toString() + " <\n");

			if ( parameters.has("other_config") ) {
				otherConfig = parameters.getJSONArray("other_config");
			} else {
				System.out.println("ERROR" + "Missing \"other_config\" JSON Array. Exiting");
				System.exit(1);
			}

			//System.out.println ("> otherConfig -> " + otherConfig.toString() + " <\n");

			for (int i = 0; i < appConfig.length(); i++) {
				//System.out.println(" appConfig " + i + " - > " + appConfig.get(i).toString());
				//System.out.println("");
				JSONObject appConfigJo = (JSONObject) appConfig.get(i);
				//System.out.println("name -> " + appConfigJo.getString("name"));
				//System.out.println("value -> " + appConfigJo.getString("value"));
				if ( appConfigJo.getString("name").equalsIgnoreCase("DcaeIpHost.FlatironServers")) {
					flatironHost = appConfigJo.getString("value");
				}	
			}
			
			for (int i = 0; i < collectors.length(); i++) {
				//System.out.println(" collectors " + i + " - > " + collectors.get(i).toString());
				//System.out.println("");
				JSONObject collectorsJo = (JSONObject) collectors.get(i);
				//System.out.println("collectorsJo name -> " + collectorsJo.getString("name"));
				JSONArray collectorVal = collectorsJo.getJSONArray("value");
				//System.out.println("collectorsJo value-> " + collectorVal.toString());
				//System.out.println(" collectorVal " + i + " - > " + collectorVal.toString());
				for (int j = 0; j < collectorVal.length(); j++) {
					JSONObject collectorValJo = (JSONObject) collectorVal.get(j);
					//System.out.println(" collectorValJo name " + j + " - > " + collectorValJo.get("name"));
					//System.out.println(" collectorValJo value " + j + " - > " + collectorValJo.get("value"));
					System.out.println(collectorValJo.get("name") + "=" + collectorValJo.get("value") +".");
				}
				System.out.println();
			}

			if ( null != flatironHost ) {
				System.out.println("\nDcaeIpHost.FlatironServers=" + flatironHost + ".");
			} else {
				System.out.println("ERROR" + "Missing DcaeIpHost.FlatironServers. Exiting");
				System.exit(1);
			}

		}
		catch (Exception e) {
			System.out.println("exp = " );
			e.printStackTrace();
		}
	}
}
