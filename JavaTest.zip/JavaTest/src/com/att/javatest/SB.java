package com.att.javatest;

public class SB {

	private static StringBuilder sb = new StringBuilder();
	
	public static void main(String[] args) {
		
		
		sb.append("test1");
		
		System.out.println("sb1 = " + sb.toString());
		
		sb = new StringBuilder();
		
		sb.append("test2");
		
		System.out.println("sb2 = " + sb.toString());
		
		sb = new StringBuilder();
		
		if ( sb.length() == 0 ) {
			System.out.println("sb 0 len = ");
		}

	}

}
