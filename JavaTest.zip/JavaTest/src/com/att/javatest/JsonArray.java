package com.att.javatest;

import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonArray {


	static JSONObject mainJson = null;
	static HashMap<String,String> UEBAlarmFieldsMapping = new HashMap<String,String>(); 
	static HashMap<String,String> Logs = new HashMap<String,String>();
	
	
	public static void main(String[] args) {

		try {
		
			mainJson = new JSONObject(new JSONTokener(new FileReader("aots-cm-PlannedStartTimeReached-event1.json")));
			JSONArray validAssetTypes = mainJson.getJSONArray("validAssetTypes");
			JSONTokener jt = new JSONTokener(mainJson.getJSONObject("change-ticket").toString());
			JSONObject jb = new JSONObject(jt);
			//JSONArray changeAssetList = mainJson.getJSONObject("change-ticket").getJSONObject("change-asset-list").getJSONArray("change-asset");
			JSONArray changeAssetList = jb.getJSONObject("change-asset-list").getJSONArray("change-asset");
			boolean isMatchingAssetType = false;
			for (int i = 0; i < changeAssetList.length(); i++) {
				String assetType = changeAssetList.getJSONObject(i).getJSONObject("asset-data").getString("asset-type");
				String assetId = changeAssetList.getJSONObject(i).getString("asset-id");
				System.out.println(" assetId-id -- " + assetId + ".");
				System.out.println(" assetType -- " + assetType + ".\n");
				if ( !isMatchingAssetType && validAssetTypes.toString().contains(assetType) ) {
					isMatchingAssetType = true;
					System.out.println(" -- isMatchingAssetType --" + isMatchingAssetType);
				}
			}
			
			//		getJSONArray("validAssetTypes");
			System.out.println("validAssetTypes -> " + validAssetTypes.toString() + "\n\n");
			System.out.println("changeAssetList -> " + changeAssetList.toString());
			/*System.out.println("testA 0 -> " + testA.getString(0));
			if ( testA.toString().contains("perver")) {
				System.out.println("ok -> ");
			}*/
			
		}
		catch (Exception e) {
			System.out.println("exp = " );
			e.printStackTrace();
		}
		

	}
	

}
