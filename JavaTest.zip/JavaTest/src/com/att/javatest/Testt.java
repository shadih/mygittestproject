package com.att.javatest;

public class Testt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stublog.info("This event: neighborIp2 = " + neighborIp);
		String neighborIp = "149.0.4.17";
		
		String[] octets = neighborIp.split("/.");
		System.out.println("-- " + octets[0] + ".");
	}

}
