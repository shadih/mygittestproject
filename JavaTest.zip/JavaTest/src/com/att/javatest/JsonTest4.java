package com.att.javatest;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonTest4 {

	public static void main(String[] args) throws JSONException, FileNotFoundException {

		//String str2 = "{\"eventId\":\"127.0.0.1\",\"sourceInstance\":\"127.0.0.1\",\"eventSourceHostname\":\"UNKNOWN\",\"Priority\":\"190\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Oct 18 22:39:38\",\"eventSourceHost\":\"USATT1NJMUSVVHP001\",\"syslogProc\":\"node-upload\",\"syslogProcId\":\"2499\",\"syslogTag\":\"\",\"isVCO\":\"\",\"syslogMsg\":[{\\\"source\":\"EDGE\",\"event\":\"EDGE_SERVICE_FAILED\",\"category\":\"EDGE\",\"severity\":\"ERROR\",\"message\":\"Service edged failed with error -6, restarting\",\"detail\":null,\"eventTime\":\"2016-10-18T22:38:25.577Z\",\"enterpriseUserId\":null,\"enterpriseUsername\":null,\"edgeId\":192,\"edgeName\":\"finance-edge-ptr45\",\"linkId\":null,\"enterpriseId\":1,\"enterpriseName\":\"ATT-sndc-coke-customer1\",\"enterpriseObjectId\":null,\"enterpriseObjectName\":null,\"linkName\":null}],\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Dec 14 20:12:09 2016\",\"otherRuleName\":\"VELOCLOUD_EDGE_LINK\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"otherCollector\":\"dcaelocal-dev-01\"}";
		
		//String str2 = "{\"eventId\":\"127.0.0.1\", \"test\":\"}";
		
		//String str2 = "{<134>Jan 11 09:10:45 USATT1NJMUSVVHP002 node-upload[15801]: info: [control.148411000.3890] [15801] 10.10.101.102 {\"params\": {\"gwBgpNeighbors\": {\"startEntryIdx\": 0, \"bgpNeighborSummary\": [{\"state\": \"Established\", \"neighborIp\": \"10.10.101.1\", \"msgSent\": \"57238\", \"neighborAS\": \"13979\", \"enterpriseLogicalId\": \"aae974d3-2140-41e4-a4d9-e4f0d60fc73d\", \"msgRcvd\": \"60009\", \"pfxRcvd\": \"14\", \"upDownTime\": \"02w5d19h\"}], \"totalEntries\": 1, \"dispEntries\": 1}, \"logicalId\": \"gateway8d4dea39-9696-4b7c-bad7-c289c88d3e38\", \"crlNumber\": \"0\", \"dataCenterVpnStates\": [], \"utilization\": 0.325, \"endpointPkiMode\": \"CERTIFICATE_DISABLED\", \"actionUpdates\": [], \"serviceUpSince\": 1482431619446, \"serviceState\": \"IN_SERVICE\", \"systemUpSince\": 1474987038000, \"softwareVersion\": \"2.3.0\", \"endpointTrustedIssuerVersion\": \"0\", \"buildNumber\": \"R23-20161206-RC4\", \"deviceId\": \"52:54:00:e8:0f:67\", \"utilizationDetail\": {\"load\": 0.1275, \"overall\": 0.325, \"cpu\": 0.13, \"memory\": 0.325}, \"connectedEdgeList\": [{\"vceid\": \"474946ac-4da7-40be-9073-4e8dca823241\"}, {\"vceid\": \"5922ffcf-9e0d-4c6b-a211-aad42f75699b\"}], \"configuration\": [{\"version\": \"1476657588540\", \"module\": \"controlPlane\"}, {\"version\": \"1470248625031\", \"module\": \"managementPlane\"}, {\"version\": \"1\", \"module\": \"imageUpdate\"}], \"events\": [], \"token\": {\"logicalId\": \"gateway8d4dea39-9696-4b7c-bad7-c289c88d3e38\", \"hmac\": \"5c3aaf875c6c3d31b2b9d1e88b2133e0cd13e1bf69b00df2343f46854caa0881\"}, \"connectedEdges\": 2}, \"jsonrpc\": \"2.0\", \"method\": \"ga\"}";

		//String str2 = "{\"eventId\":\"135.25.157.169\",\"sourceInstance\":\"135.25.157.169\",\"eventSourceHostname\":\"UNKNOWN\",\"Priority\":\"134\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Jan 11 10:52:45\",\"eventSourceHost\":\"USATT1NJMUSVVHP002\",\"syslogProc\":\"node-upload\",\"syslogProcId\":\"15935\",\"syslogTag\":\"\",\"isVCO\":\"\",\"syslogMsg\":\"\"params\": {\"gwBgpNeighbors\": {\"startEntryIdx\": 0, \"bgpNeighborSummary\": [{\"state\": \"Established\", \"neighborIp\": \"10.10.101.1\", \"msgSent\": \"57442\", \"neighborAS\": \"13979\", \"enterpriseLogicalId\": \"aae974d3-2140-41e4-a4d9-e4f0d60fc73d\", \"msgRcvd\": \"60223\", \"pfxRcvd\": \"14\", \"upDownTime\": \"02w5d21h\"}], \"totalEntries\": 1, \"dispEntries\": 1}, \"logicalId\": \"gateway8d4dea39-9696-4b7c-bad7-c289c88d3e38\", \"crlNumber\": \"0\", \"dataCenterVpnStates\": [], \"utilization\": 0.325, \"endpointPkiMode\": \"CERTIFICATE_DISABLED\", \"actionUpdates\": [], \"serviceUpSince\": 1482431619446, \"serviceState\": \"IN_SERVICE\", \"systemUpSince\": 1474987038000, \"softwareVersion\": \"2.3.0\", \"endpointTrustedIssuerVersion\": \"0\", \"buildNumber\": \"R23-20161206-RC4\", \"deviceId\": \"52:54:00:e8:0f:67\", \"utilizationDetail\": {\"load\": 0.12875, \"overall\": 0.325, \"cpu\": 0.125, \"memory\": 0.325}, \"connectedEdgeList\": [{\"vceid\": \"474946ac-4da7-40be-9073-4e8dca823241\"}, {\"vceid\": \"5922ffcf-9e0d-4c6b-a211-aad42f75699b\"}], \"configuration\": [{\"version\": \"1476657588540\", \"module\": \"controlPlane\"}, {\"version\": \"1470248625031\", \"module\": \"managementPlane\"}, {\"version\": \"1\", \"module\": \"imageUpdate\"}], \"events\": [], \"token\": {\"logicalId\": \"gateway8d4dea39-9696-4b7c-bad7-c289c88d3e38\", \"hmac\": \"5c3aaf875c6c3d31b2b9d1e88b2133e0cd13e1bf69b00df2343f46854caa0881\"}, \"connectedEdges\": 2}, \"jsonrpc\": \"2.0\", \"method\": \"\",\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Jan 11 15:49:59 2017\",\"otherRuleName\":\"VELOCLOUD_EDGE_LINK\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"otherCollector\":\"zltcmtc3njcoll01\"}";

		//String str2 = "{\"eventId\":\"135.25.157.68\",\"sourceInstance\":\"135.25.157.68\",\"eventSourceHostname\":\"UNKNOWN\",\"Priority\":\"190\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Jan 11 15:51:01\",\"eventSourceHost\":\"USATT1NJMUSVVHP001\",\"syslogProc\":\"node-backend\",\"syslogProcId\":\"22749\",\"syslogTag\":\"\",\"isVCO\":\"\",\"syslogMsg\":[{ start: Wed Jan 11 2017 10:00:00 GMT+0000 (UTC),\n  end: Wed Jan 11 2017 11:59:59 GMT+0000 (UTC) } most recent interval: { start: Wed Jan 11 2017 12:00:00 GMT+0000(UTC),\n  end: Wed Jan 11 2017 13:59:59 GMT+0000 (UTC) }],\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Jan 11 15:49:31 2017\",\"otherRuleName\":\"VELOCLOUD_EDGE_LINK\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"otherCollector\":\"zltcmtc3njcoll01\"}";
		
		//String str2 = "{\"eventId\":\"107.250.172.53\",\"sourceInstance\":\"107.250.172.53\",\"eventSourceHostname\":\"ZRDM1MMSC04ALB002\",\"Priority\":\"182\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Jan 4 19:14:43\",\"eventSourceHost\":\"ZRDM1MMSC04ALB002\",\"syslogProc\":\"\",\"syslogProcID\":\"ssl_req\",\"syslogTag\":\"\",\"syslogMsg\":\"-0800] 127.0.0.1 TLSv1 AES256-SHA \"/iControl/iControlPortal.cgi\" 637\",\"syslogSData\":\"\",\"startEpochMicrosec\":\"Thu Jan 5 03:14:45 2017\",\"otherSiteId\":\"RDM\",\"otherSiteInst\":\"1\",\"otherElementTp\":\"MMSC\",\"otherElementInst\":\"04\",\"otherSubElementTp\":\"ALB\",\"otherSubElementInst\":\"002\"}";
		//String str2 = "{\"eventId\":\"135.25.157.68\",\"sourceInstance\":\"135.25.157.68\"}";
		
		String str2 = "{\"eventId\":\"107.250.173.67\",\"sourceInstance\":\"107.250.173.67\",\"eventSourceHostname\":\"UNKNOWN\",\"Priority\":\"135\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"2017-01-11T15:24:19+00:00\",\"eventSourceHost\":\"ZRDM2MOGX04OAM001\",\"syslogProc\":\"qps\",\"syslogProcID\":\"\",\"syslogTag\":\"\",\"syslogMsg\":[{ GeoHA: Adding Lb instance status map to memcache is: {ZRDM2MOGX04={ZRDM2MOGX04MPD002-2=true, ZRDM2MOGX04MPD001-2=true}, ZRDM2MOGX03={ZRDM2MOGX03MPD001-2=true, ZRDM2MOGX03MPD002-2=true}}],\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Jan 11 15:24:20 2017\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\"}";
		
		System.out.println(" BEFORE str2 -> " + str2); System.out.println();


		try {

			JSONObject jo = new JSONObject(str2);
			System.out.println(" OK-> " + str2);

		} catch (JSONException e) {
			System.out.println("updateJson JSONException: " + e);

		}
	}
}
