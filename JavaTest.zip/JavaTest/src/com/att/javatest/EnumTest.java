package com.att.javatest;


public class EnumTest {
	
	public enum DeviceType
	{
		UCPE ( "pserver" ),
		VM ( "vserver" ),
		JCP ( "SW" ),
		VROUTER ( "RT" ),
		JDM ( "ZZ" ),
		VWANX ( "WX" ),
		PROUTER ( "pnf", "tbd" ),
		NONE ( "" );

		private DeviceType ( String type )
		{
			typeVal = type;
		}
		
		private DeviceType ( String type, String type2 )
		{
			System.out.println(" type -- : " + type);
			System.out.println(" type2 -- : " + type2);
			if ( type.equals("pnf") ) { typeVal = type; }
			else { typeVal = type2; }
		}

		public String getTypeValue ()
		{
			return typeVal;
		}

		private String typeVal;
	};
	

	public static void main(String[] args) {
		
		String entity_type = "sd"; String device_type = "ZZ"; 
		System.out.println(" entity_type : " + entity_type + " device_type " + device_type);
		System.out.println(" ret : " + getDeviceType(entity_type, device_type));
	}
	

	public static DeviceType getDeviceType ( String entity_type, String device_type )
	{
		String type = "";
		if ( entity_type.equals("pnf") || device_type.equals("TBD") )
		{
			type = "pnf";
		}
		else
		{
			type = device_type;
		}
		
		for ( DeviceType aType : DeviceType.values () )
		{
			
			System.out.println(" aType : " + aType);
			System.out.println(" aType.getTypeValue () : " + aType.getTypeValue ());
			if ( aType.getTypeValue ().equals ( type ) )
			{
				
				return aType;
			}
		}
		return DeviceType.VM;
	}


}
