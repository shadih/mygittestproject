package com.att.javatest;

public class TypeTest {

	public static void main(String[] args) {
		System.out.println("creating new Type");
		Object t = new Type();
		System.out.println("t is: " + t.getClass());
		if ( t instanceof Type ) {
			System.out.println("is instanceof Type");
		}
	}

}

class Type {
	Type() {
		
	}
	
	
}
