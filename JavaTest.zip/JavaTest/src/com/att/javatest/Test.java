package com.att.javatest;

import java.util.*;
import java.io.*;


public class Test {

	//public static Hashtable<String, ArrayList<Integer>> cfo_chronic_ht = new Hashtable<String, ArrayList<Integer>>();
	public static Hashtable<String, List<Long>> cfo_chronic_ht = new Hashtable<String, List<Long>>();
	
	
	public static void main(String[] args) {
		String alertid1 = "50002/100/52-10.215.180.201/VPLS:277831";

		
	while (true ) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Enter be1a: ");
        Long be1a = null;
        try {
        	be1a = Long.valueOf(reader.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        } 
        System.out.println("You entered : " + be1a);

        if ( be1a == 000) {
        	break;
        }

		if ( cfo_chronic_ht.get(alertid1) == null) {
			List<Long> be = new ArrayList<Long>();
			be.add(be1a);
			cfo_chronic_ht.put(alertid1, be);
			//send alarm
			System.out.println("Send alarm1");
		}
		else {
			if ( cfo_chronic_ht.get(alertid1).size() < 3 ) {
				cfo_chronic_ht.get(alertid1).add(be1a);
				
				//send alarm
				System.out.println("Send alarm2");
			}
			else {
				Long ts1 = cfo_chronic_ht.get(alertid1).get(0);
				Long ts2 = cfo_chronic_ht.get(alertid1).get(1);
				Long ts3 = cfo_chronic_ht.get(alertid1).get(2);
				
				Long currTime =  System.currentTimeMillis() / 1000 ;
				Long twelveHoursAgo = currTime - 43200;
				System.out.println("curr = " + currTime);
				System.out.println("12 hours ago = " + twelveHoursAgo);
				if ( ( ts1 > twelveHoursAgo) && ( ts2 > twelveHoursAgo) && ( ts3 > twelveHoursAgo) ) {
					//suppress alarm
					System.out.println("Sup alarm");
				}
				else {
					//send alarm
					System.out.println("Send alarm3");
					cfo_chronic_ht.get(alertid1).add(be1a);
					cfo_chronic_ht.get(alertid1).remove(0);
				}
			}
		}
		//be.remove(0);
		for (int i=0; i<cfo_chronic_ht.get(alertid1).size(); i++){
			System.out.println("List element " + i + " = " + cfo_chronic_ht.get(alertid1).get(i));
		}
	}

	}

}
