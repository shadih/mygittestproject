package com.att.javatest;

import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonArray2 {
	
	private static final String SITE_TAG = "site";
	
	public static void main(String[] args) {

			String json = "{\"services_calls\":{},\"streams_subscribes\":{},\"site2.hostip\":\"https://identity-aic.rdm32.cci.att.com:5000/v2.0\",\"site1.hostip\":\"https://identity-aic.rdm3.cci.att.com:5000/v2.0\",\"streams_publishes\":{\"publish-sdnleventcol-alarm\":{\"aaf_username\":\"m06680@highlandPark.dcae.att.com\",\"dmaap_info\":{\"topic_url\":\"https://dcae-msrt-mtl5-ftl2.homer.att.com:3905/events/com.att.dcae.dmaap.FTL2.DCAE-SDNL-CONTRAIL-ALARM-EVENT\",\"location\":\"mtl5\",\"client_id\":\"1500559629719\",\"client_role\":\"com.att.dcae.member\"},\"type\":\"message_router\",\"aaf_password\":\"2018Open06680\"},\"publish-sdnleventcol-uve\":{\"aaf_username\":\"m06680@highlandPark.dcae.att.com\",\"dmaap_info\":{\"topic_url\":\"https://dcae-msrt-mtl5-ftl2.homer.att.com:3905/events/com.att.dcae.dmaap.FTL2.DCAE-SDNL-CONTRAIL-UVE-EVENT\",\"location\":\"mtl5\",\"client_id\":\"1500559629720\",\"client_role\":\"com.att.dcae.member\"},\"type\":\"message_router\",\"aaf_password\":\"2018Open06680\"}},\"site1\":\"AIC_LAB_RDM5B\",\"site2\":\"AIC_LAB_RDM5B2\"}";
			
			try {
				
				String objData = "{ \"streams_subscribes\": {}, \"streams_publishes\": { \"sdnlocal-vetl\": { \"type\": \"data_router\", \"dmaap_info\": { \"publish_url\": \"https://dcae-drps-ftl.homer.att.com/publish/756\", \"username\": \"mtl1-0\", \"publisher_id\": \"sdnlocal-vetl\", \"log_url\": \"https://dcae-drps-ftl.homer.att.com/publish/logs\", \"location\": \"zldccfc1njcoll01.research.att.com\", \"password\": \"13su4sltbgl35lsntcp1ertoev\" } } }, \"services_calls\": {}, \"site1\": \"Sdn_Lab_RDM5B\", \"site1.hostip\": \"sdn-l-analytics-aic.rdm5b.cci.att.com\", \"site1.keyStoneURL\": \"https://identity-aic.rdm3.cci.att.com:5000/v2.0\", \"site1.computeURL\": \"https://compute-aic.rdm3.cci.att.com:8774/v2/\", \"site1.keyStoneTenant\": \"admin\", \"site1.keyStoneUser\": \"m17598\", \"site1.keyStonePad\": \"LowDensity1026\", \"site1.authflag\": false, \"site1.port\": \"8081\", \"site1.protocol\": \"https\", \"site1.freq_ms\": \"300\", \"site1.csvStreamId\": \"sdnlocal-vetl\", \"site1.jsonStreamId\": \"sdnlocal-json\", \"site1.targetFileDirectory\": \"/tmp/dcae\", \"site1.httpProxy\": \"one.proxy.att.com\", \"site1.timeoutConnection\": \"17000\", \"site1.timeoutSocket\": \"17000\", \"site1.threadpool_Size\": \"25\", \"site1.threadpool_timeout_min\": \"5\", \"site1.alternate_port\": \"8081\", \"site1.usedmaap\": \"Y\", \"site2\": \"Dashboard_Lab_RDM3\", \"site2.hostip\": \"dashboard-aic.rdm3.cci.att.com\", \"site2.keyStoneURL\": \"https://identity-aic.rdm3.cci.att.com:5000/v2.0\", \"site2.computeURL\": \"https://compute-aic.rdm3.cci.att.com:8774/v2/\", \"site2.keyStoneTenant\": \"admin\", \"site2.keyStoneUser\": \"m17598\", \"site2.keyStonePad\": \"LowDensity1026\", \"site2.authflag\": false, \"site2.port\": \"8081\", \"site2.protocol\": \"https\", \"site2.freq_ms\": \"300\", \"site2.csvStreamId\": \"sdnlocal-vetl\", \"site2.jsonStreamId\": \"sdnlocal-json\", \"site2.targetFileDirectory\": \"/tmp/dcae\", \"site2.httpProxy\": \"one.proxy.att.com\", \"site2.timeoutConnection\": \"17000\", \"site2.timeoutSocket\": \"17000\", \"site2.threadpool_Size\": \"25\", \"site2.threadpool_timeout_min\": \"5\", \"site2.alternate_port\": \"8081\", \"site2.usedmaap\": \"Y\" }"; 

				
				JSONObject jo = new JSONObject( new JSONTokener(objData));
				String o = getDynamicConfigParameters(jo);
				System.out.println(" OUT " + o.toString());
			} catch (JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("ERROR");
			}
			
			
	}
	
			public static String getDynamicConfigParameters( final JSONObject configJsonObject ) { 
				final String methodName = "getDynamicConfigParameters()"; 
		 
				String dynamicConfigString = ""; 
		 
				if ( configJsonObject == null ) { 
					 System.out.println("configJsonObject is empty!"); 
					 return dynamicConfigString; 
				} 
		 
		 
				dynamicConfigString = "{ \"sites\": [ "; 
				int siteNumber = 0; 
				try { 
		 
					while ( true ) { 
		 
						siteNumber ++; 
						String siteNum = "site" + siteNumber; 
						String siteName = null;
						if ( configJsonObject.has(siteNum) ) {
							siteName = configJsonObject.getString(siteNum);
						}
						 
						if ( siteName == null ) { 
							// no more new site. break the loop 
							break; 
						} 
		 
						System.out.println(siteNum + " name = " + siteName); 
		 
						String hostip =  (String) configJsonObject.get(siteNum + ".hostip"); 
						String keyStoneURL =  (String) configJsonObject.get(siteNum + ".keyStoneURL"); 
						String computeURL =  (String) configJsonObject.get(siteNum + ".computeURL"); 
						String keyStoneTenant =  (String) configJsonObject.get(siteNum + ".keyStoneTenant"); 
						String keyStoneUser =  (String) configJsonObject.get(siteNum + ".keyStoneUser"); 
						String keyStonePad =  (String) configJsonObject.get(siteNum + ".keyStonePad"); 
						boolean authflag =  (Boolean) configJsonObject.get(siteNum + ".authflag"); 
						String port =  (String) configJsonObject.get(siteNum + ".port"); 
						String protocol =  (String) configJsonObject.get(siteNum + ".protocol"); 
						String freq_ms =  (String) configJsonObject.get(siteNum + ".freq_ms"); 
						String csvStreamId =  (String) configJsonObject.get(siteNum + ".csvStreamId"); 
						String jsonStreamId =  (String) configJsonObject.get(siteNum + ".jsonStreamId"); 
						String targetFileDirectory =  (String) configJsonObject.get(siteNum + ".targetFileDirectory"); 
						String httpProxy =  (String) configJsonObject.get(siteNum + ".httpProxy"); 
						String timeoutConnection =  (String) configJsonObject.get(siteNum + ".timeoutConnection"); 
						String timeoutSocket =  (String) configJsonObject.get(siteNum + ".timeoutSocket"); 
						String threadpool_Size =  (String) configJsonObject.get(siteNum + ".threadpool_Size"); 
						String threadpool_timeout_min =  (String) configJsonObject.get(siteNum + ".threadpool_timeout_min"); 
						String alternate_port =  (String) configJsonObject.get(siteNum + ".alternate_port"); 
						String usedmaap =  (String) configJsonObject.get(siteNum + ".usedmaap"); 
		 
					    dynamicConfigString += "{\"hostip\"" + ": " + "\"" + hostip + "\",";
						dynamicConfigString += " \"keyStoneURL\"" + ": " + "\"" + keyStoneURL + "\","; 
						dynamicConfigString += " \"computeURL\"" + ": " + "\"" + computeURL + "\","; 
						dynamicConfigString += " \"keyStoneTenant\"" + ": " + "\"" + keyStoneTenant + "\","; 
						dynamicConfigString += " \"keyStoneUser\"" + ": " + "\"" + keyStoneUser + "\","; 
						dynamicConfigString += " \"keyStonePad\"" + ": " + "\"" + keyStonePad + "\","; 
						dynamicConfigString += " \"authflag\"" + ": " + "\"" + authflag + "\","; 
						dynamicConfigString += " \"port\"" + ": " + "\"" + port + "\","; 
						dynamicConfigString += " \"protocol\"" + ": " + "\"" + protocol + "\","; 
						dynamicConfigString += " \"freq_ms\"" + ": " + "\"" + freq_ms + "\","; 
						dynamicConfigString += " \"csvStreamId\"" + ": " + "\"" + csvStreamId + "\","; 
						dynamicConfigString += " \"jsonStreamId\"" + ": " + "\"" + jsonStreamId + "\","; 
						dynamicConfigString += " \"targetFileDirectory\"" + ": " + "\"" + targetFileDirectory + "\","; 
						dynamicConfigString += " \"httpProxy\"" + ": " + "\"" + httpProxy + "\","; 
						dynamicConfigString += " \"timeoutConnection\"" + ": " + "\"" + timeoutConnection + "\","; 
						dynamicConfigString += " \"timeoutSocket\"" + ": " + "\"" + timeoutSocket + "\","; 
						dynamicConfigString += " \"threadpool_Size\"" + ": " + "\"" + threadpool_Size + "\","; 
						dynamicConfigString += " \"threadpool_timeout_min\"" + ": " + "\"" + threadpool_timeout_min + "\","; 
						dynamicConfigString += " \"alternate_port\"" + ": " + "\"" + alternate_port + "\","; 
						dynamicConfigString += " \"usedmaap\"" + ": " + "\"" + usedmaap + "\""; 
		 
						dynamicConfigString += "},"; 
		 
					} // end of while loop 
		 
					if ( dynamicConfigString.length() >= 20 ) { 
						dynamicConfigString = dynamicConfigString.substring(0, dynamicConfigString.length() -1 ); 
					} else { 
						// something is not correct in second url call 
					} 
					dynamicConfigString += "] }"; 
		 
					System.out.println("totalSites = " + (siteNumber - 1) ); 
					System.out.println("dynamicConfigString = " + dynamicConfigString ); 
		 
				} catch (Exception e) { 
					e.printStackTrace();
					System.out.println("Exception while attempting to getDynamicConfigParameters using config: : " + 
							configJsonObject.toString() + ". Exiting."); 
					System.out.println("getDynamicConfigParameters: Exception while attempting to update dynamic configuration using config: " + 
							configJsonObject.toString() + ". Exiting. " + e.toString()); 
					System.exit(1); 
				} 
		 
				return dynamicConfigString; 
			}		


}
