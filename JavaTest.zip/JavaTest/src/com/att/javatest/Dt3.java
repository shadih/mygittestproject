package com.att.javatest;


import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.io.File;
import java.io.FilenameFilter;

public class Dt3 {

	private static String basefileName = null;
	
	public static void main(String[] args) {
		
		String input = "C:/tmp/tmp3/evcReport";
		String dir = input.substring(0, input.lastIndexOf("/"));
		basefileName = input.substring(input.lastIndexOf("/")+1, input.length());
		
		System.out.println(" input " + input + " dir " + dir + " basefileName " + basefileName + ".");
	
		File[] listOfFiles = new File(dir).listFiles(new EvcFileFilter());
		//long maxAge = 7 * 24 * 60 * 60 * 1000;
		long maxAge = 10 * 1000;
		
		for (File f : listOfFiles) {
			System.out.println("Checking filename: " + f.getName() + ".");
			long fileAge = new Date().getTime() - f.lastModified();
			if ( fileAge > maxAge ) {
				System.out.println("Deleting filename: " + f.getName() + ".");
				if ( f.delete() ) {
					System.out.println("Done\t" + f.getName());
				}
				else {
					System.out.println("Failed\t" + f.getName());
				}
			}
		}
/*		
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyy.MM.dd");
		System.out.println("today = \t" + df.format(date));
		
		int j = 8;
		File dirFl = new File(dir);
		
	
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DAY_OF_MONTH, -j);
			String daysBefore = df.format(cal.getTimeInMillis());
			
			System.out.println(j + " dayBefore = \t" + daysBefore);
			String fileName = dir+"."+daysBefore;
			System.out.println("Checking fileName = \t" + fileName);*/
			
		
/*			
			if ( fileName.exists() ) {
				System.out.println("Deleting fileName = \t" + fileName);
				if ( fileName.delete() ) {
					System.out.println("Done\t" + fileName);
				}
				else {
					System.out.println("Failed\t" + fileName);
				}
			}*/
			
		//	j++;
			
		
		
/*		for (int i=1; i <= 7; i++) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DAY_OF_MONTH, -i);
			String daysBefore = df.format(cal.getTimeInMillis());
			System.out.println(i + " dayBefore = \t" + daysBefore);
			
			String fileName = basefileName+"."+daysBefore;
			System.out.println("Checking fileName = \t" + fileName);
			
			File fl = new File(fileName);
			if ( fl.exists() ) {
				System.out.println(" file " + fileName + " exists");
			}
			else {
				System.out.println(" file " + fileName + " does not exist");
			}
		}*/

	}
	
	public static class EvcFileFilter implements FilenameFilter {

		@Override
		public boolean accept(File dir, String fileName) {
			if ( fileName.contains(basefileName) ) {
				return true;
			}
			else {
				return false;
			}
			
		}
	}

}


