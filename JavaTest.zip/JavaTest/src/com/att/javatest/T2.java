package com.att.javatest;



public class T2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String managedObjectInstance = "SLOT 12.80.0.39/0";
		String ip = managedObjectInstance.split(" ")[1].split("/")[0];

		System.out.println(" ip " + ip + " --");

		//String comp = "Slot=&lt;2&gt; Interface Bridge: Slot 2 Group #1, Link: Slot 2 Port #29";
		String comp = "Slot=<2> Interface Bridge: Slot 2 Group #1, Link: Slot 2 Port #29";

		String[] fields =  comp.split(" ");

		for (String field : fields) {
			System.out.println(" field = " + field);
			if (field.contains("=")) {
				String[] keyValues = field.split("\\=");
				if ( "slotname".equalsIgnoreCase(keyValues[0]) ) {
					if(keyValues.length > 1) {
						System.out.println("parseComponentField(alarm): Found slotname field seperated by = "
								+ keyValues[1]);
						//alarm.setSlotName(keyValues[1]);
					}
				}

				if ("Slot".equalsIgnoreCase(keyValues[0])) {
					System.out.println("parseComponentField(alarm): Found slot field seperated by = "
							+ keyValues[1]);
					//alarm.setSlot(keyValues[1]);
				}
			}
		}
	}

}
