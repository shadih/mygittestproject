package com.att.javatest;

public class Testparse {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
    	String assetId = "dpa2r03c005.san3.cci.att.com";
    	System.out.println("assetId -- " + assetId + " --");
    	assetId = assetId.substring(0, assetId.indexOf("."));
    	
    	System.out.println("assetId -- " + assetId + " --");

	}

}
