package com.att.javatest;

public class Testinit {
	
	String test = "testing";
	static int i = 0;
	
	static {
		init();
	}
	
	private static void init() {
		
		String testinit = "testing in init()";
		System.out.println(" in init()");
		i++;
		
	}
	
	static void send() {
		System.out.println(" in send(), i = " + i);
	}

}
