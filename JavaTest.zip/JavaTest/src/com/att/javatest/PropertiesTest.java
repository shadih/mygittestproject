package com.att.javatest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;
import java.util.Enumeration;
import java.util.List;

public class PropertiesTest {

	public static void main(String[] args) {
		
		FileInputStream fin = null;
		OutputStream out = null;
		
		try {
			fin = new FileInputStream("Collector.properties");
			Properties props = new Properties();
			props.load(fin);
			//fin.close();
			System.out.println("LOADED: \n" + props.toString() );
			// count the number of collectors
			Enumeration em = props.keys();
			int i = 0;
			while ( em.hasMoreElements() ) {
				if ( em.nextElement().toString().matches("COLLECTOR\\d+\\.name.*") ) {
					i++;
				}
				//if ( em.nextElement().toString().contains("COLLECTOR") ) {
				//	i++ ;
				//}
				//System.out.println("key -->" + em.nextElement() + "--");
			}
			System.out.println("Num of collectors -->" + i + "--");
			
			props.setProperty("COLLECTOR1.name", "NEW");
			System.out.println("LOADED2: \n" + props.toString() );
			
			
			out = new FileOutputStream( new File("Collector.properties"));
			props.store(out, "Dynamically updated Collector.properties");
			
		}
		catch(Exception e) {
			System.out.println("Exception while loading properties file Collector.properties... Exiting.");
			e.printStackTrace();
			System.exit(1);
		} finally {
			if ( fin != null ) {
				try {
					fin.close();
				} catch (IOException e) {
					System.out.println("Exception while closing properties Collector.properties file . Exiting.");
					e.printStackTrace();
					System.exit(1);
				}
			}
			if ( out != null ) {
				try {
					out.close();
				} catch (IOException e) {
					System.out.println("Exception while closing updated properties Collector.properties file . Exiting.");
					e.printStackTrace();
					System.exit(1);
				}
			}
		}

	}

}
