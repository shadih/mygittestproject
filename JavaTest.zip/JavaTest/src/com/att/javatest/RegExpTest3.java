package com.att.javatest;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class RegExpTest3 {

	private static Pattern fPattern;

	private static List<String> fFields;
	static final String kSetting_Fields = "fields";

	public static void main(String[] args) {

		//String component = "deviceType=<> deviceModel=<> OSPF Neighbor State local ospfRouterId = 12.82.219.11, neighbor IP = 12.82.219.154, neighbor ospfRouterId = 12.82.219.1, PortAID=<xe-0/0/0>, PortLagId=<ae0>";
		//String component = "deviceType=<test> deviceModel=<testing d> OSPF Neighbor State local ospfRouterId = 12.82.219.11, neighbor IP = 12.82.219.154, neighbor ospfRouterId = 12.82.219.1";
		String component = "deviceType=<> deviceModel=<JUNIPR ER       G> OSPF Neighbor State local ospfRouterId = 12.82.219.11, neighbor IP = 12.82.219.154,";
		System.out.println("component -- " + component + " --"); 
		String devMd = "No deviceModel Match";
		//Pattern dvMdPtrn = Pattern.compile("deviceModel=\\<(.+?)\\>");
		Pattern dvMdPtrn = Pattern.compile("deviceModel=<(.+?)>");
		Matcher dvMdMatcher = dvMdPtrn.matcher(component);

		if ( dvMdMatcher.find() )  {
			devMd = dvMdMatcher.group(1);
			System.out.println("dvMdMatcher.group(1) -- " +devMd + " --");
		} 

		System.out.println("\ndevMd -- " + devMd + " --\n"); 
		
		System.out.println("\nNEW devMd -- " + getDevMd(component) + " --\n"); 
		System.out.println("\nNEW devTp -- " + getDeviceType(component) + " --\n"); 
	}	

	public static String getDevMd (String component) {

		String ndevMd = "No deviceModel Match";
		int startingIndex = component.indexOf("deviceModel=<") + "deviceModel=<".length();
		System.out.println("startingIndex -- " + startingIndex + " --\n"); 
		if (startingIndex != -1) {			
			int endingIndex = component.indexOf(">", startingIndex);
			System.out.println("endingIndex -- " + endingIndex + " --\n"); 
			if (endingIndex != -1) {
				ndevMd = component.substring(startingIndex, endingIndex);				
				System.out.println("ndevMd -- "  + ndevMd + " --");				 
			}		        		 
		}
		if ( ndevMd == null || ndevMd.isEmpty() ) {
			ndevMd = "No deviceModel Match";
		}
		
		return ndevMd;
	}


	public static String getDeviceType(String component) {
		
		String devTp = "No deviceType Match";
		int startingIndex = component.indexOf("deviceType=<") + "deviceType=<".length();
		if (startingIndex != -1) {			
			int endingIndex = component.indexOf(">", startingIndex); 
			if (endingIndex != -1) {
				devTp = component.substring(startingIndex, endingIndex);							 
			}		        		 
		}
		if ( devTp == null || devTp.isEmpty() ) {
			devTp = "No deviceType Match";
		}
		return devTp;
	}




}
