package com.att.javatest;


import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class Dt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Date date = new Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		//System.out.println("date = " + df.format(date));
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, -1);
		String dayBefore = df.format(cal.getTimeInMillis());
		System.out.println("date = " + dayBefore + " --");
		String jsonSqlqry = "ms_part_$PREVIOUSDAY";
		String toReplace = "PREVIOUSDAY";
		String sqlqry = jsonSqlqry.replaceAll("$"+toReplace, dayBefore);
    	System.out.println("SQL Query : " + sqlqry + " ...");
    	int tot = 2966304;
    	//int cnt1 = 2458320;
    	int cnt1 = 2966304;
    	int diff = tot - cnt1;
    	//double y = ((i1-i2)/i2)*100;
		double percent = 0;
		percent = ( ( (double) diff ) / ( (double) tot ) ) *100;
		String result = String.format("%.1f", percent);
		
		System.out.println(" pre = " + result + " ...");
		
		SimpleDateFormat df3 = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss zzz");
		Date now = new Date();
		System.out.println(" now = " + df3.format(now) + ".");
		String str2 = "t1";
		int ii = 123;
		String test1 = new String();
		test1+=("<td align=\"center\">" + str2 + " -- ");
		test1+=(" add " + ii);
		System.out.println(" test 1 = " + test1 + " ...");
		
	}

}
