package com.att.javatest;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.lang.ArrayIndexOutOfBoundsException;


public class RegExpTest2 {

	public static void main(String[] args) {

		String origReason = "CycleTime=3; AFI=1; SAFI=4; NumberRoutes=10; BGPLabel/LDPLoopback=524280 32.120.255.10/32,524281 32.120.255.11/32,524282 32.120.255.12/32,524283 32.120.255.13/32,524284 32.120.255.14/32,524285 32.120.255.15/32,524286 32.120.255.16/32,524287 32.120.255.17/32,524288 32.120.255.18/32,524289 32.120.255.19/32; NextHop= 10.40.4.206,10.40.4.207; RR_IP=12.122.8.3; suboption_info=,";

		String[] reasonInfo2And3 = origReason.split("\\;");

		String numberRoutes = ""; String addInfo2 = ""; String addInfo3 = "";

		try {
			numberRoutes = reasonInfo2And3[3];
			addInfo2 = reasonInfo2And3[4];
			addInfo3 = reasonInfo2And3[5];

		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBoundsException Error while parsing out received reason text: " + origReason);
			e.printStackTrace();
			return;
		} catch (Exception e) {
			System.out.println("Error while parsing out received reason text: " + origReason);
			e.printStackTrace();
			return;
		}

		System.out.println("origReason -> " + origReason);
		System.out.println("");
		System.out.println("field 4 or numberRoutes -> " + numberRoutes + ".");
		System.out.println("");

		Matcher m;

		m = Pattern.compile ( "NumberRoutes=(\\d+).*" ).matcher ( numberRoutes ); 

		if ( m.find() ) { 
			System.out.println("number of routes -> " + m.group(1) + ".");
		} else {
			System.out.println("number of routes could not be parsed out");
		}

		System.out.println("");
		System.out.println("field 5 or addInfo2 -> " + addInfo2 + ".");
		System.out.println("");
		
		String[] info2Fields = addInfo2.split("\\s");

		try {

			for (String infoField : info2Fields ) {
				System.out.println("infoField -> " + infoField + ".");
				m = Pattern.compile ( "(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}).*" ).matcher ( infoField );
				if ( m.find() ) { 
					String ipToReplace = m.group(1);
					System.out.println("matched IP to replace -> " + ipToReplace + "."); 
					addInfo2 = addInfo2.replaceAll(ipToReplace, ipToReplace+"test");
				} else {
					System.out.println("No matched IP");
				}
			}

			System.out.println("Updated addInfo2 -> " + addInfo2 + ".");

		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBoundsException Error while parsing out BGPLabel/LDPLoopback from reason text: " + origReason);
			e.printStackTrace();
			return;
		} catch (Exception e) {
			System.out.println("Error while parsing out BGPLabel/LDPLoopback from reason text: " + origReason);
			e.printStackTrace();
			return;
		}
		
		System.out.println("");
		System.out.println("field 6 or addInfo3 -> " + addInfo3 + ".");
		System.out.println("");
		
		String[] info3Fields = addInfo3.split("\\,");

		try {

			for (String infoField : info3Fields ) {
				System.out.println("infoField -> " + infoField + ".");
				m = Pattern.compile ( "(\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}).*" ).matcher ( infoField );
				if ( m.find() ) { 
					String ipToReplace = m.group(1);
					System.out.println("matched IP to replace -> " + ipToReplace + "."); 
					addInfo3 = addInfo3.replaceAll(ipToReplace, ipToReplace+"test");
				} else {
					System.out.println("No matched IP");
				}
			}

			System.out.println("Updated addInfo3 -> " + addInfo3 + ".");

		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBoundsException Error while parsing out BGPLabel/LDPLoopback from reason text: " + origReason);
			e.printStackTrace();
			return;
		} catch (Exception e) {
			System.out.println("Error while parsing out BGPLabel/LDPLoopback from reason text: " + origReason);
			e.printStackTrace();
			return;
		}


	}



}
