package com.att.javatest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonObjectFromFile {


	public static void main(String[] args) {

		try {
			
			JSONObject jo = new JSONObject ( new JSONTokener ( new FileInputStream ( new File ( "syslog-col-dmaap-config.json" ) ) ) );
			
			JSONObject dmaapInfo = null;
			
			if ( jo.has("publish_syslogs_secure") && 
					!jo.getJSONObject("publish_syslogs_secure").isNull("topic_url") &&
					!jo.getJSONObject("publish_syslogs_secure").isNull("dmaapUserName") &&
					!jo.getJSONObject("publish_syslogs_secure").isNull("dmaapPassword")
					) {
				dmaapInfo = jo.getJSONObject("publish_syslogs_secure");
			} else {
				System.out.println("ERROR" + " Can't read DMaaP info from publish_syslogs_secure json config key. Exiting");
				System.exit(1);
			}
			
			
			System.out.println ("> dmaapInfo -> " + dmaapInfo.toString() + " <");
			
			String dmaapHost = null;
			String dmaapTopic = null;
			String dmaapUserName = null;
			String dmaapPasswd = null;
			String dmaapProtocol = null;
			
			if ( dmaapInfo.has("topic_url") && !dmaapInfo.getString("topic_url").isEmpty() ) {
				String urlParts[] = dmaapInfo.getString("topic_url").split("/");
				
				dmaapProtocol = urlParts[0].substring(0, urlParts[0].length() - 1);
				dmaapHost = urlParts[2];
				dmaapTopic = urlParts[4];
				dmaapUserName = dmaapInfo.getString("dmaapUserName");
				dmaapPasswd = dmaapInfo.getString("dmaapPassword");
				
				System.out.println(">dmaapProtocol=" + dmaapProtocol + "<>dmaapHost=" + dmaapHost + 
						"<>dmaapTopic=" + dmaapTopic + "<>dmaapUserName=" + dmaapUserName + "<>dmaapPasswd=" + dmaapPasswd + "<");
			} else {
				System.out.println("ERROR" + " Can't read topic_url DMaaP info from publish_syslogs_secure json config key. Exiting");
				System.exit(1);
			}

		}
		catch (Exception e) {
			System.out.println("exp = " );
			e.printStackTrace();
		}
	}
}
