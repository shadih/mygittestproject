package com.att.javatest;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class RegExpTest {

	private static Pattern fPattern;
	
	private static List<String> fFields;
	static final String kSetting_Fields = "fields";
	
    public static void main(String[] args) {
    	
    	
    	//String value = "dpa2r03c015.els-an.att.net";
    	
    	String value = "dpa2r03c015_sdrg_sdsf.sdsdf/wddff";
    	//String value = "dpa2r03c015.testing";
    	//String value = "dpa2r03c015";
    	//String value = "vnfName=enpx0001v.els-an.att.net";
    	//String value = "minor/major";
    	//String value = "minor";
    	//String fRegex = "(.*)(?:.els-an.att.net|.nelab.els.att.net)";
    	//String fRegex = "(.*?)\\.*.*";
    	
    	//String fRegex = "([^\\.]+).*";
    	//String fRegex = ".*vnfName=([^\\.]+).*";
    	
    	//String fRegex = "([^\\.]+).*";
    	
    	String fRegex = "([^\\/]+).*";
    	
    	//String fRegex = "(.*?)\\.(?:.*)";
    	fPattern = Pattern.compile ( fRegex );
    	
    	System.out.println("4: " + value + " --" + fPattern + " --");
    	
    	final Matcher m = fPattern.matcher ( value ); 
    	
    	if ( m.matches() ) { System.out.println("ok");}
    	
    	if ( m.matches () && m.groupCount () > 0 )
		{
			final String result = m.group ( 1 );    
			System.out.println( " result --> "  + result + " .");
		}
    	
    	String[] fchangeAssetJson;
    	String str = "change-ticket.change-asset-list.change-asset.asset-id.asset-data.asset-type";
    	fchangeAssetJson = str.split("\\.");
    	System.out.println("Using changeAssetArrayLocation  :" + Arrays.toString(fchangeAssetJson));
	 
    	long nowMs = System.currentTimeMillis();
    	System.out.println(" nowMs -> " + nowMs);
    	int nowSec = (int) nowMs;
    	System.out.println(" nowSec -> " + nowSec);
    }
    


}
