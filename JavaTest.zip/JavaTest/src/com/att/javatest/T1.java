package com.att.javatest;

import java.security.SecureRandom;
import java.util.UUID;
import java.io.*;

public class T1 {

	public void processFile(String fName) throws FileNotFoundException,
	IOException {
		FileInputStream fis = null;

		try {
			fis = new FileInputStream(fName);
			int sz;
			byte[] byteArray = new byte[10];
			while ((sz = fis.read(byteArray)) != -1) {
				//processBytes(byteArray, sz);
			}
		}
		finally {
			if (fis != null) {
				safeClose(fis);
			}
		}
	}
	public static void safeClose(FileInputStream fis) {
		if (fis != null) {
			try {
				fis.close();
			} catch (IOException e) {
				//log(e);
			}
		}
	}

}

