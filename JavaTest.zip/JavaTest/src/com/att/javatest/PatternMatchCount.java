package com.att.javatest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.regex.Pattern;
import java.util.regex.Matcher;;

public class PatternMatchCount {

	public static void main(String[] args) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(args[0]));
			String line = "";
			int line_cnt = 0;
			
			while ( (line = reader.readLine()) != null ) {
				line_cnt++;
				line.replaceAll("\"", "\\\"");
				System.out.println(" line number = " + line_cnt);
	            Pattern aciPattern = Pattern.compile("AlarmCreationInterface");
	            //Pattern betsPattern = Pattern.compile("be_time_stamp");
	            Pattern betsPattern = Pattern.compile("<customField value=\"\\d+\" name=\"be_time_stamp\"/>");
	           // Pattern p2 = Pattern.compile("be_time_stamp");
	    		Matcher aciMatcher = aciPattern.matcher(line);
	    		Matcher betsMatcher = betsPattern.matcher(line);
	    		
	    		int aciMatchCount = 0; int betsMatchCount = 0;
	    		
	    		while (aciMatcher.find()){
	    			aciMatchCount++;
	    		}
	    		while (betsMatcher.find()){
	    			betsMatchCount++;
	    			System.out.println("Matched be_time_stamp = " + betsMatcher.group() + " --");
	    		}
	    		System.out.println(" aciMatchCount = " + aciMatchCount + " betsMatchCount = " + betsMatchCount + ".");

			}
			reader.close();
		}
		catch (Exception e) {
			System.out.println("caught excep = " + e);
			e.printStackTrace();
			
		}
	}	
}
