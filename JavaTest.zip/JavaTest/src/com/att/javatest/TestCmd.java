package com.att.javatest;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;

public class TestCmd {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			String perlOp;
		    Process proc = Runtime.getRuntime().exec(args[0]) ;
		    //Process proc = Runtime.getRuntime().exec("perl /home/ns317q1/ipag/testTTS.pl");
		    int wf = proc.waitFor();
		    //int exitVal = proc.exitValue();
		    InputStream is = null;
		    is = proc.getInputStream();
		    int intAvail = is.available();
		    byte inBuff[] = new byte[intAvail] ;
		    int intRead = is.read(inBuff, 0, intAvail);
		    perlOp = new String(inBuff);
		    if ( wf == 0 ) {
		    	System.out.println("Cmd ran ok:");
		    	System.out.println("perl output=" + perlOp + "---");
		    }
		    else {
		    	System.out.println("error runnning cmd, exit val = " + wf);
		    }
		}
		catch(IOException ioe) {
		    // for exec()
			 System.out.println("Command execution failed=" + ioe );
		    ioe.printStackTrace();
		}
		catch(InterruptedException ie) {
		    // for waitFor()
			System.out.println("Command execution 2 failed=" + ie );;
		    ie.printStackTrace();
		}
		catch(Exception e) {
		    // for waitFor()
			System.out.println("Command execution 3 failed=" + e );;
		    e.printStackTrace();
		}

	}

}
