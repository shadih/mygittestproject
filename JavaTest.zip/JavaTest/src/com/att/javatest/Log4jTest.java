package com.att.javatest;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class Log4jTest {

	private static final Logger log = LoggerFactory.getLogger( "debugLogger" );
	private static final Logger errorLog = LoggerFactory.getLogger( "errorLogger" );
	//private static final Logger auditLog = LoggerFactory.getLogger( "auditLogger" );
	//private static final Logger metricLog = LoggerFactory.getLogger( "metricLogger" );

	public static void main(String[] args) {
		
		int i=0;
		while ( i < 5) {
			log.info("TestINF " + i + "..");
			errorLog.info("TestERR " + i + "..");
			i++;
		}
	}
}
