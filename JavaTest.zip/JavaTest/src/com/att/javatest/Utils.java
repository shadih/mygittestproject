package com.att.javatest;

import java.util.HashMap;
import java.util.Map;


public class Utils {
	
	//Create HashMap
	static Map<String , Integer> alarmObjectType = new HashMap<String, Integer>();
	 
	static {
	//Add Key/Value pairs
	
	alarmObjectType.put("Major", 1);
/*	alarmObjectType.put("PE_Device", "DEVICE");
	alarmObjectType.put("DEVICE", "DEVICE");
	alarmObjectType.put("CE_Card", "CARD");
	alarmObjectType.put("PE_Card", "CARD");
	alarmObjectType.put("CARD", "CARD");
	alarmObjectType.put("CE_Slot", "SLOT");
	alarmObjectType.put("PE_Slot", "SLOT");
	alarmObjectType.put("SLOT", "SLOT");
	alarmObjectType.put("CE_PPort", "PPORT");
	alarmObjectType.put("PE_PPort", "PPORT");
	alarmObjectType.put("PPORT", "PPORT");
	alarmObjectType.put("CE_LPort", "LPORT");
	alarmObjectType.put("PE_LPort", "LPORT");
	alarmObjectType.put("LPORT", "LPORT");
	alarmObjectType.put("EVCNode", "EVC");
	alarmObjectType.put("EVC", "EVC");
	alarmObjectType.put("Tunnel", "TUNNEL");
	alarmObjectType.put("TUNNEL", "TUNNEL");
*/
	}
    
    //find element using key
 //   System.out.println("Becca's Marks:: "+alarmObjectType.get("Becca"));
    
    //remove element
 //   alarmObjectType.remove("Becca");
    
    //Iterate over HashMap
//    for(String key: alarmObjectType.keySet()){
 //       System.out.println(key  +" :: "+ alarmObjectType.get(key));
 //   }
	
//	alarmObjectType.put("CE_Device", "DEVICE");
	
/*

 CE_Device*DEVICE
 PE_Device*DEVICE
 CE_Card*CARD
 PE_Card*CARD
 CE_Slot*SLOT
 PE_Slot*SLOT
 CE_PPort*PPORT
 PE_PPort*PPORT
 CE_LPort*LPORT
 PE_LPort*LPORT
 EVCNode*EVC
 Tunnel*TUNNEL



 */

}
