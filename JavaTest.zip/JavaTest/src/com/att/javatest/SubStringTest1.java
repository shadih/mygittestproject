package com.att.javatest;


import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.io.File;
import java.io.FilenameFilter;

public class SubStringTest1 {

	private static String basefileName = null;
	
	public static void main(String[] args) {
		
		String input1 = "event: update";
		String input2 = "data: {\"type\": \"XmppPeerInfoData\", \"value\": {\"state_info\": {\"last_state\": \"Active\", \"state\": \"Established\", \"last_state_at\": 1499787850199942}, \"peer_stats_info\": {\"tx_proto_stats\": {\"notification\": 0, \"update\": 448, \"close\": 0, \"total\": 47922, \"open\": 1, \"keepalive\": 47473}, \"tx_update_stats\": {\"unreach\": 72, \"total\": 448, \"reach\": 590, \"end_of_rib\": 0}, \"rx_proto_stats\": {\"notification\": 0, \"update\": 138, \"close\": 0, \"total\": 47751, \"open\": 1, \"keepalive\": 47612}, \"rx_update_stats\": {\"unreach\": 4, \"total\": 66, \"reach\": 62, \"end_of_rib\": 0}, \"rx_error_stats\": {\"inet6_error_stats\": {\"bad_inet6_xml_token_count\": 0, \"bad_inet6_prefix_count\": 0, \"bad_inet6_nexthop_count\": 0, \"bad_inet6_afi_safi_count\": 0}}}, \"identifier\": \"rdm3r30c014.rdm3.cci.att.com\", \"event_info\": {\"last_event_at\": 1499787850199058, \"last_event\": \"xmsm::EvXmppOpen\"}, \"send_state\": \"in sync\"}, \"key\": \"ObjectXmppPeerInfo:zrdm3ccnt01.rdm3.cci.att.com:172.29.8.36\"}";
		
		System.out.println(" input : --\n" + input2 + "--\n");
		int index = input2.indexOf("{");
		String data = input2.substring(input2.indexOf("{"), input2.length());
		System.out.println("\nindex : --" + index + "--");
		
		System.out.println(" data : --\n" + data + "--\n");
		
		//String dir = input.substring(0, input.lastIndexOf(\"/\"));
		//basefileName = input.substring(input.lastIndexOf(\"/\")+1, input.length());
		
		//System.out.println(\" input \" + input + \" dir \" + dir + \" basefileName \" + basefileName + \".\");

	}

}


