package com.att.javatest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class KeepTailing {

	int initCnt;
	String txt;

	public KeepTailing() {
		initCnt = 1;
		txt = "thread text";
	}

	public void keepTailing() {

		try {
			Thread thread = new Thread(new Runnable()
					{
						public void run () 
						{
							boolean keepReading = true;
							BufferedReader br = null;
							while (keepReading) {

								try {
									br = new BufferedReader(new FileReader("inputfile"));
								}
								catch (IOException e) 
								{
									System.out.println("Problem reading BufferedReader. IOException" + e.toString());
									e.printStackTrace();
									System.exit(1);
								} 
								catch ( Exception e) 
								{
									System.out.println("Exception" + e.toString());
									e.printStackTrace();
									System.exit(1);
								}

								while (keepReading){
									String line = "";

									try {
										line = br.readLine();
										if ( null == line ||  line.isEmpty() ) 
										{
											Thread.sleep(2000);
										}
										else if ( line.startsWith("LASTLINE")) {
											keepReading = false;
											br.close();
										}
										else {
											System.out.println("in THREAD, LN -> " + line);
										}
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									} catch (InterruptedException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}

								}
							}
							
						}
					});
			
			thread.start();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
}
