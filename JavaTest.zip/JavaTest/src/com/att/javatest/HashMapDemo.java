package com.att.javatest;

import java.util.HashMap;
import java.util.LinkedList;

public class HashMapDemo {

	private final HashMap<String,HashMap<String,LinkedList<Entry>>> fEntries;
	HashMap<String,LinkedList<Entry>> innerHM;
	LinkedList<Entry> innerLL;
	
	public HashMapDemo () {
		System.out.println("HashTest Consrtruction");
		
		fEntries = new HashMap<String,HashMap<String,LinkedList<Entry>>> ();
		innerHM = new HashMap<String,LinkedList<Entry>>();
		innerLL = new LinkedList<Entry>();
	}
	
	public HashMap<String,HashMap<String,LinkedList<Entry>>> genEntry (String setName, String innerName, long timestampMs){
		Entry eo = new Entry(timestampMs);
		innerLL.add(eo);
		innerHM.put(innerName, innerLL);
		fEntries.put(setName, innerHM);
		
		return fEntries;
	}

	public class Entry
	{
		public Entry ( long timestampMs )
		{
			fExpireAtMs = timestampMs;
		}

		@Override
		public String toString ()
		{
			return "" + fExpireAtMs;
		}

		@Override
		public int hashCode ()
		{
			return toString ().hashCode ();
		}

		@Override
		public boolean equals ( Object obj )
		{
			if ( obj instanceof HashMapDemo.Entry )
			{
				return obj.toString ().equals ( toString () );
			}
			return false;
		}

		private final long fExpireAtMs;
	}
}
