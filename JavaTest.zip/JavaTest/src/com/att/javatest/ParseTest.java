package com.att.javatest;

import java.util.ArrayList;

public class ParseTest {

	private static ArrayList<String> g2Names = new ArrayList<String>();
	private static ArrayList<Integer> g2Ports = new ArrayList<Integer>();

	public static void main(String[] args) {
		String DSL_G2_DOMAINS = "DSL01:19401,DSL02:19402,DSL03:19403";
		String[] splitDomains = DSL_G2_DOMAINS.split(",");
		for (int i = 0; i < splitDomains.length; i++) {
			System.out.println("elem[" + i + "] = " + splitDomains[i] + " -- ");
			String[] domainAndPort = splitDomains[i].split(":");
			//System.out.println("\t domainAndPort[0]" +  domainAndPort[0] + " -- ");
			//System.out.println("\t domainAndPort[1]" +  domainAndPort[1] + " -- ");
			g2Names.add(domainAndPort[0]);
			g2Ports.add(Integer.valueOf(domainAndPort[1]));
		}
	
	
	for (String domain: g2Names) {
		System.out.println("domain = " + domain + " --");
	}
	
	for (int port: g2Ports) {
		System.out.println("port = " + port + " --");
	}
	
	}
}
