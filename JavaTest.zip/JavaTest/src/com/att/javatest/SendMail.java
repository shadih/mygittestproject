package com.att.javatest;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;


public class SendMail {

	public static void main(String[] args) {
		System.out.println("sending mail...");
		
		String repFileName = "reports/CorrReport.20141128.html";
		String detRepFileName = "reports/DetailedCorrReport.20141128.html";
		String tmpFile = "uuencodeTemp";
		String uuencode = "/bin/uuencode";
		String mailx = "/bin/mailx";
		String subject = "Correlation Report for day from env";
		String mailTo = "sh1986@att.com,shadi.h1@hotmail.com";
		
		ArrayList<String[]> mailCommands = new ArrayList<String[]>();

		String uuencodeCmd1Cli = uuencode + " " + repFileName + " " + repFileName + " > " + tmpFile;
		String[] uuencodeCmd1 = {"/bin/sh", "-c", uuencodeCmd1Cli};
		mailCommands.add(uuencodeCmd1);
		String uuencodeCmd2Cli = uuencode + " " + detRepFileName + " " + detRepFileName + " >> " + tmpFile;
		String[] uuencodeCmd2 = {"/bin/sh", "-c", uuencodeCmd2Cli};
		mailCommands.add(uuencodeCmd2);
		String mailCmdCli = "cat " + tmpFile + " | " + mailx + " -s \"" + subject + "\" \"" + mailTo + "\"";
		String[] mailCmd = {"/bin/sh", "-c", mailCmdCli};
		mailCommands.add(mailCmd);
		
		Iterator<String[]> mailCommandsIterator = mailCommands.iterator();
		while (mailCommandsIterator.hasNext()) {
			String[] cmd = mailCommandsIterator.next();
		
			System.out.print("Running command: "+ Arrays.toString(cmd) + "...");
		
			String cmdOut = runCli(cmd);
			if ( cmdOut.equals("OK") ) {
				System.out.println(cmdOut);
			}
			else {
				System.out.print("ERROR: \n");
				System.out.println(cmdOut);
			}
		}

	}
	
	public static String runCli(String[] cmd) {
 
		String cmdOutput = "";
		BufferedReader reader = null;;
		BufferedReader readerStdErr = null;
		
		try {
			Process proc = Runtime.getRuntime().exec(cmd);
			
            reader 		= new BufferedReader (new InputStreamReader(proc.getInputStream()));
            readerStdErr = new BufferedReader (new InputStreamReader(proc.getErrorStream()));
            String line = "";
            
            while ( (line = reader.readLine()) != null ) {
            	cmdOutput+=(line + "\n");
            }
            while ( (line = readerStdErr.readLine()) != null ) {
            	cmdOutput+=(line + "\n");
            }

			int wf = proc.waitFor();
			
			if ( wf == 0 ) {
				cmdOutput = "OK";
			}
		}
		catch (Exception e) {
			System.out.println("Error in sending mail runCli, Exception = " + e);
			e.printStackTrace();
		}
		
		try {
			reader.close();
			readerStdErr.close();
		}
		catch (Exception e) {
			System.out.println("Error in closing BufferedReaders in runCli, Exception = " + e);
			e.printStackTrace();
		}
		
		return cmdOutput;
			
	}

}
