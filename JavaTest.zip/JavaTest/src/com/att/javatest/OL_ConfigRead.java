package com.att.javatest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class OL_ConfigRead {


	public static void main(String[] args) {

		try {
			String appDir = "overlandCore/";
			JSONArray jArray = new JSONArray ( new JSONTokener (
					new FileInputStream ( new File ( appDir + "etc/overlandConfigFiles.json" ) ) ) );

			StringBuilder cfgFileStr = new StringBuilder ();
			cfgFileStr.append ( appDir + "etc/overland.json" );
			for ( int i = 0; i < jArray.length (); i++ )
			{
				cfgFileStr.append ( "," );
				cfgFileStr.append ( appDir + jArray.getString ( i ) );
			}

			String[] ovlndArgs = { "-c", cfgFileStr.toString (), "-p", "8088" };
			for (String ovlndArg : ovlndArgs ) {
				System.out.println("ovlndArg --> " + ovlndArg + ".");
			}
		}
		catch (Exception e) {
			System.out.println("exp = " );
			e.printStackTrace();
		}
	}
}
