package com.att.javatest;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonTest2 {

	public static void main(String[] args) throws JSONException, FileNotFoundException {

/*		String jsonStr = 
				"{\"eventId\":\"127.0.0.1\",\"sourceInstance\":\"127.0.0.1\",\"eventSourceHostname\":\"UNKNOWN\","
						+ "\"Priority\":\"190\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Sep 13 13:34:01\","
						+ "\"eventSourceHost\":\"zrdm3fcmd01cmd001\",\"syslogProc\":\"syslog-ng\",\"syslogProcID\":\"19575\","
						+ "\"syslogTag\":\"\",\"syslogMsg\":\"Connection broken; time_reopen='60'\",\"syslogSData\":\"\","
						+ "\"startEpochMicrosec\":\"Wed Sep 21 14:47:28 2016\",\"otherSiteId\":\"unknown\","
						+ "\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\","
						+ "\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"other\":\"\"}";*/
		
		//String jsonStr = "{\"eventId\":\"127.0.0.1\",\"sourceInstance\":\"127.0.0.1\",\"eventSourceHostname\":\"UNKNOWN\",\"Priority\":\"190\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Oct 18 22:39:38\",\"eventSourceHost\":\"USATT1NJMUSVVHP001\",\"syslogProc\":\"node-upload\",\"syslogProcId\":\"2499\",\"syslogTag\":\"\",\"syslogMsg\":[{\"source\":\"EDGE\",\"event\":\"EDGE_SERVICE_FAILED\",\"category\":\"EDGE\",\"severity\":\"ERROR\",\"message\":\"Service edged failed with error -6, restarting\",\"detail\":null,\"eventTime\":\"2016-10-18T22:38:25.577Z\",\"enterpriseUserId\":null,\"enterpriseUsername\":null,\"edgeId\":192,\"edgeName\":\"finance-edge-ptr45\",\"linkId\":null,\"enterpriseId\":1,\"enterpriseName\":\"ATT-sndc-coke-customer1\",\"enterpriseObjectId\":null,\"enterpriseObjectName\":null,\"linkName\":null}],\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Dec 14 14:51:26 2016\",\"otherRuleName\":\"VELOCLOUD_EDGE_LINK\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"otherCollector\":\"dcaelocal-dev-01\"}";
		
		//String jsonStr = "{\"eventId\":\"127.0.0.1\",\"sourceInstance\":\"127.0.0.1\",\"eventSourceHostname\":\"UNKNOWN\",\"Priority\":\"190\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Oct 18 22:39:38\",\"eventSourceHost\":\"USATT1NJMUSVVHP001\",\"syslogProc\":\"node-upload\",\"syslogProcId\":\"2499\",\"syslogTag\":\"\",\"isVCO\":\"\",\"syslogMsg\":[{\"source\":\"EDGE\",\"event\":\"EDGE_SERVICE_FAILED\",\"category\":\"EDGE\",\"severity\":\"ERROR\",\"message\":\"Service edged failed with error -6, restarting\",\"detail\":null,\"eventTime\":\"2016-10-18T22:38:25.577Z\",\"enterpriseUserId\":null,\"enterpriseUsername\":null,\"edgeId\":192,\"edgeName\":\"finance-edge-ptr45\",\"linkId\":null,\"enterpriseId\":1,\"enterpriseName\":\"ATT-sndc-coke-customer1\",\"enterpriseObjectId\":null,\"enterpriseObjectName\":null,\"linkName\":null}],\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Dec 14 15:10:26 2016\",\"otherRuleName\":\"VELOCLOUD_EDGE_LINK\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"otherCollector\":\"dcaelocal-dev-01\"}";
		
		String jsonStr = "{\"eventId\":\"127.0.0.1\",\"sourceInstance\":\"127.0.0.1\",\"eventSourceHostname\":\"UNKNOWN\",\"Priority\":\"190\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Oct 18 22:39:38\",\"eventSourceHost\":\"USATT1NJMUSVVHP001\",\"syslogProc\":\"node-upload\",\"syslogProcId\":\"2499\",\"syslogTag\":\"\",\"isVCO\":\"\",\"syslogMsg\":[{\"source\":\"EDGE\",\"event\":\"EDGE_SERVICE_FAILED\",\"category\":\"EDGE\",\"severity\":\"ERROR\",\"message\":\"Service edged failed with error -6, restarting\",\"detail\":null,\"eventTime\":\"2016-10-18T22:38:25.577Z\",\"enterpriseUserId\":null,\"enterpriseUsername\":null,\"edgeId\":192,\"edgeName\":\"finance-edge-ptr45\",\"linkId\":null,\"enterpriseId\":1,\"enterpriseName\":\"ATT-sndc-coke-customer1\",\"enterpriseObjectId\":null,\"enterpriseObjectName\":null,\"linkName\":null}],\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Dec 14 19:57:49 2016\",\"otherRuleName\":\"VELOCLOUD_EDGE_LINK\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"otherCollector\":\"dcaelocal-dev-01\"}";
		
		 String str1 = "{\"eventId\":\"127.0.0.1\",\"sourceInstance\":\"127.0.0.1\",\"eventSourceHostname\":\"UNKNOWN\",\"P"+
			 "riority\":\"190\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Oct 18 22:39:38\",\"eventSourceHost\":\"USATT1NJMUSVVHP0"+
			 "01\",\"syslogProc\":\"node-upload\",\"syslogProcId\":\"2499\",\"syslogTag\":\"\",\"isVCO\":\"\",\"syslogMsg\":[{\"source\":\""+
			 "\"EDGE\",\"event\":\"EDGE_SERVICE_FAILED\",\"category\":\"EDGE\",\"severity\":\"ERROR\",\"message\":\"Serv"+
			 "ice edged failed with error -6, restarting\",\"detail\":null,\"eventTime\":\"2016-10-18T22:38:25.577Z\",\""+
			 "\"enterpriseUserId\":null,\"enterpriseUsername\":null,\"edgeId\":192,\"edgeName\":\"finance-edge-ptr45\",\""+
			 "\"linkId\":null,\"enterpriseId\":1,\"enterpriseName\":\"ATT-sndc-coke-customer1\",\"enterpriseObjectId\":n"+
			 "ull,\"enterpriseObjectName\":null,\"linkName\":null}],\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Dec 14 2"+
			 "0:12:09 2016\",\"otherRuleName\":\"VELOCLOUD_EDGE_LINK\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"ot"+
			 "herElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":"+
			 "\"unknown\",\"otherCollector\":\"dcaelocal-dev-01\"}";
		 
		 System.out.println( " str1 -> " + str1);
		 System.out.println( " pos -> " + str1.charAt(280) + str1.charAt(281) + str1.charAt(282) + str1.charAt(283) + 
				 str1.charAt(284) + str1.charAt(285) );

		/*		String jsonStr = 
				"{\"eventId\":\"127.0.0.1\",\"sourceInstance\":\"127.0.0.1\",\"eventSourceHostname\":\"UNKNOWN\","
						+ "\"syslogVer\":\"\",\"eventStartTimestamp\":\"Sep 13 13:34:01\","
						+ "\"eventSourceHost\":\"zrdm3fcmd01cmd001\",\"syslogProc\":\"syslog-ng\",\"syslogProcID\":\"19575\","
						+ "\"syslogTag\":\"\",\"syslogMsg\":\"Connection broken; time_reopen='60'\",\"syslogSData\":\"\","
						+ "\"startEpochMicrosec\":\"Wed Sep 21 14:47:28 2016\",\"otherSiteId\":\"unknown\","
						+ "\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\","
						+ "\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"updateJsonForNimbus\":\"\"}";*/

		System.out.println(" jsonStr -> " + jsonStr); System.out.println();

		JSONObject jo = new JSONObject(jsonStr);
		/*		if ( jsonStr.contains("updateJsonForNimbus") ) {

			System.out.println( " updateJsonForNimbus -> " + jo.getString("updateJsonForNimbus"));

			jo.remove("updateJsonForNimbus");
			jo.put("otherElementTp", "nimbus");
			jo.put("eventStartTimestamp", jo.get("startEpochMicrosec"));

			System.out.println( " New JSON object -> " + jo.toString() );
		}*/

		if ( jo.has("isVCO") ) {
			System.out.println(" it's VCO...");
			if ( jo.has("syslogMsg") && jo.getJSONArray("syslogMsg") != null ) {
				JSONArray syslogMsgArr =  jo.getJSONArray("syslogMsg");
				for (int i = 0; i < syslogMsgArr.length(); i++) {
					
					final JSONObject syslogMsgArrElem = syslogMsgArr.getJSONObject(i);
					//System.out.println(" Array elem " + i + " -> " + syslogMsgArrElem.toString() + "." );
					
					if ( syslogMsgArr.getJSONObject(i).has("event") && 
							null != syslogMsgArr.getJSONObject(i).getString("event") &&
							!syslogMsgArr.getJSONObject(i).getString("event").isEmpty() ) 
					{
						final String event = syslogMsgArr.getJSONObject(i).getString("event");
						System.out.println("Found event -> " + event + "." );
						jo.put("syslogTag", event);
					}
					
				}
			}
			jo.remove("isVCO");
		}
		
		if ( jo.has("setEventStartTimestamp") ) {
			if	( jo.has("startEpochMicrosec") && !jo.getString("startEpochMicrosec").isEmpty() ) {
				jo.put("eventStartTimestamp", jo.get("startEpochMicrosec"));
			}
			jo.remove("setEventStartTimestamp");
		}
		else 
		{
			System.out.println( "NO JSON updates");
		}

		if ( jo.has("Priority") && !jo.getString("Priority").isEmpty() ) {
			System.out.println( " Priority from JSON -> " + jo.getString("Priority"));
			int pri = Integer.valueOf(jo.getString("Priority"));
			System.out.println( " Priority from int -> " + pri);

			int sev = pri % 8;

			System.out.println( "int sev -> " + sev);
			if ( sev == 1 || sev == 2 ) {
				jo.put("syslogSev", "High");
			}
			else if ( sev == 3 || sev == 4 ) {
				jo.put("syslogSev", "Medium");
			} 
			else if ( sev == 5 ) {
				jo.put("syslogSev", "Normal");
			} 
			else if ( sev == 6 || sev == 7 ) {
				jo.put("syslogSev", "Low");
			} 
			else {
				jo.put("syslogSev", "UNKNOWN");
			}
		}
		else {
			jo.put("syslogSev", "UNKNOWN");
		}

		System.out.println( " New2 JSON object -> " + jo.toString() );
	}

}
