package com.att.javatest;

import java.io.BufferedReader;
import java.io.FileReader;

public class ReadXMLFile {

	static private final String eventKeySTag = "<Ename>";
	static private final String eventKeyETag = "</Ename>";
	static private final String purgeIntySTag = "<purgeInterval>";
	static private final String purgeIntETag = "</purgeInterval>";
	static private final String oidToName = "oidToEname";
	static private final String defaultOid = "DEFAULT";
	static private final String unknown = "unknown";
	static private String eventKey = "";
	static private String purgeInt = "";
	static private BufferedReader reader = null;

	public static void main(String[] args) {

		readOIDEKFile(".1.3.111.2.80.1.1.8/6/1");

		if ( purgeInt.isEmpty() ) { 
			System.out.println("purgeInt is empty; Look for DEFAULT");
			readOIDEKFile(defaultOid);
			if ( purgeInt.isEmpty() ) { 
				System.out.println("No DEFAULT Found; using purgeInt \"unknown\" value");
				purgeInt = unknown;
			}
		}

		if ( eventKey.isEmpty() ) { 
			System.out.println("eventKey is empty; Look for DEFAULT");
			readOIDEKFile(defaultOid);
			if ( eventKey.isEmpty() ) { 
				System.out.println("No DEFAULT Found; using eventKey \"unknown\" value");
				eventKey = unknown;
			}
		}

		eventKey = eventKey.trim();
		purgeInt = purgeInt.trim();
		System.out.println("purgeInt = " + purgeInt + " eventKey = " + eventKey + ".");


	}

	public static void readOIDEKFile (String oid) {

		String line = "";
		boolean found = false;

		try {
			reader = new BufferedReader(new FileReader("OID-KE.xml"));

			while ( (line = reader.readLine()) != null ) {
				if ( found ) {
					if ( line.contains(oidToName) ) {
						break;
					}
					if ( line.contains(eventKeySTag) && eventKey.isEmpty() ) {
						eventKey = line.substring(line.indexOf(eventKeySTag)+eventKeySTag.length(), line.lastIndexOf(eventKeyETag));
					}
					if ( line.contains(purgeIntySTag) && purgeInt.isEmpty()  ) {
						purgeInt = line.substring(line.indexOf(purgeIntySTag)+purgeIntySTag.length(), line.lastIndexOf(purgeIntETag));
					}
				}
				if ( line.contains(oid+"<")) {
					System.out.println("OID: " + oid + " found.");
					found = true;
				}
				if ( !purgeInt.isEmpty() && !eventKey.isEmpty() ) {
					System.out.println("Found purgeInt and eventKey");
					break;
				}

			}
		}
		catch (Exception e) {
			System.out.println("Caught exception: " + e);
			e.printStackTrace();
			System.exit(0);
		}
		finally {
			try {
				reader.close();
			} catch (Exception e) {
				System.out.println("error closing" + e.toString());
			}
		}
	}
}
