
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.media.multipart.MultiPartFeature;

import com.att.vcc.logger.VccLogger;

public class AAIBroker {
	private static final String CLASSNAME = "AAIBroker";
	private static VccLogger logger = new VccLogger("AAIBroker");

	public static String GetData(String httpURL) throws Exception {
		String methodName = "GetData";
		// local variables
		ClientConfig clientConfig = null;
		Client client = null;
		WebTarget webTarget = null;
		Invocation.Builder invocationBuilder = null;
		Response response = null;
		int responseCode;
		String responseMessageFromServer = null;
		String data = "";
		
		
		////// FOR DEBUG ///////
		if (1 == 11) {
			data = "[\r\n" + "    {\r\n" + "        \"vserver_id\": \"3e156947-1dcf-477f-9a92-9903ea28046a\",\r\n"
					+ "        \"vserver_name\": \"stack01\"\r\n" + "    },\r\n" + "    {\r\n"
					+ "        \"vserver_id\": \"98367ba0-e393-468f-98c0-071b77eb4d99\",\r\n"
					+ "        \"vserver_name\": \"heat01\"\r\n" + "    },\r\n" + "    {\r\n"
					+ "        \"vserver_id\": \"25f74ae2-fbd4-4322-82dc-10bf896ddf2f\",\r\n"
					+ "        \"vserver_name\": \"slaa-testudp-differenthost-vm01\"\r\n" + "    }\r\n" + "]";
			return data;

		}
		//////////\\\\\\\\\\\\\\

		try {
			// invoke service after setting necessary parameters
			clientConfig = new ClientConfig();
			clientConfig.register(MultiPartFeature.class);
			client = ClientBuilder.newClient(clientConfig);
			webTarget = client.target(httpURL);

			////////////////////////
			// Output all returned to the console:
			data = webTarget.request().get(String.class);
			System.out.println(data);

			////////////////// \\\\\

			invocationBuilder = webTarget.request();
			response = invocationBuilder.get();

			// get response code
			responseCode = response.getStatus();
			System.out.println("Response code: " + responseCode);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed with HTTP error code : " + responseCode);
			}

			// get response message
			responseMessageFromServer = response.getStatusInfo().getReasonPhrase();
			System.out.println("ResponseMessageFromServer: " + responseMessageFromServer);

		} catch (Exception e) {
			logger.error(CLASSNAME, methodName, "Exception while interacting with AAI Broker: " + e.getMessage());

		} finally {
			// release resources, if any
			response.close();
			client.close();
		}
		return data;
	}
	public static void main(String[] args) {
		
		try {
			String httpURL = "http://zldcmtn23adcc1dokr01.1fe31c.mtn23a.tci.att.com.:10567/query/SELECT%20vserver_id,vserver_name%20FROM%20dti.rt_vserver";
			AAIBroker.GetData(httpURL);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
