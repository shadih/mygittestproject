package com.att.javatest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonArrayFromFile {


	public static void main(String[] args) {

		try {
			
			JSONArray jArray = new JSONArray ( new JSONTokener ( new FileInputStream ( new File ( "dmaap2.conf" ) ) ) );
			//Object o = jArray.get(0);
			//JSONObject jo = (JSONObject) jArray.get(0);
			
			for (int i = 0; i < jArray.length(); i++) {
				System.out.println(" URL " + i + " - > " + jArray.get(i).toString());
				System.out.println("");
				JSONObject jo = (JSONObject) jArray.get(i);
				System.out.println("dmaapStreamId -> " + jo.getString("dmaapStreamId"));
				String urlParts[] = jo.getString("dmaapUrl").split("/");
				for (int j = 0; j < urlParts.length; j++) {
					System.out.println("-- j> " + j + " --> " + urlParts[j] );
				}
				//if ( jo.has(key))
			}
			//System.out.println(" URL " + jArray.toString());
			
			//System.out.println(" URL1 " + jArray.getJSONArray(0).toString());
			
			//System.out.println(" URL " + jArray.getJSONObject(0));
			//System.out.println(" URL2 " + jo.toString());
			
			//System.out.println(" URL3 " + jo.getString("dmaapUrl"));
			//jArray.getString ( i );

			
		}
		catch (Exception e) {
			System.out.println("exp = " );
			e.printStackTrace();
		}
	}
}
