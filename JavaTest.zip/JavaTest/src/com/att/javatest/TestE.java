package com.att.javatest;

public class TestE {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int ip_LastOctet = 97;
		if ( (ip_LastOctet & 1) == 0 ) {
			System.out.println("ip_LastOctet is even");
			// even 
			
		}
		else  System.out.println("ip_LastOctet is odd");
		
		int x = 100;
		if((x%2)==0) System.out.println("x is even");
			// even 
			else  System.out.println("x is odd");
			// odd
				

	}

}
