package com.att.javatest;

public class Min {

	public static void main(String[] args) {
		
		long alarm_50004_1_19_bets = Long.parseLong("9999999999");
		long alarm_50004_1_21_bets = Long.parseLong("9999993432");
		long alarm_50004_1_39_bets = Long.parseLong("9999999999");
		Long.parseLong("9999999999");
		
		System.out.println(Math.min(alarm_50004_1_19_bets, Math.min(alarm_50004_1_21_bets, alarm_50004_1_39_bets)));
		
		long smallest;
		if(alarm_50004_1_19_bets<alarm_50004_1_21_bets && alarm_50004_1_19_bets<alarm_50004_1_39_bets){
		    smallest = alarm_50004_1_19_bets;
		}else if(alarm_50004_1_21_bets<alarm_50004_1_39_bets && alarm_50004_1_21_bets<alarm_50004_1_19_bets){
		    smallest = alarm_50004_1_21_bets;
		}else{
		    smallest = alarm_50004_1_39_bets;
		}

		System.out.println("smallest " + smallest);
	}

}
