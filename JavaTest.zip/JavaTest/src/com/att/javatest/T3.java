package com.att.javatest;

import java.util.Random;


public class T3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String sqlStatement = "SEP= sql=select DISTINCT cucp_hostname,ip_address from cucp.cucp_server1";
		String csvSeperator = "|"; 
		
		System.out.println("original sqlStatement \t\t-" + sqlStatement + "- " );
		
		if (sqlStatement.startsWith("SEP=")) {
			String optSeperator = "";
			optSeperator = sqlStatement.substring(4, sqlStatement.indexOf(" "));
			if ( !optSeperator.isEmpty() ) {
				csvSeperator = optSeperator;
			}
			sqlStatement = sqlStatement.substring(sqlStatement.indexOf(" ")+1, sqlStatement.length());
		}
		
		//aid = aid.substring(0, aid.indexOf("/")+1) + "*****" + aid.substring(aid.indexOf("@"), aid.length());
		//+ "*****" + aid.substring(aid.indexOf("@"), aid.length());
		
		System.out.println("csvSeperator \t\t\t-" + csvSeperator + "- " );
		System.out.println("new sqlStatement \t\t-" + sqlStatement + "- " );
		
	
	}

}
