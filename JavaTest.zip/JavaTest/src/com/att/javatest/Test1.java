package com.att.javatest;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
		BufferedReader ttstabReader = new BufferedReader(new FileReader("TTSTAB_FILE"));
    	String ttstabLine; String ttsArgs = ""; String ttsCmdStr = "";
    	Pattern commentsPattern = Pattern.compile("\\s*#");
    	while ( (ttstabLine = ttstabReader.readLine()) != null ) {
    		Matcher commentsMatcher = commentsPattern.matcher(ttstabLine);
    		if ( commentsMatcher.find()) {
    			System.out.println("skip comments line --> " + ttstabLine );
    			continue;
    		}
    		
    		if ( ttstabLine.contains("TTSArguments") ) {
    			int pos1 = ttstabLine.indexOf(" \"");
    			int pos2 = ttstabLine.lastIndexOf("\";");
    			ttsArgs = ttstabLine.substring(pos1+2, pos2);
    		}
    		
   
    		else if ( ttstabLine.contains("50002/100/39") ) {
    			ttsCmdStr = parseTtstab(ttstabLine);
    			break;
    		}

        }
    	ttstabReader.close();
    	System.out.println(" ttsCmdStr = " + ttsCmdStr + ".");
    	System.out.println(" ttsArgs = " + ttsArgs + ".");
		}
		catch (Exception e) {
			System.out.println("excep = " + e);
			e.printStackTrace();
		}

	}
	
    private static String parseTtstab(String ttstabLine) {
    	String ttsCmd = "";
    	
    	int pos1 = ttstabLine.indexOf("SCR=`");
    	int pos2 = ttstabLine.lastIndexOf("`;");
    	ttsCmd = ttstabLine.substring(pos1+5, pos2);
    	
    	return ttsCmd;
    }

}
