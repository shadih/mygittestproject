package com.att.javatest;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;



public class TimerTest {
	
	final static ScheduledExecutorService ses = Executors.newSingleThreadScheduledExecutor();
	static boolean timerRunning = false;
	
	public static void main(String[] args) {
		System.out.println("Startup: " + new Date());

		//final ScheduledExecutorService ses = Executors.newSingleThreadScheduledExecutor();
		
		/*ses.scheduleWithFixedDelay(new Runnable() {
			@Override
			public void run() {
				System.out.println("in task : " + new Date());
			}
		}, 2, 5, TimeUnit.SECONDS);*/
		
		startTimer();

		System.out.println("Proceed with while: " + new Date());
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		startTimer();
		
		int i = 0;
		while ( i < 10 ) {
			System.out.println("in while i : " + i + " date " + new Date());
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			i++;
			if ( i == 5 ) {
				System.out.println("trying shuting down : ");
				if ( !ses.isShutdown() || !ses.isTerminated() ) {
					System.out.println("shuting down : ");
					ses.shutdownNow();
				}
				
			}
		}
	}
	
	public static void startTimer () {
		
		System.out.println("startTimer()");
		
		try {
			if ( timerRunning ) {
				System.out.println("startTimer(): shuting down : ");
				ses.shutdownNow();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("startTimer(): Exception shuting down : ");
			e.printStackTrace();
		}
		
		try {
			
			ses.scheduleWithFixedDelay(new Runnable() {
				@Override
				public void run() {
					System.out.println("in task : " + new Date());
				}
			}, 0, 1, TimeUnit.SECONDS);
			timerRunning = true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
