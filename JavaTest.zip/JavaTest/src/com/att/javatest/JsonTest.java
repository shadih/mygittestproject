package com.att.javatest;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonTest {
	


	public static void main(String[] args) throws JSONException, FileNotFoundException {

		JSONObject jo = new JSONObject(); jo.put("key1", "value1"); 
		
		String syslogMsg = "[{\"source\":\"EDGE\",\"event\":\"EDGE_SERVICE_FAILED\",\"category\":\"EDGE\",\"severity\":\"ERROR\",\"message\":\"Service edged failed with error -6, restarting\",\"detail\":null,\"eventTime\":\"2016-10-18T22:38:25.577Z\",\"enterpriseUserId\":null,\"enterpriseUsername\":null,\"edgeId\":192,\"edgeName\":\"finance-edge-ptr45\",\"linkId\":null,\"enterpriseId\":1,\"enterpriseName\":\"ATT-sndc-coke-customer1\",\"enterpriseObjectId\":null,\"enterpriseObjectName\":null,\"linkName\":null}]";
		System.out.println(" syslogMsg --" + syslogMsg + "--");
		JSONArray ja = new JSONArray(syslogMsg);
		
		jo.put("syslogMsg", ja);
		System.out.println(" ja --" + ja.toString() + "--");
		
		System.out.println(" NEW jo --" + jo.toString() + "--");
		
	}

}
