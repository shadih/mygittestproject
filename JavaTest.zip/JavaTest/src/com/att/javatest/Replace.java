package com.att.javatest;

public class Replace {

	public static void main(String[] args) {
		String str1 = "Testing stri* replacement";
		System.out.println(" orig " + str1);
		str1 = str1.replaceAll("\\*", "%");
		System.out.println(" out " + str1);
	}

}
