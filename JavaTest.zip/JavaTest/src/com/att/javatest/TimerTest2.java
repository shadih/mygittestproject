package com.att.javatest;

import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;


public class TimerTest2 {

	static Timer timer = new Timer();
	static boolean timerRunning = false;
	static long currEpochTime;
	
	public static void main(String[] args){

		//timer.cancel();
		
		startTimer();

		int i = 0;
        while ( i < 10 ) {
        	System.out.println("in while i : " + i + " date " + new Date());
        	try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
        	i++;
        	if ( i == 3 ) {
        		startTimer();
        	}
        	
        	if ( i == 6 ) {
        		startTimer();
        	}
        	
        	if ( i == 9 ) {
        		startTimer();
        	}
        }
		
	}
	
	public static void startTimer () {
		
		System.out.println("startTimer () ENTRY ");
		
		if ( timerRunning ) {
			System.out.println("startTimer () timerRunning, cancel and create a new timer ");
			timer.cancel();
			timer = new Timer();
		}
		
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				System.out.println("Inside Timer Task" + new Date());
				currEpochTime = System.currentTimeMillis();
				System.out.println("Inside Timer Task: currEpochTime " + currEpochTime);
			}
		};

		System.out.println("Current time1" + new Date());
		timer.schedule(task, 2000,1000);
		
		timerRunning = true;
	}
}
