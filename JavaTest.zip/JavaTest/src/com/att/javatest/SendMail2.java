package com.att.javatest;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.regex.Pattern;
import java.io.File;

public class SendMail2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String out = "";
		//try {
			 String cmd = "cat t1";

			//System.out.println("t " + Arrays.toString(cmd) + "\n");
			 System.out.println("ruuning: " + cmd);
			
			 ProcessBuilder builder = new ProcessBuilder("cat", "t1");
			 builder.redirectOutput(new File("out1"));
			 builder.redirectError(new File("out1"));
			 
	/*		Process p = Runtime.getRuntime().exec(cmd);
			BufferedReader reader = new BufferedReader (new InputStreamReader(p.getInputStream()));
			String line = "";
				while ( (line = reader.readLine()) != null ) {
					out+=(line+"\n");
				}
				p.waitFor();
		}
		catch (Exception e) {
			System.out.println("runCliCmd() Exception: " + e);
			e.printStackTrace();
		}	

		System.out.println(" out = " + out + "...");
	}
	*/
	}
}
