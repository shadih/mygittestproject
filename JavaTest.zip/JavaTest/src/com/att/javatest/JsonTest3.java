package com.att.javatest;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonTest3 {

	public static void main(String[] args) throws JSONException, FileNotFoundException {

		//String str2 = "{\"eventId\":\"127.0.0.1\",\"sourceInstance\":\"127.0.0.1\",\"eventSourceHostname\":\"UNKNOWN\",\"Priority\":\"190\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Oct 18 22:39:38\",\"eventSourceHost\":\"USATT1NJMUSVVHP001\",\"syslogProc\":\"node-upload\",\"syslogProcId\":\"2499\",\"syslogTag\":\"\",\"isVCO\":\"\",\"syslogMsg\":[{\\\"source\":\"EDGE\",\"event\":\"EDGE_SERVICE_FAILED\",\"category\":\"EDGE\",\"severity\":\"ERROR\",\"message\":\"Service edged failed with error -6, restarting\",\"detail\":null,\"eventTime\":\"2016-10-18T22:38:25.577Z\",\"enterpriseUserId\":null,\"enterpriseUsername\":null,\"edgeId\":192,\"edgeName\":\"finance-edge-ptr45\",\"linkId\":null,\"enterpriseId\":1,\"enterpriseName\":\"ATT-sndc-coke-customer1\",\"enterpriseObjectId\":null,\"enterpriseObjectName\":null,\"linkName\":null}],\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Dec 14 20:12:09 2016\",\"otherRuleName\":\"VELOCLOUD_EDGE_LINK\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"otherCollector\":\"dcaelocal-dev-01\"}";
		
		String str2 = "{\"eventId\":\"127.0.0.1\",\"sourceInstance\":\"127.0.0.1\",\"eventSourceHostname\":\"UNKNOWN\",\"Priority\":\"190\",\"syslogVer\":\"\",\"eventStartTimestamp\":\"Oct 18 22:39:38\",\"eventSourceHost\":\"USATT1NJMUSVVHP001\",\"syslogProc\":\"node-upload\",\"syslogProcId\":\"2499\",\"syslogTag\":\"\",\"isVCO\":\"\",\"syslogMsg\":[{\\\"source\":\"GATEWAY\",\"event\":\"EDGE_SERVICE_FAILED\",\"category\":\"EDGE\",\"severity\":\"ERROR\",\"message\":\"Service edged failed with error -6, restarting\",\"detail\":null,\"eventTime\":\"2016-10-18T22:38:25.577Z\",\"enterpriseUserId\":null,\"enterpriseUsername\":null,\"edgeId\":192,\"gatewayName\":\"USSONYA2STXVVHP001\",\"linkId\":null,\"enterpriseId\":1,\"enterpriseName\":\"ATT-sndc-coke-customer1\",\"enterpriseObjectId\":null,\"enterpriseObjectName\":null,\"linkName\":null}],\"syslogSData\":\"\",\"startEpochMicrosec\":\"Wed Dec 14 20:12:09 2016\",\"otherRuleName\":\"VELOCLOUD_EDGE_LINK\",\"otherSiteId\":\"unknown\",\"otherSiteInst\":\"unknown\",\"otherElementTp\":\"unknown\",\"otherElementInst\":\"unknown\",\"otherSubElementTp\":\"unknown\",\"otherSubElementInst\":\"unknown\",\"otherCollector\":\"dcaelocal-dev-01\"}";

		System.out.println( " pos -> " + str2.charAt(280) + str2.charAt(281) + str2.charAt(282) + str2.charAt(283) + 
				str2.charAt(284) + str2.charAt(285) );

		System.out.println(" BEFORE str2 -> " + str2); System.out.println();
		str2 = str2.replace("\\\"", "\"");
		System.out.println(" AFTER str2 -> " + str2); System.out.println();

		try {

			JSONObject jo = new JSONObject(str2);


			if ( jo.has("setEventStartTimestamp") ) {
				if (jo.has("startEpochMicrosec") && !jo.getString("startEpochMicrosec").isEmpty() ) {
					jo.put("eventStartTimestamp", jo.get("startEpochMicrosec"));
				}
				jo.remove("setEventStartTimestamp");
			}

			if ( jo.has("isVCO") ) {
				String d2msg = "SHADI has VCO ";
				System.out.println("updateJson" + d2msg);
				if ( jo.has("syslogMsg") && jo.getJSONArray("syslogMsg") != null ) {
					d2msg = "SHADI has syslogMsg ";
					System.out.println("updateJson" + d2msg);					
					JSONArray syslogMsgArr =  jo.getJSONArray("syslogMsg");
					for (int i = 0; i < syslogMsgArr.length(); i++) {	
						d2msg = "SHADI inside syslogMsgArr ";
						System.out.println("updateJson" + d2msg);				
						if ( syslogMsgArr.getJSONObject(i).has("event") && 
								null != syslogMsgArr.getJSONObject(i).getString("event") &&
								!syslogMsgArr.getJSONObject(i).getString("event").isEmpty() ) 
						{
							final String event = syslogMsgArr.getJSONObject(i).getString("event");
							d2msg = "SHADI inside event -> " + event;
							System.out.println("updateJson" + d2msg);					
							jo.put("syslogTag", event);
						}	

						if ( syslogMsgArr.getJSONObject(i).has("source") && 
								null != syslogMsgArr.getJSONObject(i).getString("source") &&
								!syslogMsgArr.getJSONObject(i).getString("source").isEmpty() ) 
						{
							final String source = syslogMsgArr.getJSONObject(i).getString("source");
							d2msg = "SHADI inside source -> " + source;
							System.out.println("updateJson" + d2msg);			

							if ( source.equals("EDGE") ) {
								if ( syslogMsgArr.getJSONObject(i).has("edgeName") && 
										null != syslogMsgArr.getJSONObject(i).getString("edgeName") &&
										!syslogMsgArr.getJSONObject(i).getString("edgeName").isEmpty() ) 
								{
									final String edgeName = syslogMsgArr.getJSONObject(i).getString("edgeName");
									jo.put("eventSourceHostname", edgeName);
								}
							}
							else if ( source.equals("GATEWAY") ) {
								if ( syslogMsgArr.getJSONObject(i).has("gatewayName") && 
										null != syslogMsgArr.getJSONObject(i).getString("gatewayName") &&
										!syslogMsgArr.getJSONObject(i).getString("gatewayName").isEmpty() ) 
								{
									final String gatewayName = syslogMsgArr.getJSONObject(i).getString("gatewayName");
									jo.put("eventSourceHostname", gatewayName);
								}
							}
						}
					}
				}
				
				if ( jo.has("eventSourceHostname") && null != jo.getString("eventSourceHostname") && 
						!jo.getString("eventSourceHostname").isEmpty() )  
				{
					System.out.println("updateJson otherElementTp -> " + jo.getString("otherElementTp"));
					System.out.println("updateJson otherElementInst -> " + jo.getString("otherElementInst"));
					
					final String eventSourceHostname = jo.getString("eventSourceHostname");
					if ( eventSourceHostname.length() >= 3 ) {
						jo.put("otherElementInst", eventSourceHostname.substring(eventSourceHostname.length() - 3) );
					}
					
					if ( eventSourceHostname.length() >= 7 ) {
						jo.put("otherElementTp", eventSourceHostname.substring(eventSourceHostname.length() - 7, eventSourceHostname.length() - 3) );
					}
				}
				jo.remove("isVCO");
			}

			System.out.println(" FINAL JSON object -> " + jo.toString()); System.out.println();

		} catch (JSONException e) {
			System.out.println("updateJson JSONException: " + e);

		}
	}
}
