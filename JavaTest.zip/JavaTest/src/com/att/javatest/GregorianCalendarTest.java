package com.att.javatest;


import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import java.util.GregorianCalendar;

public class GregorianCalendarTest {

	public static void main(String[] args) {
	
			try {
				System.out.println("xGC--> " + convEventTime("1461172966") + ".");
			} catch (DatatypeConfigurationException e) {
				
				e.printStackTrace();
			}

	}

	private static String convEventTime(String time) throws DatatypeConfigurationException
	{
		GregorianCalendar gcal = new GregorianCalendar();
		gcal.setTimeInMillis(Long.parseLong(time) * 1000);
		DatatypeFactory dtf = DatatypeFactory.newInstance();
		return dtf.newXMLGregorianCalendar(gcal).toString();
		
		//XMLGregorianCalendar eventTime = dtf.newXMLGregorianCalendar(gcal);
		//return eventTime.toString();
	} 


}
