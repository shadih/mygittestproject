package com.att.javatest;

public class StringLength {


	public static void main(String[] args) {
		
		boolean cont = true;
		int i = 0;
		
		String s1 = "<158>1 2017-02-14T18:13:53.858Z ZRDM3FRWL01DMZ008 /kernel - - -";
		
		System.out.println(" s1 ->" + s1 + "--");
		
		System.out.println(" hello " + i);
		
		String t1 = "<46>Nov rsyslogd: -- MARK --6] IPv";
		System.out.println(" --" + t1.substring(0, 3) + "--");
		String t = ",eventId, , ,SRC_IP,";

		System.out.println("lenthg -> " + t.length() );

		//	System.out.println("name -> " + t.substring( t.indexOf("=")+1, t.length() ) + " <-");
		//	System.out.println("name -> " + t.replaceAll("\r", "").replaceAll("\n", "")  + " <-");

		System.out.println( "1st char --" + t.substring(0, 1) + "--");

		String d = "12";
		System.out.println("is d: " + d + " an integer? ");

		if ( d.matches("\\d+") ) { System.out.println(" yes");} else { System.out.println(" no");}

		String msg = "<<46>Nov 17 15:20:15 zrdm3pxtc02mts009 rsyslogd: -- MARK --6] IPv4: martian source 166.209.17.186 from 107.243.79.44, on dev eth3r(ShardInterface.jaa:706).java:49).jaa:180)2dcfd8-3902";

		System.out.println("original syslog: " + msg);

		int fromIndex = 0;
		String stringToMatch = msg.substring(fromIndex, msg.length());

		System.out.println("syslog to match: " + stringToMatch);
		String startDelim = "<<"; String endDelim = ">";
		
		int matchStartIndex = stringToMatch.indexOf(startDelim, fromIndex); 
		int matchEndIndex = stringToMatch.indexOf(endDelim, fromIndex + startDelim.length());
		String match = stringToMatch.substring(matchStartIndex + startDelim.length(), matchEndIndex);

		System.out.println(" index of startDelim " +
				matchStartIndex 
		+ " index of endDelim " + 
				matchEndIndex
		+ " match is --" +
		match
		+ "--");

		System.out.println(" now starting to match from index: " + match.length() );
		
		stringToMatch = msg.substring( startDelim.length() + match.length(), msg.length());
		
		System.out.println(" new syslog to match: " + stringToMatch);

		String[] arr = t.split(" ");
		for (String arr_elem : arr ) {
			//System.out.println(" arr_elem " + arr_elem);
			if ( arr_elem.startsWith("PTNII=<") ) {
				System.out.println(" arr_elem " + arr_elem);
				int ptnii_indx = arr_elem.indexOf("PTNII=<");
				if ( ptnii_indx != -1 ) {
					System.out.println(" new " + arr_elem.substring("PTNII=<".length(), arr_elem.length()-1) + ".");
				}
				else {
					System.out.println(" ptnii_indx " + ptnii_indx);
				}
				break;
			}
		}


	}


}
