package com.att.javatest;

import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonArray3 {

	private static final String SITE_TAG = "site";

	public static void main(String[] args) {
		
		try {

			String ja = "{ \"sites\": [ {\"hostip\": \"sdn-l-analytics-aic.rdm5b.cci.att.com\", \"keyStoneURL\": \"https://identity-aic.rdm3.cci.att.com:5000/v2.0\", \"computeURL\": \"https://compute-aic.rdm3.cci.att.com:8774/v2/\", \"keyStoneTenant\": \"admin\", \"keyStoneUser\": \"m17598\", \"keyStonePad\": \"LowDensity1026\", \"authflag\": \"false\", \"port\": \"8081\", \"protocol\": \"https\", \"freq_ms\": \"300\", \"csvStreamId\": \"sdnlocal-vetl\", \"jsonStreamId\": \"sdnlocal-json\", \"targetFileDirectory\": \"/opt/data/DCAE/sdnlocal/output/\", \"httpProxy\": \"one.proxy.att.com\", \"timeoutConnection\": \"17000\", \"timeoutSocket\": \"17000\", \"threadpool_Size\": \"25\", \"threadpool_timeout_min\": \"5\", \"alternate_port\": \"8182\", \"usedmaap\": \"Y\"},{\"hostip\": \"dashboard-aic.rdm3.cci.att.com\", \"keyStoneURL\": \"https://identity-aic.rdm3.cci.att.com:5000/v2.0\", \"computeURL\": \"https://compute-aic.rdm3.cci.att.com:8774/v2/\", \"keyStoneTenant\": \"admin\", \"keyStoneUser\": \"m17598\", \"keyStonePad\": \"LowDensity1026\", \"authflag\": \"false\", \"port\": \"8081\", \"protocol\": \"https\", \"freq_ms\": \"300\", \"csvStreamId\": \"sdnlocal-vetl\", \"jsonStreamId\": \"sdnlocal-json\", \"targetFileDirectory\": \"/opt/data/DCAE/sdnlocal/output/\", \"httpProxy\": \"one.proxy.att.com\", \"timeoutConnection\": \"17000\", \"timeoutSocket\": \"17000\", \"threadpool_Size\": \"25\", \"threadpool_timeout_min\": \"5\", \"alternate_port\": \"8182\", \"usedmaap\": \"Y\"}] }";

			JSONObject mainConfigJson = new JSONObject(ja);
			JSONArray sitesArray = mainConfigJson.getJSONArray("sites");

			System.out.println(" OUT " + sitesArray.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("ERROR");
		}


	}



}
