package com.att.javatest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class JsonArrayFromSdnLocalFile {


	public static void main(String[] args) {

		try {
			
			JSONObject mainJson = new JSONObject(new JSONTokener(new FileReader("sdnlocal_config.properties")));
			JSONArray sitesArray = mainJson.getJSONArray("sites");
			
			//JSONArray jArray = new JSONArray ( new JSONTokener ( new FileInputStream ( new File ( "sdnlocal_config.properties" ) ) ) );

			for (int i = 0; i < sitesArray.length(); i++) {
				JSONObject jo = sitesArray.getJSONObject(i);
				System.out.println("Site -> " + i + jo.toString());
				System.out.println("");				
				System.out.println("Site.keyStoneURL -> " + i + jo.getString("keyStoneURL"));
				
			}

		}
		catch (Exception e) {
			System.out.println("exp = " );
			e.printStackTrace();
		}
	}
}
