package com.att.gfp.cpe.gfpCpeAlarmStormMgr.processors;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import org.json.JSONArray;

import java.util.Date;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;

import com.att.nsa.cambria.client.CambriaBatchingPublisher;
import com.att.nsa.cambria.client.CambriaClientBuilders;
import com.att.nsa.cambria.client.CambriaPublisher.message;

public class FormatAndPubSave {
	
	public static Logger log = Logger.getLogger(FormatAndPubSave.class);

	public FormatAndPubSave (String severity, String text, String object) {

		// set up some batch limits and the compression flag
		final int maxBatchSize = 100;
		final int maxAgeMs = 250;
		final boolean withGzip = false;


		// create our publisher using a builder
		final CambriaBatchingPublisher pub = new CambriaClientBuilders.PublisherBuilder ()
			.usingHosts ( TrapProc.pubUrl )
			.onTopic ( TrapProc.pubTopic )
			.limitBatch ( maxBatchSize, maxAgeMs )
			.enableCompresion ( withGzip )
			.build ()
		;


		SimpleDateFormat sdf = new SimpleDateFormat ("EEE, dd MMM yyyy HH:mm:ss z");

		// format json message  

		final JSONObject ts = new JSONObject ();
		ts.put ( "componentName", TrapProc.myHost );
		ts.put ( "datetime", sdf.format(new Date()) );

		final JSONObject tss = new JSONObject ();
		tss.put ( "timestamp", new JSONArray().put(ts) );

		final JSONObject hdr = new JSONObject ();
		hdr.put ( "timestamps", tss );
		hdr.put ( "sequence", "0" );
		hdr.put ( "sourceName", TrapProc.myHost );
		hdr.put ( "domain", "fault" );
		hdr.put ( "severity", severity );
		hdr.put ( "Id", TrapProc.myHost );
		hdr.put ( "eventType", TrapProc.pubTopic );
		hdr.put ( "sourceId", " " );

		final JSONObject addInfo = new JSONObject ();
		addInfo.put ( "eventSourceAddress", TrapProc.invMap.get(object) );
		addInfo.put ( "eventSourceApplication", "trapProc" );

		final JSONObject ff = new JSONObject ();
		ff.put ( "eventSourceType", "other" );
		ff.put ( "specificProblem", text );
		ff.put ( "alarmCondition", "IPsecTunnelState" );
		ff.put ( "eventSourceHostname", object );
		ff.put ( "alarmAdditionalInformation", new JSONArray().put(addInfo) );

		final JSONObject evMsg = new JSONObject ();
		evMsg.put ( "eventHeader", hdr );
		evMsg.put ( "faultFields", ff );

		final JSONObject event = new JSONObject ();
		event.put ( "event", evMsg );

		try {
		  pub.send ( "MyPartitionKey", event.toString () );
		} catch (IOException ioe) {
		  log.error("Unable to publish to UEB");
		}

		// close the publisher. The batching publisher does not send events
		// immediately, so you MUST use close to send any remaining messages.
		// You provide the amount of time you're willing to wait for the sends
		// to succeed before giving up. If any messages are unsent after that time,
		// they're returned to your app. You could, for example, persist to disk
		// and try again later.

		try {
		  final List stuck = pub.close ( 20, TimeUnit.SECONDS );
		  if ( stuck.size () > 0 ) {
			log.error( stuck.size() + " messages unsent" );
		  }
		}
		catch (Exception ex) {
			System.err.println ( "Exception: "+ex );
		}

	}
}
