/***************************************************************************
 * This class receives parsed messages from thread UEBsyslogGet via 
 * blockingQueue bq and sends onto UEB via HTTP.
 *
 * Namespace: com.att.syslogCollectionAdapter 
 * AAF UID: m04082@syslogCollectionAdapter.att.com
 ****************************************************************************
 * Original 2/2016 Jim Evans
 ****************************************************************************/
package mobsys.collector.app;

import java.util.*;
import java.util.concurrent.*;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.*;
import java.io.*;

import com.att.nsa.cambria.client.CambriaBatchingPublisher;
import com.att.nsa.cambria.client.CambriaClientBuilders;
import com.att.nsa.cambria.client.CambriaPublisher.message;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;

public class UEBsyslogPost implements Runnable 
{
   static
   {
      D2Logger.initD2Logger();
   }
   private static final String clname =
      new Throwable().getStackTrace()[0].getClassName();
   
   static HttpURLConnection uebconn;
   static String uebIP;
   static String uebTopic;
   static String uebBuflen;
   static String uebBatchSize;
   static String uebPeercon;
   static String uebProtocol;
   static String uebMechid;
   static String uebMechidPW;
   static BlockingQueue<String> bq;

   UEBsyslogPost(String uebIP, 
		  String uebTopic, String uebBuflen,
	          String uebBatchSize, String uebPeercon, 
		  String uebProtocol, String uebMechid,
		  String uebMechidPW, BlockingQueue<String> bq)
   {
      this.uebIP = uebIP;
      this.uebTopic = uebTopic;
      this.uebBuflen = uebBuflen;
      this.uebBatchSize = uebBatchSize;
      this.uebPeercon = uebPeercon;
      this.uebProtocol = uebProtocol;
      this.uebMechid = uebMechid;
      this.uebMechidPW = uebMechidPW;
      this.bq = bq;
   }

   public void run()
   {
      final String mn = "run";
      String d2msg = "Entering";
      D2Logger.debug(clname, mn, "DEBUG", d2msg);
      Socket s = null;

      String inrec = null;

      final int maxBatchSize = Integer.parseInt(uebBatchSize);
      final int maxAgeMs = 250;
      final boolean withGzip = false;
      final String apiKey = "cDw0XEwZuroJPuPj";
      final String apiSecret = "95wNyqPqSiaNYdBw3oPQX895";
      //final String mechId = "m04082";
      //final String mechIdPassword = "DCAE123!";

      while ((true))
      {
         CambriaBatchingPublisher pub =  null;
	 if ( uebPeercon.equals("DMAAP") )
	 { 
            if ( uebProtocol.equals("https") )
            {
	       try
	       {
                 d2msg = 
		   "Starting creation of CambriaClientBuilder" +
		   "Publisher (DMAAP : Protocol https)";
                 D2Logger.debug(clname, mn, "DEBUG", d2msg);
	         pub = new CambriaClientBuilders.PublisherBuilder ()
	         .usingHosts ( uebIP )
	         .onTopic ( uebTopic )
		 .usingHttps()
	         .limitBatch ( maxBatchSize, maxAgeMs )
	         .enableCompresion ( withGzip )
	         .authenticatedByHttp ( uebMechid, uebMechidPW )
	         .build ()
		;
	       } catch (Exception ex)
	       {
                  d2msg = "CambriaClientbuilders.PublisherBuilder failed";
                  D2Logger.debug(clname, mn, "DEBUG", d2msg);
	          D2Logger.error(clname, mn, "INFO", d2msg);
	       }
            }
            else
	    {
	       try
	       {
                 d2msg = 
		   "Starting creation of CambriaClientBuilder" +
		   "Publisher (DMAAP : Protocol http)";
                 D2Logger.debug(clname, mn, "DEBUG", d2msg);
	         pub = new CambriaClientBuilders.PublisherBuilder ()
	         .usingHosts ( uebIP )
	         .onTopic ( uebTopic )
	         .limitBatch ( maxBatchSize, maxAgeMs )
	         .enableCompresion ( withGzip )
	         .authenticatedByHttp ( uebMechid, uebMechidPW )
	         .build ()
		;
	       } catch (Exception ex)
	       {
                  d2msg = "CambriaClientbuilders.PublisherBuilder failed";
                  D2Logger.debug(clname, mn, "DEBUG", d2msg);
	          D2Logger.error(clname, mn, "INFO", d2msg);
	       }
	    } 
	 }
	 else
	 { 
	    try
	    {
              d2msg = 
		"Starting creation of CambriaClientBuilder" +
		"Publisher (UEB)";
              D2Logger.debug(clname, mn, "DEBUG", d2msg);
	      pub = new CambriaClientBuilders.PublisherBuilder ()
	      .usingHosts ( uebIP )
	      .onTopic ( uebTopic )
	      .limitBatch ( maxBatchSize, maxAgeMs )
	      .enableCompresion ( withGzip )
	      .authenticatedBy ( apiKey, apiSecret )
	      .build ()
            ;
	    } catch (Exception ex)
	    {
               d2msg = "CambriaClientbuilders.PublisherBuilder failed";
               D2Logger.debug(clname, mn, "DEBUG", d2msg);
	       D2Logger.error(clname, mn, "INFO", d2msg);
	    }
	 } 
         d2msg = "Completed creation of CambriaClientBuilder Publisher";
         D2Logger.debug(clname, mn, "DEBUG", d2msg);

         int num=0;
         try
         {
            for(num=0; num<maxBatchSize; num++)
            {
               inrec = bq.take();
	       d2msg = "Syslog retrieved from blockingQueue: " + inrec;
	       D2Logger.debug(clname, mn, "DEBUG", d2msg);
               byte[] inrecb = inrec.getBytes();
           
           String msgToPub = updateJson(inrec);
           d2msg = "Syslog to be pusblished: " + msgToPub;
           D2Logger.debug(clname, mn, "DEBUG", d2msg);
           
	       pub.send("dcaeCommonSyslog", msgToPub);
	    }
            d2msg = "Sending " + num + " syslogs to UEB";
            D2Logger.debug(clname, mn, "DEBUG", d2msg);
	    final List stuck = pub.close ( 20, TimeUnit.SECONDS );
            if ( stuck.size () > 0 )
            {
               d2msg = num + " Syslogs not sent to UEB";
            }
            else
            {
               d2msg = num + " Syslogs successfully sent to UEB";
            }
            D2Logger.debug(clname, mn, "DEBUG", d2msg);
         } catch (Exception ex)
	 {
	    d2msg = "Exception: " + ex;
            D2Logger.debug(clname, mn, "DEBUG", d2msg);
            D2Logger.error(clname, mn, "INFO", d2msg);
         }
      }
   }
   
   private String updateJson (String syslogJsonStr) {
	   
	   try {
		   
		JSONObject jo = new JSONObject(syslogJsonStr);
		
		   //1st let's set the SyslogSev based on Priority
		
		   if ( jo.has("Priority") && !jo.getString("Priority").isEmpty() ) {
				int sev = Integer.valueOf(jo.getString("Priority")) % 8;
				
				if ( sev == 1 || sev == 2 ) {
					jo.put("syslogSev", "High");
				}
				else if ( sev == 3 || sev == 4 ) {
					jo.put("syslogSev", "Medium");
				} 
				else if ( sev == 5 ) {
					jo.put("syslogSev", "Normal");
				} 
				else if ( sev == 6 || sev == 7 ) {
					jo.put("syslogSev", "Low");
				} 
				else {
					jo.put("syslogSev", "UNKNOWN");
				}
			}
			else {
				jo.put("syslogSev", "UNKNOWN");
			}
		   
		   //2nd let's check if we need to override eventStartTimestamp if it's default parse rule
		   
		   if ( jo.has("setEventStartTimestamp") ) {
			   if (jo.has("startEpochMicrosec") && !jo.getString("startEpochMicrosec").isEmpty() ) {
				   jo.put("eventStartTimestamp", jo.get("startEpochMicrosec"));
			   }
			   jo.remove("setEventStartTimestamp");
		   }
		   
		   return jo.toString();
		   
	} catch (NumberFormatException e) {
		 D2Logger.debug(clname, "setSyslogSevirty", "DEBUG", "NumberFormatException: " + e);
		 return syslogJsonStr;
	} catch (JSONException e) {
		D2Logger.debug(clname, "setSyslogSevirty", "DEBUG", "JSONException: " + e);
		return syslogJsonStr;
	}
	  
   }
}
