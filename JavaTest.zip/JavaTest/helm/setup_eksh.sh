#!/bin/sh

# Install ATT sudo and eksh packages
# Updated to configure sudo for RH5.5

OSSUDO=0
EKSH=0
if [[ `rpm -qa | grep -c eksh` = 0 ]]; then
  EKSH=1
fi

if [ -f /etc/redhat-release ]; then
  KER=`uname -r | cut -d- -f1`
  KERVER=`uname -r | cut -d- -f2 | cut -d. -f1`
  ARCH=`uname -i`
  case "$KER" in
    '2.6.9') echo "RHEL 4"
       if [ $EKSH = 1 ]; then
         # Install 32bit eksh regardless of arch.
         rpm -ivh /nas/common/security_tools/eksh/eksh-93.t-5.i386.rpm
       else
          echo "eksh already installed"
          exit 0
       fi
       ;;
    '2.6.18') echo "RHEL5"
       # setup eksh
       if [ $KERVER -ge 194 ]
       then 
         if [ $EKSH = 0 ]; then
           # remove eksh package
           yum -y remove eksh
         fi
         if [ -f /usr/localcw/bin/eksh ]; then
            /bin/rm -f /usr/localcw/bin/eksh
         fi
         mkdir -p /usr/localcw/bin
         ln -s /bin/ksh /usr/localcw/bin/eksh
         . /usr/localcw/opt/security/etc/sectools.conf
         [ -n "${COLLECTHOST}" ] && echo "/dev/udp/${COLLECTHOST}/514 0" > /etc/ksh_audit
       else 
         case "$ARCH" in
           'x86_64') if [ $EKSH = 1 ]; then
                rpm -ivh /nas/common/security_tools/eksh/eksh-93.t-5.x86_64.rpm
              else
                echo "eksh already installed"
                exit 0
              fi
              ;;
           'i386') if [ $EKSH = 1 ]; then
                rpm -ivh /nas/common/security_tools/eksh/eksh-93.t-5.i386.rpm
              else
                echo "eksh already installed"
                exit 0
              fi
              ;;
           *) echo "Unknown arch couldnt install eksh"
              exit 1
         esac
       fi
      ;;
    '2.6.32'| '3.10.0') echo "RHEL6 or RHEL7"
       # setup eksh
         if [ -f /usr/localcw/bin/eksh ]; then
            /bin/rm -f /usr/localcw/bin/eksh
         fi
         mkdir -p /usr/localcw/bin
         ln -s /bin/ksh /usr/localcw/bin/eksh
         . /usr/localcw/opt/security/etc/sectools.conf
         [ -n "${COLLECTHOST}" ] && echo "/dev/udp/${COLLECTHOST}/514 0" > /etc/ksh_audit
      ;;
    *) echo "Not on rhel 4,5,6 or 7 not installing eksh" ;;
  esac
else
   echo "Are you on redhat"
   exit 1
fi

