package com.att.gfp.sarea.sareaPD;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import com.att.gfp.data.ipagAlarm.AlarmDelegationType;
import com.att.gfp.data.ipagAlarm.EnrichedAlarm;
import com.att.gfp.helper.GFPFields;
import com.att.gfp.helper.StandardFields;
import com.att.gfp.helper.service_util;
import com.att.gfp.helper.GFPUtil;
import com.hp.uca.expert.alarm.Alarm;
import com.hp.uca.expert.alarm.AlarmCommon;
import com.hp.uca.expert.alarm.AlarmUpdater;
import com.hp.uca.expert.alarm.AlarmUpdater.UsualVar;
import com.hp.uca.expert.lifecycle.LifeCycleAnalysis;
import com.hp.uca.expert.scenario.Scenario;
import com.hp.uca.expert.scenario.ScenarioThreadLocal;
import com.hp.uca.expert.x733alarm.AttributeChange;
import com.hp.uca.expert.x733alarm.NetworkState;
import com.hp.uca.expert.x733alarm.PerceivedSeverity;

public class SareaCorrelationExtendedLifeCycle extends LifeCycleAnalysis {
	private static Logger log = LoggerFactory.getLogger(SareaCorrelationExtendedLifeCycle.class);

	private static ApplicationContext context = null;
	public SareaCorrelationExtendedLifeCycle(Scenario scenario) {
		super(scenario);
		if (context == null)
		{
			if (log.isInfoEnabled())
				log.info("Get Application Context.");
			context = scenario.getVPApplicationContext();
		}
		scenario.getGlobals();
	}

	@Override
	public AlarmCommon onAlarmCreationProcess(Alarm alarmx) {
		Alarm alarm = alarmx; 
		try {

			if (!(alarmx instanceof EnrichedAlarm))
				alarm = GFPUtil.populateEnrichedAlarmObj(alarmx);
			String axml = alarm.toXMLString();
			axml = axml.replaceAll("\\n", " ");
			log.info("Incoming alarm: "+axml);
			log.info("Enrichment: "+((EnrichedAlarm)alarm).toString());

			SareaAlarm sareaAlarm=null;

			try {
				sareaAlarm = new SareaAlarm(alarm);
			} catch (Exception e) {
				// this.getScenario().setStatusAndLogAndUpdateVPStatus(e.getMessage(), ScenarioStatus.Degraded);
				if (log.isInfoEnabled())
					log.info("Dropped the alarm: "+ e);
				return null;
			}

			if (sareaAlarm.getSeverity() == 4)
			{
				if (log.isInfoEnabled())
					log.info(alarm.getIdentifier() + ": Dropping the clear alarm as there is no corresponding active alarm.");
				return null;
			}

			String eventKey = sareaAlarm.getCustomFieldValue(GFPFields.EVENT_KEY);

			if (eventKey.equals("50004/2/2") || eventKey.equals("50004/2/58916876"))
			{
				if (log.isInfoEnabled())
					log.info("Health Trap. Send it to NOM.");
				sareaAlarm = null;
			}

			if (sareaAlarm == null)
			{
				if (log.isInfoEnabled())
					log.info("This alarm is not put to WM.");
			}
			else
			{
				if (log.isInfoEnabled()) {
					log.info("Put the alarm to WM.");
				}
			}
			return sareaAlarm;
		} catch (Exception e) {
			if (log.isInfoEnabled())
				log.info("Dropped this alarm = " + alarm.getIdentifier() + ",  as enrichment failed. ", e);
			return null;
		}
	}

	@Override
	public boolean onUpdateSpecificFieldsFromAlarm(Alarm newAlarm,
			AlarmCommon alarmInWorkingMemory) {

		String axml = newAlarm.toXMLString();
		axml = axml.replaceAll("\\n", " ");
		if (log.isInfoEnabled())
			log.info("Incoming updated alarm: "+axml);

		String eventKey = newAlarm.getCustomFieldValue(GFPFields.EVENT_KEY);
		String seqNum = newAlarm.getCustomFieldValue(GFPFields.SEQNUMBER);

		SareaAlarm sareaAlarm = null;

		try {
			sareaAlarm = new SareaAlarm(newAlarm);
		} catch (Exception e) {
			// this.getScenario().setStatusAndLogAndUpdateVPStatus(e.getMessage(), ScenarioStatus.Degraded);
			if (log.isInfoEnabled())
				log.info("failed to create sareaAlarm: "+ e);
			return true;
		}
		SareaAlarm ca = (SareaAlarm) alarmInWorkingMemory;

		int severity = sareaAlarm.getSeverity();
		if (severity == 4)
			log.info("Received a clear alarm.");
		// for now just handling the severity
		boolean ret = false;
		boolean isClear = false;
		Alarm alarmInWM = (Alarm) alarmInWorkingMemory;

		List<AttributeChange> attributeChangesSC = new ArrayList<AttributeChange>();
		List<AttributeChange> attributeChangesAVC = new ArrayList<AttributeChange>();
		AttributeChange attributeChange = null;

		if (alarmInWorkingMemory instanceof Alarm) {

			// Updating the Perceived Severity of the alarm in Working memory
			// only if the Alarm received is different.
			if (newAlarm.getPerceivedSeverity() != alarmInWM
					.getPerceivedSeverity()) {

				if (newAlarm.getPerceivedSeverity() == PerceivedSeverity.CLEAR
						&& alarmInWM.getNetworkState() == NetworkState.NOT_CLEARED) {

					isClear = true;
					attributeChange = new AttributeChange();
					attributeChange.setName(StandardFields.NETWORK_STATE);
					attributeChange.setNewValue(NetworkState.CLEARED.toString());
					attributeChange.setOldValue(alarmInWM.getNetworkState().toString());
					attributeChangesSC.add(attributeChange);

					attributeChange = new AttributeChange();
					attributeChange.setName(StandardFields.PERCEIVED_SEVERITY);
					attributeChange.setNewValue(PerceivedSeverity.CLEAR.toString());
					attributeChange.setOldValue(alarmInWM.getPerceivedSeverity().toString());
					attributeChangesAVC.add(attributeChange);

					// change clearence time of the alarm.
					attributeChange = new AttributeChange();
					attributeChange.setName(GFPFields.LAST_CLEAR_TIME);
					attributeChange.setNewValue(String.valueOf(System.currentTimeMillis()/1000));
					attributeChange.setOldValue(alarmInWM.getCustomFieldValue(GFPFields.LAST_CLEAR_TIME));
					attributeChangesAVC.add(attributeChange);
				} else {

					attributeChange = new AttributeChange();
					attributeChange.setName(StandardFields.PERCEIVED_SEVERITY);
					attributeChange.setNewValue(newAlarm.getPerceivedSeverity().toString());
					attributeChange.setOldValue(alarmInWM.getPerceivedSeverity().toString());
					attributeChangesAVC.add(attributeChange);
				}
			}

			if (!attributeChangesSC.isEmpty()) {
				ret = true;
			}

			if (!attributeChangesAVC.isEmpty()) {
				ret = true;
			}

		}

		if (isClear == true)
		{
			SareaAlarm a = (SareaAlarm) alarmInWorkingMemory;
			eventKey = a.getCustomFieldValue(GFPFields.EVENT_KEY);
			a.setSeverity(4);
			a.setCustomFieldValue(GFPFields.LAST_CLEAR_TIME, ""+System.currentTimeMillis()/1000);
			a.setCustomFieldValue(GFPFields.SEQNUMBER, newAlarm.getCustomFieldValue(GFPFields.SEQNUMBER));
			if("YES".equalsIgnoreCase(newAlarm.getCustomFieldValue(GFPFields.IS_GENERATED_BY_UCA)))
				a.setCustomFieldValue(GFPFields.IS_GENERATED_BY_UCA, "YES"); 
			if("YES".equalsIgnoreCase(newAlarm.getCustomFieldValue(GFPFields.IS_PURGE_INTERVAL_EXPIRED)))
				a.setCustomFieldValue(GFPFields.IS_PURGE_INTERVAL_EXPIRED, "YES"); 
			SareaAlarm ax = a;
			if (!(a instanceof EnrichedAlarm))
				// i assume a and ax are the same reference
				ax = (SareaAlarm)GFPUtil.populateEnrichedAlarmObj(a);
			if (ret == true)
			{
				if( ("YES".equalsIgnoreCase(ax.getCustomFieldValue(GFPFields.IS_GENERATED_BY_UCA))) ||
						("YES".equalsIgnoreCase(ax.getCustomFieldValue(GFPFields.IS_PURGE_INTERVAL_EXPIRED))) ) {
					log.trace("GFPUtil.forwardOrCascadeAlarm() Discarding the alarm as it is generated by UCA");
				}
				else {
					log.info("Send the clear alarm.");
					Scenario scenario = ScenarioThreadLocal.getScenario();
					service_util.forwardAlarmToNOM(scenario, ax);
					//GFPUtil.forwardOrCascadeAlarm(ax, AlarmDelegationType.FORWARD, null);
				}
				
				a.setIsClear(true);
				if (!attributeChangesSC.isEmpty()) {
					AlarmUpdater.updateAlarmFromAttributesChanges(alarmInWM, UsualVar.StateChange, attributeChangesSC, System.currentTimeMillis());
					alarmInWM.setHasStateChanged(true);
					ret = true;
				}

				if (!attributeChangesAVC.isEmpty()) {
					AlarmUpdater.updateAlarmFromAttributesChanges(alarmInWM, UsualVar.AVCChange, attributeChangesAVC, System.currentTimeMillis());
					alarmInWM.setHasAVCChanged(true);
					ret = true;
				}

			}
		}

		return ret;
	}
}
