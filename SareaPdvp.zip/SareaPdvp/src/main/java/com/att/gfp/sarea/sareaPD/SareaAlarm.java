package com.att.gfp.sarea.sareaPD;

import javax.xml.bind.annotation.XmlRootElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.att.gfp.data.ipagAlarm.EnrichedAlarm;
import com.hp.uca.expert.alarm.Alarm;
import com.hp.uca.expert.x733alarm.PerceivedSeverity;

@XmlRootElement
public class SareaAlarm extends EnrichedAlarm {

	private static Logger log = LoggerFactory.getLogger(SareaAlarm.class);
	private Boolean isClear = false;
	
	public SareaAlarm() {
		super();
	}
	
	public SareaAlarm(Alarm alarm) throws Exception {
		super(alarm);

		if (log.isInfoEnabled())
		log.info("SareaAlarm()");
	}
	
	public void setSeverity(int severity) {
		setCustomFieldValue("severity", Integer.toString(severity));
		switch(severity) {
	    case 0:
		setPerceivedSeverity(PerceivedSeverity.CRITICAL);
	    	break;
	    case 1:
		setPerceivedSeverity(PerceivedSeverity.MAJOR);
	    	break;
	    case 2:
		setPerceivedSeverity(PerceivedSeverity.MINOR);
	    	break;
	    case 3:
		setPerceivedSeverity(PerceivedSeverity.WARNING);
	    	break;
	    case 5:
		setPerceivedSeverity(PerceivedSeverity.INDETERMINATE);
	    	break;
	    case 4:
		setPerceivedSeverity(PerceivedSeverity.CLEAR);
	    	break;
	    default:
		setPerceivedSeverity(PerceivedSeverity.INDETERMINATE);
	    	break;
		}	
	}
	
	
	public Boolean getIsClear() {
		return isClear;
	}

	public void setIsClear(Boolean isClear) {
		this.isClear = isClear;
	}

}
