/**
 * This Problem is empty and ready to define methods to customize this problem
 */
package com.hp.uca.expert.vp.pd.problem;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.att.gfp.data.ipagAlarm.AlarmDelegationType;
import com.att.gfp.data.ipagAlarm.EnrichedAlarm;
import com.att.gfp.helper.GFPFields;
import com.att.gfp.helper.GFPUtil;
import com.att.gfp.helper.service_util;
import com.hp.uca.common.trace.LogHelper;
import com.hp.uca.expert.alarm.Alarm;
import com.hp.uca.expert.group.Group;
import com.hp.uca.expert.scenario.Scenario;
import com.hp.uca.expert.scenario.ScenarioThreadLocal;
import com.hp.uca.expert.vp.pd.core.ProblemDefault;
import com.hp.uca.expert.vp.pd.interfaces.ProblemInterface;

/**
 * @author MASSE
 * 
 */
public final class NsNotifyStartSuppression extends ProblemDefault implements
ProblemInterface {

	private static Logger log = LoggerFactory.getLogger(NsNotifyStartSuppression.class);

	public NsNotifyStartSuppression() {
		super();
		setLog(LoggerFactory.getLogger(NsNotifyStartSuppression.class));
	}
	/*@Override
public List<String> computeProblemEntity(Alarm a) throws Exception {
	// by default computeProblemEntity() adds the OriginatingManagedEntity in problemEntities so nothing needs to be done

	if (log.isTraceEnabled()) {
		LogHelper.enter(log, "computeProblemEntity()");
	}
	List<String> problemEntities = new ArrayList<String>();

	if (log.isTraceEnabled()) {
		LogHelper.exit(log, "computeProblemEntity() --- ProblemEntity="
				+ problemEntities.toString());
	}
	return problemEntities;
}*/

	
	@Override
	public boolean isMatchingCandidateAlarmCriteria(Alarm a) throws Exception {
		
		Scenario scenario = ScenarioThreadLocal.getScenario();
		
		if (log.isTraceEnabled()) {
			log.info("alarm = " + a.getIdentifier() + ", isMatchingCandidateAlarmCriteria() runs.");
			log.info("Sending out alarm: " + a.getCustomFieldValue("SeqNumber") + " with Identifier: " + a.getIdentifier()+" \n");
			service_util.forwardAlarmToNOM(scenario, a);
		}
		
		return true;
	}
	
	@Override
	public void whatToDoWhenSubAlarmIsAttachedToGroup(Alarm eAlarm, Group group) throws Exception {
		// TODO Auto-generated method stub
		//super.whatToDoWhenSubAlarmIsAttachedToGroup(alarm, group);

		Scenario scenario = ScenarioThreadLocal.getScenario();

		//EnrichedAlarm eAlarm = (EnrichedAlarm) alarm;
		if ( eAlarm.getCustomFieldValue(GFPFields.EVENT_KEY).equals("50007/100/10") ) {
			// this the trigger, send it to NOM always
			if (log.isTraceEnabled()) {
				log.info("Sending out trigger alarm: " + eAlarm.getCustomFieldValue("SeqNumber") + " with Identifier: " 
						+ eAlarm.getIdentifier()+" \n");
			}
			service_util.forwardAlarmToNOM(scenario, eAlarm);
			//GFPUtil.forwardOrCascadeAlarm(eAlarm, AlarmDelegationType.FORWARD, null);
		}
		else {
			if (eAlarm.getCustomFieldValue("component").contains("deviceType=<ARISTA 7200>")) {
				log.info("This event " + eAlarm.getCustomFieldValue("SeqNumber") + " and Identifier: "
						+ eAlarm.getIdentifier()+" has been suppressed\n");
			}
			else {
				log.info("Sending out alarm: " + eAlarm.getCustomFieldValue("SeqNumber") + " with Identifier: " + eAlarm.getIdentifier()+" \n");
				service_util.forwardAlarmToNOM(scenario, eAlarm);
				//GFPUtil.forwardOrCascadeAlarm(eAlarm, AlarmDelegationType.FORWARD, null);
			}

		}
	}



}