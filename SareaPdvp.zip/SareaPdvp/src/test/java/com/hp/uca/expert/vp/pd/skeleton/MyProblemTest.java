/**
 * 
 */
package com.hp.uca.expert.vp.pd.skeleton;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import junit.framework.JUnit4TestAdapter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.hp.uca.common.misc.Constants;
import com.hp.uca.expert.alarm.Alarm;
import com.hp.uca.expert.group.Group;
import com.hp.uca.expert.group.Qualifier;
import com.hp.uca.expert.testmaterial.AbstractJunitIntegrationTest;
import com.hp.uca.expert.testmaterial.ActionListener;
import com.hp.uca.mediation.action.client.Action;

/**
 * @author MASSE
 * 
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration
public class MyProblemTest extends AbstractJunitIntegrationTest {

	private static final int EXPECTED_NB_ACTIONS = 6;

	private static final int EXPECTED_NB_ALARMS = 3;

	private static final int EXPECTED_NB_GROUP = 1;

	private static Logger log = LoggerFactory.getLogger(MyProblemTest.class);

	private static final String SCENARIO_BEAN_NAME = "com.hp.uca.expert.vp.pd.ProblemDetection";

	private static final String ALARM_FILE = "src/main/resources/valuepack/pd/Alarms.xml";

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		log.info(Constants.TEST_START.val() + MyProblemTest.class.getName());
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		log.info(Constants.TEST_END.val() + MyProblemTest.class.getName()
				+ Constants.GROUP_ALT1_SEPARATOR.val());
	}

	// Way to run tests via ANT Junit
	public static junit.framework.Test suite() {
		return new JUnit4TestAdapter(MyProblemTest.class);
	}

	@Test
	@DirtiesContext
	public void testGeneratedPbAlarm() throws Exception {
		/*
		 * Initialize variables and Enable engine internal logs
		 */
		initTest(SCENARIO_BEAN_NAME, BMK_PATH);
		getScenario().setTestOnly(true);

		Map<String,String> keyValues = new HashMap<String,String>();
		keyValues.put("directiveName", "SET");
		keyValues.put("entityName", "operation_context .uca_network alarm_object 123456");

		ActionListener actionListener = new ActionListener(keyValues);

		getScenario().getSession().addEventListener(actionListener);

		/*
		 * Send alarms
		 */
		getProducer().sendAlarms(ALARM_FILE);

		/*
		 * Waiting for the last Alarm that should be updated by the rule itself
		 */
		waitingForActionInsertion(actionListener, 1 * SECOND, 10 * SECOND);
		Thread.sleep(5 * SECOND);

		/*
		 * Disable Rule Logger to close the file used to compare engine historical
		 * events
		 */
		closeRuleLogFiles(getScenario());

		if (log.isDebugEnabled()) {
			getScenario().getSession().dump();
		}

		/*
		 * Checking Actions Number
		 */
		Collection<Action> actions = getActionsFromWorkingMemory();
//		assertEquals(EXPECTED_NB_ACTIONS, actions.size());
		
		assertTrue(EXPECTED_NB_ACTIONS >= actions.size());

		/*
		 * Checking Alarm Number
		 */
		Collection<Alarm> alarms = getAlarmsFromWorkingMemory();
		assertEquals(EXPECTED_NB_ALARMS, alarms.size());

		/*
		 * Other kind of assert, using the lifecycleAnalysis hash map
		 */
		Alarm subalarm1 = getAlarm("operation_context .uca_network alarm_object 278");
		assertTrue(subalarm1.getCustomFieldValue("pb").equals(
				Qualifier.SubAlarm.toString()));

//		Alarm subalarm2 = getAlarm("operation_context .uca_network alarm_object 279");
//		assertTrue(subalarm2.getCustomFieldValue("pb").equals(
//				Qualifier.SubAlarm.toString()));

		Alarm trigger = getAlarm("operation_context .uca_network alarm_object 281");
		assertTrue(trigger.getCustomFieldValue("pb").equals(
				Qualifier.SubAlarm.toString()));
		
		Alarm pbAlarm = getAlarm("operation_context .uca_network alarm_object 123456");
		assertTrue(pbAlarm.getCustomFieldValue("pb").equals(
				Qualifier.ProblemAlarm.toString()));

		/*
		 * Checking Group Number
		 */
		Collection<Group> groups = getGroupsFromWorkingMemory();
		assertEquals(EXPECTED_NB_GROUP, groups.size());

	}

}