
package com.att.gfp.data.ipag.uebconsumer;

import java.io.IOException;
import java.util.LinkedList;
import java.util.UUID;
import org.json.JSONObject;
import java.util.Iterator;

import com.att.nsa.cambria.client.CambriaClientFactory;
import com.att.nsa.cambria.client.CambriaConsumer;

public class SimpleExampleConsumer
{
	public static void main ( String[] args ) throws IOException, InterruptedException
	{
		if ( args.length < 1 )
		{
			System.err.println ( "A topic name is required." );
			System.err.println ( "Usage: SimpleExampleConsumer topic_name [url group id]" );
			System.exit ( 1 );
		}

		final String topic = args[0];
		final String url = ( args.length > 1 ? args[1] : "zlxv8617.vci.att.com,zlxv8618.vci.att.com,zlxv8619.vci.att.com" );
		final String group = ( args.length > 2 ? args[2] : UUID.randomUUID ().toString () );
		final String id = ( args.length > 3 ? args[3] : "0" );

		long count = 0;
		long nextReport = 5000;

		final long startMs = System.currentTimeMillis ();
	
		final LinkedList<String> urlList = new LinkedList<String> ();
		for ( String u : url.split ( "," ) )
		{
			urlList.add ( u );
		}

		final CambriaConsumer cc = CambriaClientFactory.createConsumer ( urlList, topic, group, id, 10*1000, 1000 );
		while ( true )
		{
			for ( String msg : cc.fetch () )
			{
				System.out.println ( "" + (++count) + ": " + msg );
				System.out.println("\tDetailed Message:");
				JSONObject mjo= new JSONObject(msg);
				Iterator<?> mjoIter = mjo.keys();
				while (mjoIter.hasNext()){
					String mjoIterKey = (String) mjoIter.next();
					String mjoIterVal = (String) mjo.get(mjoIterKey);
					System.out.print("\t key = " + mjoIterKey);
					System.out.println("\t value = " + mjoIterVal);
				}
			}

			if ( count > nextReport )
			{
				nextReport += 5000;

				final long endMs = System.currentTimeMillis ();
				final long elapsedMs = endMs - startMs;
				final double elapsedSec = elapsedMs / 1000.0;
				final double eps = count / elapsedSec;
				System.out.println ( "Consumed " + count + " in " + elapsedSec + "; " + eps + " eps" );
			}
		}
	}
}
