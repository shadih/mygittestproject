package com.att.gfp.data.ipag.uebpublisher;

import com.att.nsa.cambria.client.CambriaClientFactory;
import com.att.nsa.cambria.client.CambriaPublisher;
import org.json.JSONObject;

public class Publish {

	static CambriaPublisher uebPub = null;
	
	public static void main(String[] args) {
		
		uebPub = CambriaClientFactory.createBatchingPublisher(
							"uebsb91kcdc.it.att.com,uebsb92kcdc.it.att.com,uebsb93kcdc.it.att.com", 
							"SH1986-TEST-TOPIC-IN", 
							1024, 
							10000, 
							false);
		
		JSONObject uebEvent = new JSONObject();
		
		uebEvent.put("field17", "value17");
		uebEvent.put("field18", "value18");
		
		try {
			System.out.println("Publishing event: " +  uebEvent.toString() );
			uebPub.send("val1", uebEvent.toString());
			System.out.println("OK");
		}
		catch (Exception e) {
			System.out.println("ERR: " + e + " text = " + e.toString());
			e.printStackTrace();
		}
	}
}
