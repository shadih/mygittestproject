package com.att.gfp.data.ipag.uebpublisher;

import com.att.nsa.cambria.client.CambriaClientFactory;
import com.att.nsa.cambria.client.CambriaPublisher;

import java.io.BufferedReader;
import java.io.FileReader;

import org.json.JSONObject;
import org.json.JSONTokener;

public class PublishFromFile {

	static CambriaPublisher uebPub = null;
	
	public static void main(String[] args) {
		
		uebPub = CambriaClientFactory.createBatchingPublisher(
							"uebsb91kcdc.it.att.com,uebsb92kcdc.it.att.com,uebsb93kcdc.it.att.com", 
							//"GFP-CPE-UCPE-VMS-ALARMS-PRECORR", 
							"SH1986-TEST-TOPIC-IN",
							1024, 
							10000, 
							false);
		
		try {
			
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("CCEDemo_Device_Unreachable.json")) );
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("CCEDemo_SwitchDown.json")) );
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("CCEDemo_Device_Unreachable_Clear.json")) );
			
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("CCEDemo_JCP_Device_Unreachable.json")) );
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("CCEDemo_VM_Down_alarm.json")) );
				
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("CCEDemo_Check_vmstates.json")) );
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("CCEDemo_Router_Down.json")) );
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("CCEDemo_vm_port.json")) );

				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("CCEDemo_Device_Down.json")) );
				
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("sampleTrap.json")) );
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("sampleEvent.json")) );
			
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("gfpdCorrelator/Device_PowerDown.json")) );
			
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("cpeAlarmStormMgr/events.json")) );
				
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("roadm/roadm_set.json")) );
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("roadm/roadm_clear.json")) );
				final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("roadm/roadm_update.json")) );
				
				
				System.out.println("Publishing event: " +  uebEvent.toString() );
				uebPub.send("test",uebEvent.toString());
				System.out.println("OK");
			
		}
		catch (Exception e) {
			System.out.println("ERR: " + e + " text = " + e.toString());
			e.printStackTrace();
		}
		uebPub.close();
		System.exit(0);
}
}
