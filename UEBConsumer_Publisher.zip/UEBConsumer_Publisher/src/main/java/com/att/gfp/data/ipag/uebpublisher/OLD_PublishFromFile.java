package com.att.gfp.data.ipag.uebpublisher;

import com.att.nsa.cambria.client.CambriaClientFactory;
import com.att.nsa.cambria.client.CambriaPublisher;

import java.io.BufferedReader;
import java.io.FileReader;

import org.json.JSONObject;
import org.json.JSONTokener;

public class OLD_PublishFromFile {

	static CambriaPublisher uebPub = null;
	
	public static void main(String[] args) {
		
		uebPub = CambriaClientFactory.createBatchingPublisher(
							"uebsb91kcdc.it.att.com,uebsb92kcdc.it.att.com,uebsb93kcdc.it.att.com", 
							"GFP-IP-PPD-ALARMS-VOIP-VUSP-shdev", 
							1024, 
							10000, 
							false);
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader("alarmsToPublish"));
			String line = ""; 
			while ( (line = reader.readLine()) != null ) 
			{
				if ( line.startsWith("#") ) { continue; }
				line.trim();
				final JSONObject uebEvent = new JSONObject ( new JSONTokener (line) );
				System.out.println("Publishing event: " +  uebEvent.toString() );
				uebPub.send("test",uebEvent.toString());
				System.out.println("OK");
			}
			reader.close();
		}
		catch (Exception e) {
			System.out.println("ERR: " + e + " text = " + e.toString());
			e.printStackTrace();
		}
		uebPub.close();
		System.exit(0);
	}
}
