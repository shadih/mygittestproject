package com.att.gfp.data.ipag.uebconsumer;

import java.io.IOException;
import java.util.LinkedList;
import org.json.JSONObject;
import java.util.Iterator;
import com.att.nsa.cambria.client.CambriaClientFactory;
import com.att.nsa.cambria.client.CambriaConsumer;

public class SimpleExampleConsumer2
{
	public static void main ( String[] args ) throws IOException, InterruptedException
	{
	
		final String topic = "SH1986-TEST-TOPIC-IN";
		final String url = "uebsb91kcdc.it.att.com,uebsb92kcdc.it.att.com,uebsb93kcdc.it.att.com";
		final String group = "TestHP-TestGroup";
		final String id = "SH1986";

		long count = 0;
		
		final LinkedList<String> urlList = new LinkedList<String> ();
		for ( String u : url.split ( "," ) )
		{
			urlList.add ( u );
		}

		System.out.println("creating consumer");
		
		final CambriaConsumer cc = CambriaClientFactory.createConsumer ( urlList, topic, group, id, 10000, 1000 );
		
		while ( true )
		{
			for ( String msg : cc.fetch () )
			{
				System.out.println ( "" + (++count) + ": " + msg );
				System.out.println("\tDetailed Message:");
				JSONObject mjo= new JSONObject(msg);
				Iterator<?> mjoIter = mjo.keys();
				while (mjoIter.hasNext()){
					String mjoIterKey = (String) mjoIter.next();
					String mjoIterVal = (String) mjo.get(mjoIterKey);
					System.out.print("\t key = " + mjoIterKey);
					System.out.println("\t value = " + mjoIterVal);
				}
			}
			Thread.sleep(5000);
		}
	}
}
