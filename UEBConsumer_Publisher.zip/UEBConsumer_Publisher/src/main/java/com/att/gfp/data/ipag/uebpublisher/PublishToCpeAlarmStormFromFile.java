package com.att.gfp.data.ipag.uebpublisher;

import com.att.nsa.cambria.client.CambriaClientFactory;
import com.att.nsa.cambria.client.CambriaPublisher;

import java.io.BufferedReader;
import java.io.FileReader;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

public class PublishToCpeAlarmStormFromFile {

	static CambriaPublisher uebPub = null;
	
	public static void main(String[] args) {
		
		uebPub = CambriaClientFactory.createBatchingPublisher(
							"uebsb91kcdc.it.att.com,uebsb92kcdc.it.att.com,uebsb93kcdc.it.att.com", 
							"GFP-CPE-UCPE-VMS-ALARMS-DEV", 
							1024, 
							10000, 
							false);
		
		try {

			JSONArray a = new JSONArray ( new JSONTokener ( new FileReader("cpeAlarmStormMgr/events_to_publish.json") ) );
			
			for ( int i = 0; i < a.length (); i++ )
			{
				final JSONObject uebEvent = a.getJSONObject ( i );
				System.out.println("Publishing event: " +  uebEvent.toString() );
				uebPub.send("test",uebEvent.toString());
				System.out.println("OK");
			}

		}
		catch (Exception e) {
			System.out.println("ERR: " + e + " text = " + e.toString());
			e.printStackTrace();
		}
		uebPub.close();
		System.exit(0);
}
}
