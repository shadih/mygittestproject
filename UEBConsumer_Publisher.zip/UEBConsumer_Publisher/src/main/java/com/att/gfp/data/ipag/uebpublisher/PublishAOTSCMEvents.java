package com.att.gfp.data.ipag.uebpublisher;

import com.att.nsa.cambria.client.CambriaClientFactory;
import com.att.nsa.cambria.client.CambriaPublisher;

import java.io.BufferedReader;
import java.io.FileReader;

import org.json.JSONObject;
import org.json.JSONTokener;

public class PublishAOTSCMEvents {

	static CambriaPublisher uebPub = null;
	
	public static void main(String[] args) {
		
		uebPub = CambriaClientFactory.createBatchingPublisher(
							"uebsb91kcdc.it.att.com,uebsb92kcdc.it.att.com,uebsb93kcdc.it.att.com", 
							"AOTSCM-TKT-STATUS-TRANSITION-shdev", 
							1024, 
							10000, 
							false);
		
		try {
			
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("aots-cm-PlannedStartTimeReached-1event.json")) );
				final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("aots-cm-StatusChange-1event.json")) );
				//final JSONObject uebEvent = new JSONObject ( new JSONTokener (new FileReader("PlannedDateChange.json")) );
				System.out.println("Publishing event: " +  uebEvent.toString() );
				uebPub.send("test",uebEvent.toString());
				System.out.println("OK");
			
		}
		catch (Exception e) {
			System.out.println("ERR: " + e + " text = " + e.toString());
			e.printStackTrace();
		}
		uebPub.close();
		System.exit(0);
	}
}
