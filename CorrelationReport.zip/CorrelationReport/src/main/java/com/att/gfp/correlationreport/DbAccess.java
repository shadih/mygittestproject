package com.att.gfp.correlationreport;

import java.sql.*;
import java.util.ArrayList;


public class DbAccess {

	private Connection conn = null;
	private String dBUrl;
	
	public DbAccess (String dBUrl) {
		this.dBUrl = dBUrl;
	}
	
	public void connDb() {

		try {
			System.out.print("Connecting to DB using: " + dBUrl + "...");
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection(dBUrl);
			System.out.println("Done\n");

		} catch(SQLException sqle) {
			System.out.println("connDb() SQLException = " + sqle);
			sqle.printStackTrace();
			disconnDb();
			System.exit(1);
		} catch(Exception e) {
			System.out.println("connDb() Exception = " + e);
			e.printStackTrace();
			disconnDb();
			System.exit(1);
		}
	}
	
	public ArrayList<Object> qryDb(String sqlqry, String[] fieldsArr)  {

		System.out.println("Running qryDb...");
		Statement stmt = null;
		ResultSet rs = null;
		
		int count = 0;
		StringBuilder qryResult = new StringBuilder();
		ArrayList<String> qryOut = new ArrayList<String>();
		ArrayList<Object> returnArr = new ArrayList<Object>();
  
		qryResult.append("<table><tr>");
		for (int i=0;i<fieldsArr.length;i=i+2){ 
			qryResult.append("<td align=\"center\"><font color=\"red\">" + 
							fieldsArr[i] + "</font></td>");
		}
		qryResult.append("</tr>");
		
		try {
			stmt = conn.createStatement();
	    	rs = stmt.executeQuery(sqlqry);
	    	int fieldInc = 0;	    	
	    	while(rs.next()) {
	    		fieldInc = 0;
	    		qryResult.append("<tr>");
	    		for (int i=1;i<fieldsArr.length;i=i+2){ 
	    			String type = fieldsArr[i];
	    			fieldInc++;
					if ( type.equals("Int") ) {
						int val = rs.getInt(fieldInc);
						qryResult.append("<td align=\"center\">" +
								         val + "</td>");
						qryOut.add(Integer.toString(val));
					}
					else if ( type.equals("String") ) {
						String val = rs.getString(fieldInc);
						qryResult.append("<td align=\"center\">" +
								         val + "</td>");
						qryOut.add(val);
					}	
				}
	    		qryResult.append("</tr>");
	    		count++;			
	    	}
	    	qryResult.append("</table><br>");
	    	qryResult.append("Number of rows returned = " + count + "<br>");		
		    System.out.println("Done. Number of rows: " + count + "\n");
		    
		} catch(SQLException sqle) {
			System.out.println("qryDb() SQLException = " + sqle);
			sqle.printStackTrace();
			disconnDb();
			System.exit(1);
		} catch(Exception e) {
			System.out.println("qryDb() Exception = " + e);
			e.printStackTrace();
			disconnDb();
			System.exit(1);
		} finally {
			try { rs.close(); } catch (Exception e) { System.out.println("rs.close() Exception = " + e); }
			try { stmt.close(); } catch (Exception e) { System.out.println("stmt.close( Exception = " + e); }
		}
		returnArr.add(qryResult);
		returnArr.add(qryOut);
		return returnArr;
	}
	
	public void disconnDb() {
		System.out.print("Disconnecting from DB...");
		if (conn != null) {
			try {
				conn.close();
				System.out.println("Done\n");
			} catch (SQLException e) {
	    	   System.out.println("failed to disconnect from the database SQLException: " + e);
	    	   e.printStackTrace();
			}
		}
	}
	
	public static String getDbUrl (String env) {
		String DB_USER, DB_PASSWD, DB_HOST, DB_SID, dBUrl;
		int DB_PORT;
				
		if ( env.equalsIgnoreCase("Prod") ) {
			DB_USER = (String) CorrReportStart.jsonObject.get("Prod_Alarm_DB_USER");
			DB_PASSWD = (String) CorrReportStart.jsonObject.get("Prod_Alarm_DB_PASSWD");
			DB_HOST = (String) CorrReportStart.jsonObject.get("Prod_Alarm_DB_HOST");
			DB_PORT = Integer.parseInt((String) CorrReportStart.jsonObject.get("Prod_Alarm_DB_PORT"));
			DB_SID = (String) CorrReportStart.jsonObject.get("Prod_Alarm_DB_SID");
		}
		else if ( env.equalsIgnoreCase("Prod_Bridge") ) {
			DB_USER = (String) CorrReportStart.jsonObject.get("Prod_Bridge_DB_USER");
			DB_PASSWD = (String) CorrReportStart.jsonObject.get("Prod_Bridge_DB_PASSWD");
			DB_HOST = (String) CorrReportStart.jsonObject.get("Prod_Bridge_DB_HOST");
			DB_PORT = Integer.parseInt((String) CorrReportStart.jsonObject.get("Prod_Bridge_DB_PORT"));
			DB_SID = (String) CorrReportStart.jsonObject.get("Prod_Bridge_DB_SID");
		}
		else if ( env.equalsIgnoreCase("UAT") ) {
			DB_USER = (String) CorrReportStart.jsonObject.get("UAT_DB_USER");
			DB_PASSWD = (String) CorrReportStart.jsonObject.get("UAT_DB_PASSWD");
			DB_HOST = (String) CorrReportStart.jsonObject.get("UAT_DB_HOST");
			DB_PORT = Integer.parseInt((String) CorrReportStart.jsonObject.get("UAT_DB_PORT"));
			DB_SID = (String) CorrReportStart.jsonObject.get("UAT_DB_SID");
		}
		else if ( env.equalsIgnoreCase("ST") ) {
			DB_USER = (String) CorrReportStart.jsonObject.get("ST_DB_USER");
			DB_PASSWD = (String) CorrReportStart.jsonObject.get("ST_DB_PASSWD");
			DB_HOST = (String) CorrReportStart.jsonObject.get("ST_DB_HOST");
			DB_PORT = Integer.parseInt((String) CorrReportStart.jsonObject.get("ST_DB_PORT"));
			DB_SID = (String) CorrReportStart.jsonObject.get("ST_DB_SID");
		}
		else if ( env.equalsIgnoreCase("Dev") ) {
			DB_USER = (String) CorrReportStart.jsonObject.get("Dev_DB_USER");
			DB_PASSWD = (String) CorrReportStart.jsonObject.get("Dev_DB_PASSWD");
			DB_HOST = (String) CorrReportStart.jsonObject.get("Dev_DB_HOST");
			DB_PORT = Integer.parseInt((String) CorrReportStart.jsonObject.get("Dev_DB_PORT"));
			DB_SID = (String) CorrReportStart.jsonObject.get("Dev_DB_SID");
		}
		else {
			System.out.println("Invalid Env... Exit");
			System.exit(1);
			return "ERROR";
		}
		dBUrl = "jdbc:oracle:thin:" + DB_USER + "/" + DB_PASSWD + "@" + 
		         DB_HOST + ":" + DB_PORT + ":" + DB_SID;	
		return dBUrl;
	}
	
}
