package com.att.gfp.correlationreport;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;


public class DailyAlarmVolumes {
	
	DbAccess dB;
	FileWriter reportWriter;
	String previousDay, previousDayReport;
	String reportName;
	
	DailyAlarmVolumes(DbAccess dbA, FileWriter repWr) {	
		
		this.reportWriter = repWr;
		
		previousDay = CorrReportUtils.getPreviousDayForSql();
		previousDayReport = CorrReportUtils.getPreviousDayForReport();
		
		this.dB = dbA;
		
		System.out.println("Previous Day : " + previousDay + " ...");
		
        reportName = "GFP-Mobility Daily Alarm Volumes";
        Date TS = new Date();
        System.out.println("Processing Report : " + reportName + " ...on " +  CorrReportStart.TsDf.format(TS));
    }						

	
	public void generateReport() throws Exception {
		
		String sql = "select distinct corrstatus, count(*) from gfpalarm.message_status partition (ms_part_" +
				     previousDay + ") where aggname is not NULL and aggname not in ('BL_A6_AGG2','LT_155_BLK1','UN_A5_AGG1') group by corrstatus";
		String[] fieldsArr = {"corrstatus", "Int", "count", "Int"};
		System.out.println("Running sql : " + sql + " ...");
		try {
			
			reportWriter.write("Report : <h2>" + reportName + "</h2>");
			ArrayList<Object> qryResults = new ArrayList<Object>();
			qryResults = dB.qryDb(sql, fieldsArr);
			ArrayList<String> qryOut = new ArrayList<String>();
			qryOut = (ArrayList<String>) qryResults.get(1);
			Iterator<String> qryOutIterator = qryOut.iterator(); 
			int totCnt = 0; int noCorrCnt = 0; int tpvpCnt = 0; int bothCnt = 0; int pdvpCnt = 0;
		
			while (qryOutIterator.hasNext()) {
				int corrstatus = Integer.parseInt(qryOutIterator.next());
				int count = Integer.parseInt(qryOutIterator.next());
				totCnt += count;
				if (corrstatus == CorrReportStart.NO_CORRELATION_CORRSTATUS) {
					noCorrCnt += count;
				}
				else if ( (corrstatus == CorrReportStart.TPVP_CORRSTATUS1) || (corrstatus == CorrReportStart.TPVP_CORRSTATUS2) ) {
					tpvpCnt += count;
				}
				else if ( (corrstatus == CorrReportStart.BOTH_CORRSTATUS1) || (corrstatus == CorrReportStart.BOTH_CORRSTATUS2) ) {
					bothCnt += count;
				}
				else if ( (corrstatus == CorrReportStart.PDVP_CORRSTATUS1) || (corrstatus == CorrReportStart.PDVP_CORRSTATUS2) ) {
					pdvpCnt += count;
				}
			}
			if ( totCnt == 0 ) {
				reportWriter.write("<br><b>No Data returned from SQL query : <br>" + sql );
				reportWriter.write("<br><br>No Report will be generated <br></b><br>" );
				return;
			}
		
			sql = "select distinct corrstatus, alarmtype, count(*) from gfpalarm.message_status partition (ms_part_" +
					previousDay + ") where aggname is not NULL and aggname not in ('BL_A6_AGG2','LT_155_BLK1','UN_A5_AGG1') group by corrstatus, alarmtype";
		
			String[] fieldsArr2 = {"corrstatus", "Int", "alarmtype", "Int", "count", "Int"};
			System.out.println("Running sql : " + sql + " ...");
			qryResults = new ArrayList<Object>();
			qryResults = dB.qryDb(sql, fieldsArr2);
			qryOut = new ArrayList<String>();
			qryOut = (ArrayList<String>) qryResults.get(1);
			qryOutIterator = null;
			qryOutIterator = qryOut.iterator(); 
			int pdvpDidPart = 0; int pdvpDidNotPart = 0; 
			int tpvpDidPart = 0; int tpvpDidNotPart = 0;
			int bothDidPart = 0; int bothDidNotPart = 0;
			totCnt = 0;
		
			while (qryOutIterator.hasNext()) {
				int corrstatus = Integer.parseInt(qryOutIterator.next());
				int alarmtype = Integer.parseInt(qryOutIterator.next());
				int count = Integer.parseInt(qryOutIterator.next());
				totCnt += count;
				if ( (corrstatus == CorrReportStart.PDVP_DIDNOT_PARTCORR_CORRSTATUS1) || (corrstatus == CorrReportStart.PDVP_DIDNOT_PARTCORR_CORRSTATUS2) ) {
					if ( alarmtype == CorrReportStart.PDVP_DIDNOT_PARTCORR_ALARMTYPE) {
						pdvpDidNotPart += count;
					}
					else {
						pdvpDidPart += count;
					}
				}
				else if ( (corrstatus == CorrReportStart.TPVP_DIDNOT_PARTCORR_CORRSTATUS1) || (corrstatus == CorrReportStart.TPVP_DIDNOT_PARTCORR_CORRSTATUS2) ) {
					if ( alarmtype == CorrReportStart.TPVP_DIDNOT_PARTCORR_ALARMTYPE) {
						tpvpDidNotPart += count;
					}
					else {
						tpvpDidPart += count;
					}
				}
				else if ( (corrstatus == CorrReportStart.BOTH_DIDNOT_PARTCORR_CORRSTATUS1) || (corrstatus == CorrReportStart.BOTH_DIDNOT_PARTCORR_CORRSTATUS2) ) {
					if ( alarmtype == CorrReportStart.BOTH_DIDNOT_PARTCORR_ALARMTYPE) {
						bothDidNotPart += count;
					}
					else {
						bothDidPart += count;
					}
				}
			}
		
			if ( totCnt == 0 ) {
				reportWriter.write("<br><b>No Data returned from SQL query : <br>" + sql );
				reportWriter.write("<br><br>Partial Report will be generated <br></b><br>" );
			}

			reportWriter.write("<br><br><table><tr>");		
			reportWriter.write("<td colspan=\"4\" align=\"center\"><b><i>GFP-Mobility Daily Alarm Volumes</i></b> for " + previousDayReport + 
							" -  Total Daily Alarm Count - " + totCnt +  "</td>");
			reportWriter.write("</tr><tr>");
			reportWriter.write("<td align=\"center\"> Total Alarms Sent to Correlation Engines </td>");
			reportWriter.write("<td align=\"center\" colspan=\"3\">" + (totCnt - noCorrCnt) + " (" + CorrReportUtils.calPercent(totCnt-noCorrCnt, totCnt) + "%)</td>");
			reportWriter.write("</tr><tr><td colspan=\"4\" bgcolor=\"grey\" height=\"20\"></td></tr>");
			
			if ( totCnt == 0 ) {
				reportWriter.write("</table>");
				return;
			}
			
			reportWriter.write("<tr><td>Alarms Did Participated in Correlation</td>");
			reportWriter.write("<td>TPVP</td><td>PDVP</td><td>Both</td></tr>");
			reportWriter.write("<tr><td></td>");
			reportWriter.write("<td>" + tpvpDidPart + " (" + CorrReportUtils.calPercent(tpvpDidPart, tpvpCnt) + "%)");
			reportWriter.write("<td>" + pdvpDidPart + " (" + CorrReportUtils.calPercent(pdvpDidPart, pdvpCnt) + "%)");
			reportWriter.write("<td>" + bothDidPart + " (" + CorrReportUtils.calPercent(bothDidPart, bothCnt) + "%)");
			reportWriter.write("</tr><tr><td colspan=\"4\" bgcolor=\"grey\" height=\"20\"></td></tr>");
			reportWriter.write("<tr><td>Alarms Did Not Participated in Correlation</td>");
			reportWriter.write("<td>" + tpvpDidNotPart + " (" + CorrReportUtils.calPercent(tpvpDidNotPart, tpvpCnt) + "%)");
			reportWriter.write("<td>" + pdvpDidNotPart + " (" + CorrReportUtils.calPercent(pdvpDidNotPart, pdvpCnt) + "%)");
			reportWriter.write("<td>" + bothDidNotPart + " (" + CorrReportUtils.calPercent(bothDidNotPart, bothCnt) + "%)");
			reportWriter.write("</tr></table>");
			reportWriter.write("<hr><br><br>");
			
			System.out.println();
		}
		catch (Exception e) {
			System.out.println("Cannot run DailyAlarmVolumes.generateRep(), Exception =  " + e);
			e.printStackTrace();
		}
	}
	
}
