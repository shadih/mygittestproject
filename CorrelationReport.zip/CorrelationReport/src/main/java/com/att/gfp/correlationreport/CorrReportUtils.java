package com.att.gfp.correlationreport;

import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;


public class CorrReportUtils {
	
	static FileWriter reportWriter;
	static SimpleDateFormat sqlDf = new SimpleDateFormat("yyyyMMdd");
	static SimpleDateFormat reportDf = new SimpleDateFormat("MM/dd/yyyy");
	
	CorrReportUtils(FileWriter repWr) {	
		
		reportWriter = repWr;

	}
	
	public static String getPreviousDayForSql() {
		String sqlPrevDay = "";
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, -1);
		sqlPrevDay = sqlDf.format(cal.getTimeInMillis());
		return sqlPrevDay;
	}

	public static String getPreviousDayForReport() {
		String repPrevDay = "";
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DAY_OF_MONTH, -1);
		repPrevDay = reportDf.format(cal.getTimeInMillis());
		return repPrevDay;
	}
	
	public static void beginHtmlOut(String env) {
		try {
			
			reportWriter.write("<!DOCTYPE html><html><head>");
			reportWriter.write("<style> table, th, td {" +
			    	   "border: 1px solid black; " +
			    	   "border-collapse: collapse; " +
			    	   "th, td {" +
			    	   "padding: 15px;} </style>");
			reportWriter.write("<title>Correlation Report</title></head><body>");
			reportWriter.write("<h1>Correlation Report (from " + env + ")</h1><hr>");

		}
		catch (Exception e) {
				System.out.println("Error writing in beginHtmlOut(), Exception = " + e);
				e.printStackTrace();
		}
	}

	public static void endHtmlOut() {
		try {
			reportWriter.write("</body></html>");
		}
		catch (Exception e) {
			System.out.println("Error writing in endHtmlOut(), Exception = " + e);
			e.printStackTrace();
		}
	}
	
	public static String calPercent(int num1, int num2) {
		String formatedPercent;
		if ( num2 == 0 ) {
			formatedPercent = "Divide by 0 ERROR - when attempting to get percentage for num1 = " + num1 + " over num2 = " + num2 + ".";
			return formatedPercent;
		}
		double percent = 0;
		percent = ( ( (double) num1 ) / ( (double) num2 ) ) * 100;
		formatedPercent = String.format("%.1f", percent);
		return formatedPercent;
	}
	
	public static void sendMail(String repFileName, String env) {	

	
		String tmpFile = (String) CorrReportStart.jsonObject.get("uuencode tempFile");
		String uuencode = (String) CorrReportStart.jsonObject.get("uuencode Path");
		String mailx = (String) CorrReportStart.jsonObject.get("mailx Path");
		String subject = "GFP-Mobility Correlation Report for " + getPreviousDayForReport() + " From " + env;
		String mailTo = (String) CorrReportStart.jsonObject.get("mailTo");
	
		ArrayList<String[]> mailCommands = new ArrayList<String[]>();

		String uuencodeCmd1Cli = uuencode + " " + repFileName + " " + repFileName + " > " + tmpFile;
		String[] uuencodeCmd1 = {"/bin/sh", "-c", uuencodeCmd1Cli};
		mailCommands.add(uuencodeCmd1);
		String mailCmdCli = "cat " + tmpFile + " | " + mailx + " -s \"" + subject + "\" \"" + mailTo + "\"";
		String[] mailCmd = {"/bin/sh", "-c", mailCmdCli};
		mailCommands.add(mailCmd);
	
		Iterator<String[]> mailCommandsIterator = mailCommands.iterator();
		while (mailCommandsIterator.hasNext()) {
			String[] cmd = mailCommandsIterator.next();
			System.out.print("Running command: "+ Arrays.toString(cmd) + "...");
			String cmdOut = runCli(cmd);
			if ( cmdOut.equals("OK") ) {
				System.out.println(cmdOut);
			}
			else {
				System.out.print("ERROR: \n");
				System.out.println(cmdOut);
			}
		}
	}

	public static String runCli(String[] cmd) {

		String cmdOutput = "";
		BufferedReader reader = null;;
		BufferedReader readerStdErr = null;
	
		try {
			Process proc = Runtime.getRuntime().exec(cmd);
		
			reader 		= new BufferedReader (new InputStreamReader(proc.getInputStream()));
			readerStdErr = new BufferedReader (new InputStreamReader(proc.getErrorStream()));
			String line = "";
        
			while ( (line = reader.readLine()) != null ) {
				cmdOutput+=(line + "\n");
			}
			while ( (line = readerStdErr.readLine()) != null ) {
				cmdOutput+=(line + "\n");
			}

			int wf = proc.waitFor();
		
			if ( wf == 0 ) {
				cmdOutput = "OK";
			}
		}
		catch (Exception e) {
			System.out.println("Error in sending mail runCli, Exception = " + e);
			e.printStackTrace();
		}
	
		try {
			reader.close();
			readerStdErr.close();
		}
		catch (Exception e) {
			System.out.println("Error in closing BufferedReaders in runCli, Exception = " + e);
			e.printStackTrace();
		}
		return cmdOutput;
	}
	
	public static String sortMap(Map<String, Integer> unsortedMap) {
		
        Set<Entry<String, Integer>> set = unsortedMap.entrySet();
        List<Entry<String, Integer>> list = new ArrayList<Entry<String, Integer>>(set);
        Collections.sort( list, new Comparator<Map.Entry<String, Integer>>()
        {
            public int compare( Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2 )
            {
                return (o2.getValue()).compareTo( o1.getValue() );
            }
        } );
        String sortedMap = "";
        for(Map.Entry<String, Integer> entry:list){
        	sortedMap += "<tr><td align=\"center\">" + entry.getKey() + "</td><td align=\"center\">" + entry.getValue() + "</td></tr>";
        }
        return sortedMap;
	}
	
}
