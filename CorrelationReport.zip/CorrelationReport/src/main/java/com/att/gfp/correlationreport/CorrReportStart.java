package com.att.gfp.correlationreport;

import java.io.FileWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.FileReader;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class CorrReportStart {
	
	static public JSONObject jsonObject;
	final static String configFile = "corr_rep_conf.json";
	final static SimpleDateFormat TsDf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss zzz");
	static int NO_CORRELATION_CORRSTATUS = 0;
	static int TPVP_CORRSTATUS1 = 0;
	static int TPVP_CORRSTATUS2 = 0;
	static int BOTH_CORRSTATUS1 = 0;
	static int BOTH_CORRSTATUS2 = 0;
	static int PDVP_CORRSTATUS1 = 0;
	static int PDVP_CORRSTATUS2 = 0;
	static int PDVP_DIDNOT_PARTCORR_ALARMTYPE = 0;
	static int PDVP_DIDNOT_PARTCORR_CORRSTATUS1 = 0;
	static int PDVP_DIDNOT_PARTCORR_CORRSTATUS2 = 0;
	static int TPVP_DIDNOT_PARTCORR_ALARMTYPE = 0;
	static int TPVP_DIDNOT_PARTCORR_CORRSTATUS1 = 0;
	static int TPVP_DIDNOT_PARTCORR_CORRSTATUS2 = 0;
	static int BOTH_DIDNOT_PARTCORR_ALARMTYPE = 0;
	static int BOTH_DIDNOT_PARTCORR_CORRSTATUS1 = 0;
	static int BOTH_DIDNOT_PARTCORR_CORRSTATUS2 = 0;

	public static void main(String[] args) {
		Date TS = new Date();
		System.out.println();
		System.out.println("Starting CorrReport ... on " +  TsDf.format(TS));
		System.out.println();
		readConfig(configFile);
		NO_CORRELATION_CORRSTATUS = Integer.parseInt((String) jsonObject.get("NO_CORRELATION_CORRSTATUS"));
		TPVP_CORRSTATUS1 = Integer.parseInt((String) jsonObject.get("TPVP_CORRSTATUS1"));
		TPVP_CORRSTATUS2 = Integer.parseInt((String) jsonObject.get("TPVP_CORRSTATUS2"));
		BOTH_CORRSTATUS1 = Integer.parseInt((String) jsonObject.get("BOTH_CORRSTATUS1"));
		BOTH_CORRSTATUS2 = Integer.parseInt((String) jsonObject.get("BOTH_CORRSTATUS2"));
		PDVP_CORRSTATUS1 = Integer.parseInt((String) jsonObject.get("PDVP_CORRSTATUS1"));
		PDVP_CORRSTATUS2 = Integer.parseInt((String) jsonObject.get("PDVP_CORRSTATUS2"));
		PDVP_DIDNOT_PARTCORR_ALARMTYPE = Integer.parseInt((String) jsonObject.get("PDVP_DIDNOT_PARTCORR_ALARMTYPE"));
		PDVP_DIDNOT_PARTCORR_CORRSTATUS1 = Integer.parseInt((String) jsonObject.get("PDVP_DIDNOT_PARTCORR_CORRSTATUS1"));
		PDVP_DIDNOT_PARTCORR_CORRSTATUS2 = Integer.parseInt((String) jsonObject.get("PDVP_DIDNOT_PARTCORR_CORRSTATUS2"));
		TPVP_DIDNOT_PARTCORR_ALARMTYPE = Integer.parseInt((String) jsonObject.get("TPVP_DIDNOT_PARTCORR_ALARMTYPE"));
		TPVP_DIDNOT_PARTCORR_CORRSTATUS1 = Integer.parseInt((String) jsonObject.get("TPVP_DIDNOT_PARTCORR_CORRSTATUS1"));
		TPVP_DIDNOT_PARTCORR_CORRSTATUS2 = Integer.parseInt((String) jsonObject.get("TPVP_DIDNOT_PARTCORR_CORRSTATUS2"));
		BOTH_DIDNOT_PARTCORR_ALARMTYPE = Integer.parseInt((String) jsonObject.get("BOTH_DIDNOT_PARTCORR_ALARMTYPE"));
		BOTH_DIDNOT_PARTCORR_CORRSTATUS1 = Integer.parseInt((String) jsonObject.get("BOTH_DIDNOT_PARTCORR_CORRSTATUS1"));
		BOTH_DIDNOT_PARTCORR_CORRSTATUS2 = Integer.parseInt((String) jsonObject.get("BOTH_DIDNOT_PARTCORR_CORRSTATUS2"));
		
		String env = (String) jsonObject.get("Prod|UAT|ST|Dev");
		System.out.println("Env = " + env + ". Getting DB URL...");
		String DB_URL = DbAccess.getDbUrl(env);
		System.out.println("DB URL = " + DB_URL + ".");
		DbAccess dB = new DbAccess(DB_URL);
		dB.connDb();
		
		String Bridge_DB_URL = DbAccess.getDbUrl("Prod_Bridge");
		System.out.println("Bridge_DB_URL = " + Bridge_DB_URL + ".");
		DbAccess bridgedB = new DbAccess(Bridge_DB_URL);
		bridgedB.connDb();

        FileWriter repWr = null;
        String repFileName = (String) jsonObject.get("ReportBaseFileName");
        repFileName = repFileName + "." + CorrReportUtils.getPreviousDayForSql() + ".html";
        
        try {
        	repWr = new FileWriter(repFileName);
        }
        catch (Exception e) {
            System.out.println("new FileWriter Exception = " + e);
            e.printStackTrace();
            dB.disconnDb();
            bridgedB.disconnDb();
            System.exit(1);
        }

        CorrReportUtils utils = new CorrReportUtils(repWr);
        CorrReportUtils.beginHtmlOut(env);
   	
        if ( ((String) jsonObject.get("DailyAlarmVolumesReport")).equalsIgnoreCase("Run") ) {
			DailyAlarmVolumes dailyVolRep = new DailyAlarmVolumes(dB, repWr);
			try {
				dailyVolRep.generateReport();
			}
			catch (Exception e) {
				System.out.println("dailyVolRep.generateReport() Exception = " + e);
				e.printStackTrace();
			}		
        }
        
        if ( ((String) jsonObject.get("TopoCorrCountsReport")).equalsIgnoreCase("Run") ) {
			TopologicalCorrCounts topoCorrRep = new TopologicalCorrCounts(dB, bridgedB, repWr);
			try {
				topoCorrRep.generateReport();
			}
			catch (Exception e) {
				System.out.println("topoCorrRep.generateReport() Exception = " + e);
				e.printStackTrace();
			}
        }
        
        if ( ((String) jsonObject.get("RuleBasedCorrCountsReport")).equalsIgnoreCase("Run") ) {
			RuleBasedCorrCounts ruleCorrRep = new RuleBasedCorrCounts(dB, bridgedB, repWr);
			try {
				ruleCorrRep.generateReport();
			}
			catch (Exception e) {
				System.out.println("ruleCorrRep.generateReport() Exception = " + e);
				e.printStackTrace();
			}
        }
        
		CorrReportUtils.endHtmlOut();
		
        try {
        	repWr.close();
        }
        catch (Exception e) {
            System.out.println("close FileWriter Exception = " + e);
            e.printStackTrace();
            dB.disconnDb();
            bridgedB.disconnDb();
            System.exit(1);
        }
        
		dB.disconnDb();
		bridgedB.disconnDb();
		
		System.out.println("sending mail...");
		CorrReportUtils.sendMail(repFileName, env);
	
		System.out.println();
		TS = new Date();
		System.out.println("CorrReport End ... on " +  TsDf.format(TS));
	}
	
	private static void readConfig(String configFile) {
		try {
			JSONParser parser = new JSONParser();
			Object obj = parser.parse(new FileReader(configFile));
			jsonObject = (JSONObject) obj;
		}
		catch (Exception e) {
			System.out.println("Caught Exception in readConfig() when trying to read file : " + configFile + ".");
			e.printStackTrace();
			System.exit(1);
		}
	}

}
