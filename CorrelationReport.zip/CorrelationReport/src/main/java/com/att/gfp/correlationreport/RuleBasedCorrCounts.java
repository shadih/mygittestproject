package com.att.gfp.correlationreport;

import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class RuleBasedCorrCounts {
	
	DbAccess dB;
	DbAccess bridgedB;
	FileWriter reportWriter;
	String previousDay, previousDayReport;
	String reportName;
	
	RuleBasedCorrCounts(DbAccess dbA, DbAccess brgdbA, FileWriter repWr) {
		
		this.reportWriter = repWr;
		
		previousDay = CorrReportUtils.getPreviousDayForSql();
		previousDayReport = CorrReportUtils.getPreviousDayForReport();
		
		this.dB = dbA;
		this.bridgedB = brgdbA;
		
		System.out.println("Previous Day : " + previousDay + " ...");
		
        reportName = "GFP-Mobility Rule-Based Correlations Counts";
        Date TS = new Date();
        System.out.println("Processing Report : " + reportName + " ...on " +  CorrReportStart.TsDf.format(TS));
    }						

	
	public void generateReport() throws Exception {
		
		String sql = "select distinct corr_name from bridge.correlation_def where active = 1";
		
		String[] fieldsArr = {"corr_name", "String"};
		System.out.println("Running sql : " + sql + " ...");
		try {
			reportWriter.write("Report : <h2>" + reportName + "</h2>");
			ArrayList<Object> qryResults = new ArrayList<Object>();
			qryResults = bridgedB.qryDb(sql, fieldsArr);
			ArrayList<String> qryOut = new ArrayList<String>();
			qryOut = (ArrayList<String>) qryResults.get(1);
			Iterator<String> qryOutIterator = qryOut.iterator(); 
			int totCnt = 0; int corrnameCnt = qryOut.size();
			Map<String, Integer> reportMap = new HashMap<String, Integer>();
			//Boolean done = false;		

			System.out.println("Found " + corrnameCnt + " corr_name's");
			
			while (qryOutIterator.hasNext()) {
				//if (done) { break; }
				String corrname = qryOutIterator.next();
				totCnt++;
				System.out.println("Querying for " + corrname + " ... " + totCnt + " of " + corrnameCnt + " ...");
				String cnt_sql = "Select count(*) as COUNT From Gfpalarm.Message_Status Partition (ms_part_" +
						          previousDay + ") Where corrname like '%" + corrname + "%'";
				
				String[] fieldsCntArr = {"COUNT", "Int"};
				ArrayList<Object> qryCntResults = new ArrayList<Object>();
				qryCntResults = dB.qryDb(cnt_sql, fieldsCntArr);
				ArrayList<String> qryCntOut = new ArrayList<String>();
				qryCntOut = (ArrayList<String>) qryCntResults.get(1);
				Iterator<String> qryCntOutIterator = qryCntOut.iterator(); 
				while (qryCntOutIterator.hasNext()) {
					int retCorrnameCnt = Integer.parseInt(qryCntOutIterator.next());
					reportMap.put(corrname, retCorrnameCnt);
				}
				//if (totCnt == 3) {
				//	done = true;
				//}				
			}
			
			if ( totCnt == 0 ) {
				
				reportWriter.write("<br><b>No Data returned from SQL query : <br>" + sql );
				reportWriter.write("<br><br>No Report will be generated <br></b><br>" );
				
				return;
			}
			
			reportWriter.write("<br><br><table><tr>");		
			reportWriter.write("<td colspan=\"2\" align=\"center\"><b><i>Rule-Based Correlations </i></b> for " + previousDayReport + "</td>");
			reportWriter.write("</tr><tr>");
			reportWriter.write("<td align=\"center\"> Correlation Name </td>");
			reportWriter.write("<td align=\"center\"> TOTAL Correlation Count </td>");
			reportWriter.write("</tr><tr><td colspan=\"2\" bgcolor=\"grey\" height=\"20\"></td></tr>");		
			
			if ( totCnt == 0 ) {
				reportWriter.write("</table>");
				return;
			}
			
			reportWriter.write(CorrReportUtils.sortMap(reportMap));
			reportWriter.write("</table>");
			reportWriter.write("<hr><br><br>");
			
			System.out.println();
		}
		catch (Exception e) {
			System.out.println("Cannot run RuleBasedCorrCounts.generateRep(), Exception =  " + e);
			e.printStackTrace();
		}
	}
	
}
