package com.att.gfp.data.neo4jtopoquery;

import java.io.File;
import java.io.FileReader;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.HashSet;
import org.neo4j.graphdb.Node;
import org.neo4j.rest.graphdb.RestAPI;
import org.neo4j.rest.graphdb.RestAPIFacade;
import org.neo4j.rest.graphdb.RestGraphDatabase;
import org.neo4j.rest.graphdb.query.QueryEngine;
import org.neo4j.rest.graphdb.query.RestCypherQueryEngine;
import org.neo4j.rest.graphdb.util.QueryResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.neo4j.cypher.javacompat.ExecutionEngine;
import org.neo4j.cypher.javacompat.ExecutionResult;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.factory.GraphDatabaseFactory;
import javax.transaction.TransactionManager;
import scala.Function0;
import com.googlecode.concurrentlinkedhashmap.ConcurrentLinkedHashMap;;

public class EvcQueryUsingExecutionEngineAndExecutionResult {
	public static RestAPI graphDb;
	private static final Logger log = LoggerFactory.getLogger ( EvcQueryUsingExecutionEngineAndExecutionResult.class );
	private static ExecutionEngine engine;

	public static void main(String[] args) {

		String hostname = System.getenv("IPAG_HOST");

		hostname = "rldh033.oss.att.com";

		log.info("Starting Neo4jQuery. Using hostname = " + hostname);

		if ( null == hostname ||  hostname.isEmpty() ) {
			log.error("Empty/null hostname. Exiting");
			System.exit(1);
		}

		GraphDatabaseService graphDb = null;

		try{

			String graphDbUrl = "http://" + hostname + ":7574/db/data/";
			log.info("Creating graphDb with URL = " + graphDbUrl);

			graphDb = new RestGraphDatabase(graphDbUrl);

			engine = new ExecutionEngine(graphDb);



		}
		catch(Exception e)
		{
			log.error("Exception Occured = " + e.toString(), e);
			graphDb.shutdown();
		}

		query("start evcnode=node:EVCNode(key=\"245.168.95.137/VPLS:77743\") return evcnode", "");
		//query("START n=node(*)  WHERE ( HAS(n.class) and n.class=\"EVCNode\" and HAS(n.product_type) and n.product_type=\"SDN-ETHERNET\" ) RETURN n", "");

		log.info("Done. Existing");
		graphDb.shutdown();
		System.exit(0);
	}


	private static void query (String query, String outputFileName) {
		log.info("Running query: " + query);
		log.info("\t" + query);
		log.info("outputFileName: " + outputFileName);

		try {
			ExecutionResult result = engine.execute(query);

			Node node = null;
			Iterator<Node> columnRows = result.columnAs("evcnode");
			//Iterator<Node> columnRows = result.columnAs("n");

			while(columnRows.hasNext()) {  
				node = columnRows.next(); 

				Iterator<String> keys = node.getPropertyKeys().iterator();
				while ( keys.hasNext() ) {
					String key = keys.next();
					log.info("key -> " + key);
					log.info("val -> " + node.getProperty(key));
				}
			}
		}
		catch (Exception e) {
			log.error("Exception while running updateNode = " + e.toString(), e);
		}

	}

}

