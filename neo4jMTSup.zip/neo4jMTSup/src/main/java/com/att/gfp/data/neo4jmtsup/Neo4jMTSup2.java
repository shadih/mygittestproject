package com.att.gfp.data.neo4jmtsup;

import java.io.File;
import java.io.FileReader;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.HashSet;
import org.neo4j.rest.graphdb.RestAPI;
import org.neo4j.rest.graphdb.RestAPIFacade;
import org.neo4j.rest.graphdb.query.QueryEngine;
import org.neo4j.rest.graphdb.query.RestCypherQueryEngine;
import org.neo4j.rest.graphdb.util.QueryResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Neo4jMTSup2 {
	public static RestAPI graphDb;
	private static final Logger log = LoggerFactory.getLogger ( Neo4jMTSup2.class );
	private static JSONObject mainJson;
	private static QueryEngine engine;
	private static int updateCount = 0;

	public static void main(String[] args) {

		//String hostname = System.getenv("IPAG_HOST");

		String hostname = "rldh033.oss.att.com";

		log.info("Starting Neo4jQuery. Using hostname = " + hostname);

		if ( null == hostname ||  hostname.isEmpty() ) {
			log.error("Empty/null hostname. Exiting");
			System.exit(1);
		}

		try{

			String graphDbUrl = "http://" + hostname + ":7574/db/data/";
			log.info("Creating graphDb with URL = " + graphDbUrl);

			graphDb = new RestAPIFacade(graphDbUrl);

			engine=new RestCypherQueryEngine(graphDb);  
			
			processPports("143.0.24.235/1/0/0", "");

		}
		catch(Exception e)
		{
			log.error("Exception Occured = " + e.toString(), e);
			System.out.println("Exception Occured = " + e.toString());
			e.printStackTrace();
		}
		finally {
			graphDb.close();
		}


	}


	private static void updateNode (String key, String nClass, String propName, String propVal) {
		String query = "START nd=node:" + nClass + "(key=\""+ key +"\") SET nd." + propName + "=\"" + propVal + "\" return nd." + propName; 

		log.info("Running Query = " + query + " ... ");
		//System.out.println("Running Query = " + query + " ... ");

		try {
			QueryResult<Map<String,Object>> result = engine.query(query, Collections.EMPTY_MAP);
			Iterator<Map<String, Object>> iterator=result.iterator();  

			while(iterator.hasNext()) {  
				log.info("Attempting to set property value...");
				Map<String,Object> row= iterator.next();  
				for (Map.Entry<String, Object> entry : row.entrySet()) {
					if ( entry.getValue().equals(propVal)) {
						log.info("OK");
						updateCount++;
					}
					else {
						log.info(propName + " not set properly");
					}
				}
			}
		}
		catch (Exception e) {
			log.error("Exception while running updateNode = " + e.toString(), e);
		}
	}

	private static void processPports (String key, String inmaintVal) {
		String query = "START locDev=node:PE_Device(key=\""+key+"\") match " +
				"(locDev)-[:Composed_Of]->(locSlot)-[:Composed_Of]->(locCard)-[:Composed_Of]->(locPPort) " +
				"return locPPort.remote_pport_key, locPPort.remote_device_type";
		
		Map<String,Object> params = new HashMap<>();
		params.put("key", key);
		//String query2 = "start locPPort=node:PE_PPort(key=\"" + key + "\") return locPPort.remote_pport_key, locPPort.remote_device_type";
		String query2 = "start locPPort=node:PE_PPort(key= { key } ) return locPPort.remote_pport_key, locPPort.remote_device_type";

		HashSet<String> remoteIPs = new HashSet<String>();

		log.info("Running query to get remote pports: " + query2);
		System.out.println("Running query to get remote pports: " + query2);
		for (Map.Entry<String, Object> entry : params.entrySet() ) {
			System.out.println("\t " + entry.getKey() + " --> " + entry.getValue());
		}

		try {
			//QueryResult<Map<String,Object>> result = engine.query(query2, Collections.EMPTY_MAP);
			QueryResult<Map<String,Object>> result = engine.query(query2, params);
			Iterator<Map<String, Object>> iterator=result.iterator();  
			while(iterator.hasNext()) {  
				Map<String,Object> row= iterator.next();  
				//for (Map.Entry<String, Object> entry : row.entrySet()) {

				String remote_pport_key = (String)row.get("locPPort.remote_pport_key");

				log.info("remote_pport_key = " + remote_pport_key);
				System.out.println("remote_pport_key = " + remote_pport_key);

				String remote_device_type = (String)row.get("locPPort.remote_device_type");

				log.info("remote_device_type = " + remote_device_type);
				System.out.println("remote_device_type = " + remote_device_type);

				return;
/*				
				if (    (!remote_device_type.contains("CIENA")) && 
						(!remote_device_type.contains("ADTRAN")) &&
						(!remote_device_type.contains("ALCATEL")) &&
						(null != remote_pport_key && !remote_pport_key.isEmpty()) ) {
					remoteIPs.add(remote_pport_key.split("/")[0]); 
					updateNode(remote_pport_key, "PE_PPort", "nghbr_inmaint", inmaintVal);
				}
*/
				//if ( (null != (String)entry.getValue()) && !((String)entry.getValue()).isEmpty() ) {
				//	remoteIPs.add(((String)entry.getValue()).split("/")[0]); 
				//	updateNode((String)entry.getValue(), "PE_PPort", "nghbr_inmaint", inmaintVal);
				//}
				//}
			}
		}
		catch (Exception e) {
			log.error("Exception while running updateNode = " + e.toString(), e);
		}

/*		if ( remoteIPs.contains(key) ) {
			remoteIPs.remove(key);
		}

		for(String nghbrIP : remoteIPs) {
			log.info("Setting nghbr_inmaint to " + inmaintVal + " for remote device IP = " + nghbrIP);
			updateNode(nghbrIP, "PE_Device", "nghbr_inmaint", inmaintVal);
		}
*/
	}

}

