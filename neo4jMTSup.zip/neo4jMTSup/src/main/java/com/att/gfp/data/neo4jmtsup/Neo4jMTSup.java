package com.att.gfp.data.neo4jmtsup;

import java.io.File;
import java.io.FileReader;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.HashSet;
import org.neo4j.rest.graphdb.RestAPI;
import org.neo4j.rest.graphdb.RestAPIFacade;
import org.neo4j.rest.graphdb.query.QueryEngine;
import org.neo4j.rest.graphdb.query.RestCypherQueryEngine;
import org.neo4j.rest.graphdb.util.QueryResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Neo4jMTSup {
	public static RestAPI graphDb;
	private static final Logger log = LoggerFactory.getLogger ( Neo4jMTSup.class );
	private static JSONObject mainJson;
	private static QueryEngine engine;
	private static int updateCount = 0;

	public static void main(String[] args) {

		String hostname = System.getenv("IPAG_HOST");

		//hostname = "rldh033.oss.att.com";

		log.info("Starting Neo4jQuery. Using hostname = " + hostname);

		if ( null == hostname ||  hostname.isEmpty() ) {
			log.error("Empty/null hostname. Exiting");
			System.exit(1);
		}

		File f = new File(args[0]);

		if ( f.exists() ) {
			log.info("Reading " + args[0] + "...  ");

			try {
				mainJson = new JSONObject(new JSONTokener(new FileReader(args[0])));
			}
			catch (JSONException je) {
				log.error("JSONException While Initializing JSONObject = " + je.toString(), je);
				System.out.println("JSONException While Initializing JSONObject = " + je.toString());
				je.printStackTrace();
				System.exit(1);
			}
			catch (Exception e) {
				log.error("Exception While Initializing JSONObject = " + e.toString(), e);
				System.out.println("Exception While Initializing JSONObject = " + e.toString());
				e.printStackTrace();
				System.exit(1);
			}
			log.info("Done.");
		} else {
			log.error("Input file: " + args[0] + " not found. Exiting.");
			System.out.println("Input file: " + args[0] + " not found. Exiting.");
			System.exit(1);
		}

		try{

			String graphDbUrl = "http://" + hostname + ":7574/db/data/";
			log.info("Creating graphDb with URL = " + graphDbUrl);

			graphDb = new RestAPIFacade(graphDbUrl);

			engine=new RestCypherQueryEngine(graphDb);  

			String ipsToSuppress = mainJson.getString("suppress");
			String ipsToUnSuppress = mainJson.getString("unsuppress");

			if ( null != ipsToUnSuppress && !ipsToUnSuppress.isEmpty() ) {
				String[] unSuppressList = ipsToUnSuppress.split(",");
				for (String ip : unSuppressList ) {
					unSuppressIp(ip);
				}
			}
			
			if ( null != ipsToSuppress && !ipsToSuppress.isEmpty() ) {
				String[] suppressList = ipsToSuppress.split(",");
				for (String ip : suppressList ) {
					suppressIp(ip);
				}
			}

		}
		catch(Exception e)
		{
			log.error("Exception Occured = " + e.toString(), e);
			System.out.println("Exception Occured = " + e.toString());
			e.printStackTrace();
		}
		finally {
			graphDb.close();
		}

		log.info("Done. " + updateCount + " nodes were updated.");
		System.out.println("Done. " + updateCount + " nodes were updated.");
		System.exit(0);
	}

	private static void suppressIp (String ip) {
		log.info("Suppressing IP = " + ip);
		updateNode(ip, "PE_Device", "inmaint", "true");
		processPports(ip, "true");
	}

	private static void unSuppressIp (String ip) {
		log.info("UnSuppressing IP = " + ip);
		updateNode(ip, "PE_Device", "inmaint", "false");
		processPports(ip, "false");
	}

	private static void updateNode (String key, String nClass, String propName, String propVal) {
		String query = "START nd=node:" + nClass + "(key=\""+ key +"\") SET nd." + propName + "=\"" + propVal + "\" return nd." + propName; 

		log.info("Running Query = " + query + " ... ");
		//System.out.println("Running Query = " + query + " ... ");

		try {
			QueryResult<Map<String,Object>> result = engine.query(query, Collections.EMPTY_MAP);
			Iterator<Map<String, Object>> iterator=result.iterator();  

			while(iterator.hasNext()) {  
				log.info("Attempting to set property value...");
				Map<String,Object> row= iterator.next();  
				for (Map.Entry<String, Object> entry : row.entrySet()) {
					if ( entry.getValue().equals(propVal)) {
						log.info("OK");
						updateCount++;
					}
					else {
						log.info(propName + " not set properly");
					}
				}
			}
		}
		catch (Exception e) {
			log.error("Exception while running updateNode = " + e.toString(), e);
		}
	}

	private static void processPports (String key, String inmaintVal) {
		String query = "START locDev=node:PE_Device(key=\""+key+"\") match " +
				"(locDev)-[:Composed_Of]->(locSlot)-[:Composed_Of]->(locCard)-[:Composed_Of]->(locPPort) " +
				"return locPPort.remote_pport_key, locPPort.remote_device_type";
		HashSet<String> remoteIPs = new HashSet<String>();

		log.info("Running query to get remote pports: " + query);

		try {
			QueryResult<Map<String,Object>> result = engine.query(query, Collections.EMPTY_MAP);
			Iterator<Map<String, Object>> iterator=result.iterator();  
			while(iterator.hasNext()) {  
				Map<String,Object> row= iterator.next();  
				//for (Map.Entry<String, Object> entry : row.entrySet()) {

				String remote_pport_key = (String)row.get("locPPort.remote_pport_key");

				log.info("remote_pport_key = " + remote_pport_key);

				String remote_device_type = (String)row.get("locPPort.remote_device_type");

				log.info("remote_device_type = " + remote_device_type);


				if (    (!remote_device_type.contains("CIENA")) && 
						(!remote_device_type.contains("ADTRAN")) &&
						(!remote_device_type.contains("ALCATEL")) &&
						(null != remote_pport_key && !remote_pport_key.isEmpty()) ) {
					remoteIPs.add(remote_pport_key.split("/")[0]); 
					updateNode(remote_pport_key, "PE_PPort", "nghbr_inmaint", inmaintVal);
				}

				//if ( (null != (String)entry.getValue()) && !((String)entry.getValue()).isEmpty() ) {
				//	remoteIPs.add(((String)entry.getValue()).split("/")[0]); 
				//	updateNode((String)entry.getValue(), "PE_PPort", "nghbr_inmaint", inmaintVal);
				//}
				//}
			}
		}
		catch (Exception e) {
			log.error("Exception while running updateNode = " + e.toString(), e);
		}

		if ( remoteIPs.contains(key) ) {
			remoteIPs.remove(key);
		}

		for(String nghbrIP : remoteIPs) {
			log.info("Setting nghbr_inmaint to " + inmaintVal + " for remote device IP = " + nghbrIP);
			updateNode(nghbrIP, "PE_Device", "nghbr_inmaint", inmaintVal);
		}
	}

}

