package com.att.gfp.data.neo4jtopoquery;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.HashSet;
import org.neo4j.graphdb.Node;
import org.neo4j.rest.graphdb.RestAPI;
import org.neo4j.rest.graphdb.RestAPIFacade;
import org.neo4j.rest.graphdb.query.QueryEngine;
import org.neo4j.rest.graphdb.query.RestCypherQueryEngine;
import org.neo4j.rest.graphdb.util.QueryResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Calendar;


public class EvcQuery {
	public static RestAPI graphDb;
	private static final Logger log = LoggerFactory.getLogger ( EvcQuery.class );
	private static QueryEngine engine;
	private static String basefileName = null;
	private static int cnt = 0;

	public static void main(String[] args) {

		try {
			log.info("Using report base file name: " + args[0]);
		} catch (Exception e) {
			log.error("No argument/filename passed. Exiting. Exception = " + e.toString(), e);
			System.exit(1);
		}

		String hostname = System.getenv("IPAG_HOST");

		//hostname = "rldh033.oss.att.com";
		//hostname = "rlth093.oss.att.com";

		log.info("Starting Neo4jQuery. Using hostname = " + hostname);

		if ( null == hostname ||  hostname.isEmpty() ) {
			log.error("Empty/null hostname. Exiting");
			System.exit(1);
		}

		try{

			String graphDbUrl = "http://" + hostname + ":7874/db/data/";
			log.info("Creating graphDb with URL = " + graphDbUrl);

			graphDb = new RestAPIFacade(graphDbUrl);

			engine=new RestCypherQueryEngine(graphDb);  

		}
		catch(Exception e)
		{
			log.error("Exception Occured = " + e.toString(), e);
			e.printStackTrace();
		}
		finally {
			log.info("Closing graphDb");
			graphDb.close();
		}

		//String evcQueryText = "START n=node(*) WHERE HAS(n.service_ind) and n.class=\"IpagEvcNode\" and n.service_ind=\"SDN-ETHERNET-INTERNET\" RETURN " + 
		String evcQueryText = "START n=node:serviceind(service_ind=\"SDN-ETHERNET-INTERNET\") RETURN " +
				"n.acnaban, n.ineffect, n.clci, n.port_aid, n.evc_name, n.unickt, n.cdc_subscription_type, " +
				"n.alarm_classification, n.data_source, n.class, n.product_type, n.legacy_org_ind, n.nte_uni, n.ipaddress, n.service_ind, " +
				"n.svlanid, n.is_operational, n.alarm_domain, n.cvlanid, n.vrf_name, n.clli, n.key, n.TDL_instance_name";

		//query("start evcnode=node:EVCNode(key=\"245.168.95.137/VPLS:77743\") return evcnode.evc_name", "");
		//query("START n=node(*) WHERE HAS(n.service_ind) and n.service_ind=\"SDN-ETHERNET-INTERNET\"  RETURN n.evc_name", "");

		String date = new SimpleDateFormat("yyyy.MM.dd").format(new Date());

		query(evcQueryText, args[0]+"."+date);

		if ( cnt != 0 ) { deleteOldEvcFiles(args[0]); }

		log.info("Done. Existing");
		graphDb.close();
		System.exit(0);
	}


	private static void query (String query, String outputFileName) {
		log.info("Running query: " + query);
		log.info("outputFileName: " + outputFileName);


		BufferedWriter bufWriter = null;

		try {
			QueryResult<Map<String,Object>> result = engine.query(query, Collections.EMPTY_MAP);
			Iterator<Map<String, Object>> iterator=result.iterator();  

			bufWriter = new BufferedWriter(new FileWriter(new File(outputFileName)));

			bufWriter.write("acnaban|ineffect|clci|port_aid|evc_name|unickt|cdc_subscription_type|alarm_classification|data_source|class"
					+ "|product_type|legacy_org_ind|nte_uni|ipaddress|service_ind|svlanid|is_operational|alarm_domain|cvlanid|vrf_name|"
					+ "clli|key|TDL_instance_name");
			bufWriter.newLine();

			while(iterator.hasNext()) {  
				Map<String,Object> row= iterator.next();  

				if ( null == (String)row.get("n.port_aid") || ((String)row.get("n.port_aid")).isEmpty() ) {	
					continue;
				}

				bufWriter.write((String)row.get("n.acnaban")+"|"+(String)row.get("n.ineffect")+"|"+(String)row.get("n.clci")+"|"+
						(String)row.get("n.port_aid")+"|"+(String)row.get("n.evc_name")+"|"+(String)row.get("n.unickt")+"|"+
						(String)row.get("n.cdc_subscription_type")+"|"+(String)row.get("n.alarm_classification")+"|"+
						(String)row.get("n.data_source")+"|"+(String)row.get("n.class")+"|"+(String)row.get("n.product_type")+"|"+
						(String)row.get("n.legacy_org_ind")+"|"+(String)row.get("n.nte_uni")+"|"+(String)row.get("n.ipaddress")+"|"+
						(String)row.get("n.service_ind")+"|"+(String)row.get("n.svlanid")+"|"+(String)row.get("n.is_operational")+"|"+
						(String)row.get("n.alarm_domain")+"|"+(String)row.get("n.cvlanid")+"|"+(String)row.get("n.vrf_name")+"|"+
						(String)row.get("n.clli")+"|"+(String)row.get("n.key")+"|"+(String)row.get("n.TDL_instance_name"));
				bufWriter.newLine();
				cnt++;

			}
			bufWriter.flush();
		}
		catch (Exception e) {
			log.error("Exception while writing to report file. " + e.toString(), e);
			cnt = 0;
		}
		finally {
			try {
				bufWriter.close();
			} catch (IOException e) {
				log.error("IOException while closing bufWriter = " + e.toString(), e);
				cnt = 0;
			}
		}
		log.info("Count: " + cnt);
	}

	public static void deleteOldEvcFiles (String input) {

		String dir = input.substring(0, input.lastIndexOf("/"));
		basefileName = input.substring(input.lastIndexOf("/")+1, input.length());

		log.info("Attempting to delete old evcReport files from dir " + dir + " with basefileName " + basefileName + ".");

		File[] listOfFiles = new File(dir).listFiles(new EvcFileFilter());
		long maxAge = 7 * 24 * 60 * 60 * 1000;
		//long maxAge = 10 * 1000;

		for (File f : listOfFiles) {
			log.info("Checking file: " + f.getName() + ".");
			long fileAge = new Date().getTime() - f.lastModified();
			if ( fileAge > maxAge ) {
				log.info("\tDeleting...");
				if ( f.delete() ) {
					log.info("\tDone");
				}
				else {
					log.info("\tFailed");
				}
			}
		}
	}

	public static class EvcFileFilter implements FilenameFilter {

		@Override
		public boolean accept(File dir, String fileName) {
			if ( fileName.contains(basefileName) ) {
				return true;
			}
			else {
				return false;
			}

		}
	}

}

