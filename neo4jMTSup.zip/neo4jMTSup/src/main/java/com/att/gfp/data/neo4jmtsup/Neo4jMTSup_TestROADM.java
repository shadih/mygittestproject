package com.att.gfp.data.neo4jmtsup;

import java.io.File;
import java.io.FileReader;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.HashSet;
import org.neo4j.rest.graphdb.RestAPI;
import org.neo4j.rest.graphdb.RestAPIFacade;
import org.neo4j.rest.graphdb.query.QueryEngine;
import org.neo4j.rest.graphdb.query.RestCypherQueryEngine;
import org.neo4j.rest.graphdb.util.QueryResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public class Neo4jMTSup_TestROADM {
	public static RestAPI graphDb;
	private static final Logger log = LoggerFactory.getLogger ( Neo4jMTSup_TestROADM.class );
	private static JSONObject mainJson;
	private static QueryEngine engine;
	private static int updateCount = 0;

	public static void main(String[] args) {

		String hostname = System.getenv("IPAG_HOST");

		hostname = "rldh033.oss.att.com";

		log.info("Starting Neo4jQuery. Using hostname = " + hostname);

		if ( null == hostname ||  hostname.isEmpty() ) {
			log.error("Empty/null hostname. Exiting");
			System.exit(1);
		}

		try{

			String graphDbUrl = "http://" + hostname + ":7574/db/data/";
			log.info("Creating graphDb with URL = " + graphDbUrl);

			graphDb = new RestAPIFacade(graphDbUrl);

			engine=new RestCypherQueryEngine(graphDb);  
			
			String overallCLFI = "overallCLFI2";
			String rootCauseCLFI = "rootCauseCLFI2";
			String alarmTime = String.valueOf(System.currentTimeMillis()/1000);
			
			String query = "START n=node(0) CREATE (t  { class : \"ROADM\" , overallCLFI :\"" + overallCLFI + 
					"\" , rootCauseCLFI :\"" + rootCauseCLFI + "\" , alarmTime :\"" + alarmTime + 
					"\" } ) CREATE n-[:ROADMTicket]->t RETURN t.overallCLFI, t.rootCauseCLFI, t.alarmTime";
			
			log.info("Before calling createNode() ... Query = " + query + " ... ");
			//createNode(overallCLFI, rootCauseCLFI, alarmTime);
			
			//deleteNode(overallCLFI);
			
			purgeNode();
			

		}
		catch(Exception e)
		{
			log.error("Exception Occured = " + e.toString(), e);
			System.out.println("Exception Occured = " + e.toString());
			e.printStackTrace();
		}
		finally {
			graphDb.close();
		}


		System.exit(0);
	}
	
	private static void createNode (String overallCLFI, String rootCauseCLFI, String alarmTime) {
		
		String query = "START n=node(0) CREATE (t  { class : \"ROADM\" , overallCLFI :\"" + overallCLFI + 
				"\" , rootCauseCLFI :\"" + rootCauseCLFI + "\" , alarmTime :\"" + alarmTime + 
				"\" } ) CREATE n-[:ROADMTicket]->t RETURN t.overallCLFI, t.rootCauseCLFI, t.alarmTime";
		

		log.info("Running Query = " + query + " ... ");

		try {
			QueryResult<Map<String,Object>> result = engine.query(query, Collections.EMPTY_MAP);
			Iterator<Map<String, Object>> iterator=result.iterator();  
			while(iterator.hasNext()) {  
				Map<String,Object> row= iterator.next();  

				String retOverallCLFI = (String)row.get("t.overallCLFI");
				log.info("retOverallCLFI = " + retOverallCLFI);
				
				String retRootCauseCLFI = (String)row.get("t.rootCauseCLFI");
				log.info("retRootCauseCLFI = " + retRootCauseCLFI);
				
				String retAlarmTime = (String)row.get("t.alarmTime");
				log.info("retAlarmTime = " + retAlarmTime);
			}
		}
		catch (Exception e) {
			log.error("Exception while running createNode() = " + e.toString(), e);
		}
	}
	
	private static void deleteNode (String overallCLFI) {
				
		String query = "START n=node(0) MATCH (n)-[r:ROADMTicket]-(t) WHERE t.overallCLFI=\"" + overallCLFI + "\" DELETE t, r";
		

		log.info("Running Query = " + query + " ... ");

		try {
			QueryResult<Map<String,Object>> result = engine.query(query, Collections.EMPTY_MAP);
		}
		catch (Exception e) {
			log.error("Exception while running deleteNode() = " + e.toString(), e);
		}
	}
	
	private static void purgeNode () {
		
		String query = "START n=node(0) MATCH (n)-[: ROADMTicket]-(t) WHERE t.alarmTime < \"" + 
				String.valueOf(System.currentTimeMillis()/1000) + "\" RETURN  t.overallCLFI";
		

		log.info("Running Query = " + query + " ... ");

		try {
			QueryResult<Map<String,Object>> result = engine.query(query, Collections.EMPTY_MAP);
			Iterator<Map<String, Object>> iterator=result.iterator();  
			int i = 0;
			while(iterator.hasNext()) {  
				Map<String,Object> row= iterator.next();  

				String retOverallCLFI = (String)row.get("t.overallCLFI");
				log.info("Will delete node for retOverallCLFI = " + retOverallCLFI);
				
				deleteNode(retOverallCLFI);
				i++;
			}
			if ( i == 0 ) {
				log.info("No matching node to delete were found");
			}
			else {
				log.info("Deleted " + i + " records.");
			}
		}
		catch (Exception e) {
			log.error("Exception while running purgeNode() = " + e.toString(), e);
		}
	}

}

