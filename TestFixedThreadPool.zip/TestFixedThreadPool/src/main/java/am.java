

import java.util.concurrent.*;

class TTSTask implements Runnable {
              
       static final int MAX_TTS_TASKS = 20;

        public static ExecutorService ftp = Executors.newFixedThreadPool(MAX_TTS_TASKS);
        
        IpagAlarm incTtsAlarm;
        
        public TTSTask(IpagAlarm incTtsAlarm) {
              this.incTtsAlarm = incTtsAlarm;
              System.out.println("Constructing object for alarm with SeqNumber: " + this.incTtsAlarm.sequence);
        }
        
        public void run() {
              try {
                           
                  System.out.println("Thread = " + Thread.currentThread().getName() + "  TTS command executed for alarm with SeqNumber: " + this.incTtsAlarm.sequence);
                  Thread.sleep(30000);
                  System.out.println("Thread = " + Thread.currentThread().getName() + " waitFor() completed for TTS command for alarm with SeqNumber : " + this.incTtsAlarm.sequence);
              } catch(Exception e) { }
        }
}

class IpagAlarm
{
       public String sequence;
       public int value;
       IpagAlarm(String sequence, int value)
       {
              this.sequence = sequence;
              this.value = value;
       }
}

class ProcessAlarm
{
	ProcessAlarm () { }
	
	public void processAlarms(IpagAlarm incAlarm) throws InterruptedException {
        TTSTask runTts = new TTSTask(incAlarm);
        TTSTask.ftp.execute(runTts);
        Thread.sleep(10000);
	}
}

class GetAlarm
{
	GetAlarm() {
		ProcessAlarm procAlarm = new ProcessAlarm ();
		
		for (int i = 0; i < 2; i++)
	    { 
	           IpagAlarm incAlarm  = new IpagAlarm("12345"+i, 12345+i);
	           try {
	        	   procAlarm.processAlarms(incAlarm);
	           }
	           catch (InterruptedException ie) {
	        	   System.out.println("caught ie = " + ie);
	        	   ie.printStackTrace();
	           }
	    }
	}
	
}

public class am
{
       public static void main(String[] argvs) throws InterruptedException
       {

    	   GetAlarm getAlarm = new GetAlarm();
       }
}

