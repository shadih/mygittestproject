package com.att.gfp.data.util;

public class SuppressionBean {

	private boolean nfomobilityuniSuppression;

	public boolean isNfomobilityuniSuppression() {
		return nfomobilityuniSuppression;
	} 

	public void setNfomobilityuniSuppression(boolean nfomobilityuniSuppression) {
		this.nfomobilityuniSuppression = nfomobilityuniSuppression;
	}
}
