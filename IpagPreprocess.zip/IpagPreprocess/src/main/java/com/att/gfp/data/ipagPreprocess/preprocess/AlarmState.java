package com.att.gfp.data.ipagPreprocess.preprocess;

public enum AlarmState {
	forward,
	sent,
	pending,
	duplicated;  
}
