import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.io.input.Tailer;
import org.apache.commons.io.input.TailerListenerAdapter;
import org.apache.commons.io.input.TailerListener;


public class FsMon {

        private static final int SLEEP = 500;
        private static final File file = new File("/appl/UCA/adm/save_m_ps_files/vpo_m_chk.out.old");
        private static final String MAILCMD = "/bin/mailx -s \"New FS_ Monitor ENTRY\" \"sh1986@att.com,ko1456@att.com,my2328@att.com\"";
      

        public static void main(String[] args) throws Exception {

        	FsMon tF = new FsMon();
        	tF.run();
        	
        }
        
        private void run() throws InterruptedException {
                TailerListener listener = new MyTailerListener();
                Tailer tailer = Tailer.create(file, listener, SLEEP, true);
                while (true) {
                	Thread.sleep(SLEEP);
                }
        }


        public class MyTailerListener extends TailerListenerAdapter {
        	  @Override
              public void handle(String line) {
                  //System.out.println(line);
        		  if ( line.contains("FS_") ) {
        			  mailAndLog(line);
        		  }
              }
        }
        
        public void mailAndLog(String line) {
			long millis = System.currentTimeMillis();
			Date date = new Date(millis);
			SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss", Locale.ENGLISH);
			String formattedDate = sdf.format(date);
        	System.out.println("\t" + formattedDate + " -> Read line:");
        	System.out.println("\t" + line + "\n \tproceeding to send email");
        	String mailCmd = "echo \"" + line + "\" | " + MAILCMD;
        	mail(mailCmd);
        	//System.out.println("\tRunning command:");
        	//System.out.println("\t" + mailCmd);
        }
        
        public void mail(String mailCmd) {
        	String[] srtrCmd = {"/bin/sh", "-c", mailCmd};
        	System.out.println("\tRunning command:");
        	System.out.println("\t" + Arrays.toString(srtrCmd));
			try {
				
				Process p = Runtime.getRuntime().exec(srtrCmd);
				StringBuilder cmdOut = new StringBuilder();
				BufferedReader reader = new BufferedReader (new InputStreamReader(p.getInputStream()));
				BufferedReader readerStdErr = new BufferedReader (new InputStreamReader(p.getErrorStream()));
				String line = "";
	            while ( (line = reader.readLine()) != null ) {
	            	cmdOut.append(line + "\n");
	            }
	            while ( (line = readerStdErr.readLine()) != null ) {
	            	cmdOut.append(line + "\n");
	            }
				int returnCode = p.waitFor();
				if ( returnCode != 0) {
					System.out.println("\t\tcommand failed with return code:" + returnCode);
					System.out.println("\t\t" + cmdOut); 
				}
				else {
					System.out.println("\t\tcommand succeeded with return code 0");
				}
			}
			catch (Exception e) {
				System.out.println("mail() Exception: " + e);
				e.printStackTrace();
				System.exit(1);
			}	
        }
}
