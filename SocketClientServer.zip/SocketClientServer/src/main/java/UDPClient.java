import java.io.*; 
import java.net.*; 
  
class UDPClient { 
	 public static void main(String args[]) {
		 
		 BufferedReader in = null;
		    try {
		      String host = "127.0.0.1";
		      //String host = "135.13.5.6";
		      int port = 1515;
		      //String fileName = "syslogsToSimulate_TEST";
		      //String fileName = "syslogsToSimulate_MAIN1514";
		     //String fileName = "syslogsToSimulate_MAIN1514.1";
		     // String fileName = "syslogsToSimulate_VCO";
		     //String fileName = "syslogsToSimulate_VCO1";
		     //String fileName = "syslogsToSimulate_GENERIC_RFC3164.1";
		      //String fileName = "syslogToSimulate_BGP";
		     //String fileName = "syslogsToSimulate_VCO_EDGE_CPU_HIGH";
		     String fileName = "syslogsToSimulate_VCO_test";
		      //String fileName = "syslogsToSimulate_VCO_ECONNREFUSED4";
		    //  String fileName = "syslogsToSimulate_VIPR";
		      //String fileName = "syslogsToSimulate_NIMBUS";
		      //String fileName = "syslogsToSimulate_GEMALTO";
		      
		      in = new BufferedReader( new FileReader(fileName));

		      // Get the internet address of the specified host
		      InetAddress address = InetAddress.getByName(host);
		      
		      String syslogToSend;
		      
		      while ((syslogToSend = in.readLine()) != null) 
				{ 
		    	  
			      byte[] message = syslogToSend.getBytes();
		    	  
		    	// Initialize a datagram packet with data and address
			      DatagramPacket packet = new DatagramPacket(message, message.length,
			          address, port);

			      // Create a datagram socket, send the packet through it, close it.
			      DatagramSocket dsocket = new DatagramSocket();
			      System.out.println("UDP Client sending to port " + port + " message: \n" + syslogToSend);
			      dsocket.send(packet);
			      dsocket.close();
				}
		      in.close();
		    } catch (Exception e) {
		      System.err.println(e);
		      try {
				in.close();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		    }
		  }
		}