import java.io.*;
import java.net.*;

public class NomSim {
    public static void main(String[] args) throws IOException {

        String serverHostname = new String ("127.0.0.1");

        System.out.println ("Attemping to connect to host " + serverHostname + " on port 60091.");

        Socket echoSocket = null;
        PrintWriter out = null;

        try {
            echoSocket = new Socket(serverHostname, 60091);
            
            out = new PrintWriter(echoSocket.getOutputStream(), true);

        } catch (UnknownHostException e) {
            System.err.println("Don't know about host: " + serverHostname);
            System.exit(1);
        	echoSocket.close();
        } catch (IOException e) {
            System.err.println("Couldn't get I/O for "
                               + "the connection to: " + serverHostname);
        	echoSocket.close();
            System.exit(1);
        }

	String userInput;
	int i = 0;
	int sleep = 2000;
	
    try {
    	BufferedReader reader = new BufferedReader(new FileReader(args[0]));
    	
        while ( (userInput = reader.readLine()) != null ) {
        	System.out.println("sending following message to socket, count: " + ++i);
        	System.out.println(userInput);
        	out.println(userInput);
        	System.out.println("sleeping for: " + sleep );
        	Thread.sleep(sleep);
        }
       
    }
    catch (Exception e) {
    	System.out.println("Caught exception: " + e);
    	e.printStackTrace();
    	out.close();
    	echoSocket.close();
    	System.exit(0);
    }

	out.close();
	echoSocket.close();
    }
}

